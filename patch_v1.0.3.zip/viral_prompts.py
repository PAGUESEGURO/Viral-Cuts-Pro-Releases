"""
=============================================================================
VIRAL CUTS PRO - MOTOR DE PROMPTS VIRAIS MULTIDIMENSIONAIS (Camada 3)
Prompts otimizados para modelos locais (Qwen 3.5 9B / LM Studio) e Cloud
=============================================================================
"""

class ViralPrompts:
    """Gerenciador central de prompts estruturados com suporte a Few-Shot para Qwen."""

    CATEGORIAS_EMOCIONAIS = {
        "RAGE": "Tilt, frustração, raiva, perda de compostura, indignação",
        "HILARIOUS": "Humor genuíno, absurdo, fail, ironia, risadas",
        "SADGE": "Emoção sincera, desabafo, vulnerabilidade, momento comovente",
        "HYPE": "Clutch, vitória épica, jogada genial, celebração, adrenalina",
        "HOT_TAKE": "Opinião polêmica, debate moral/político, quebra de tabus",
    }

    CATEGORIAS_CONTEUDO = {
        "GAMING_CLUTCH": "Jogada habilidosa, extração, fail de gameplay, momento de jogo",
        "DEBATE_POLEMICA": "Discussão acalorada, opinião forte, tema controverso",
        "TEA_REVELACAO": "Segredo revelado, bastidores, fofoca, história pessoal chocante",
        "MEME_COMICO": "Momento cômico, auto-ironia, vergonha alheia, timing perfeito",
        "INSIGHT_REVIEW": "Conselho valioso, lição de vida, análise sincera",
    }

    @staticmethod
    def get_system_prompt_master(topico_detectado="HIBRIDO"):
        """System prompt com regras estritas de anatomia viral e JSON puro."""
        
        contexto_nicho = ""
        if topico_detectado == "GAMING":
            contexto_nicho = """
CONTEXTO: Esta é uma live de GAMING. Foque em:
- Momentos de TILT/RAGE quando o streamer morre ou perde loot
- Clutches épicos e jogadas habilidosas
- Reações autênticas a situações de jogo
- Interações com chat durante partidas"""
        elif topico_detectado == "DRAMA":
            contexto_nicho = """
CONTEXTO: Esta é uma live com DRAMA/FOFOCA. Foque em:
- Revelações chocantes ou bastidores
- Discussões acaloradas entre pessoas
- Momentos de tensão e confronto
- Opiniões polêmicas que geram debate"""
        elif topico_detectado == "RESENHA":
            contexto_nicho = """
CONTEXTO: Esta é uma live de RESENHA/ANÁLISE. Foque em:
- Opiniões fortes e polêmicas sobre temas
- Momentos de conselho valioso
- Análises sinceras que geram debate
- Interações autênticas com o público"""
        else:
            contexto_nicho = """
CONTEXTO: Live com conteúdo variado. Foque em:
- Momentos de alta emoção (rage, humor, hype)
- Interações genuínas com o chat
- Situações inesperadas ou absurdas
- Qualquer momento que faça o espectador querer compartilhar"""

        return f"""Você é um Diretor Especialista em Conteúdo Viral para TikTok, YouTube Shorts e Instagram Reels.
Sua missão é extrair os MOMENTOS DE MAIOR RETENÇÃO E ENGAJAMENTO de uma live.
{contexto_nicho}

REGRAS RÍGIDAS DE ANATOMIA VIRAL:
1. DURAÇÃO: Cada corte DEVE ter entre 25 e 55 segundos (sweet spot 30-50s para retenção máxima, permitindo até 70s apenas se indispensável para concluir o raciocínio).
2. HOOK (0s-1.5s): O primeiro segundo DEVE prender o espectador com uma fala chocante, pergunta intrigante ou grito/reação. O scroll para nos primeiros 1.5 segundos.
3. DESFECHO COMPLETO: O corte DEVE ter um desfecho claro (a piada, a revelação, a conclusão do raciocínio ou o grito final). NUNCA interrompa o streamer no meio da frase.
4. HEADLINE OVERLAY: Gere uma manchete chamativa em letras maiúsculas para sobrepor no topo do vídeo estilo TikTok (ex: "🔥 ELE NÃO ACREDITOU NISSO", "😱 A MAIOR JOGADA DA LIVE").
5. PONTUAÇÃO VIRAL: Atribua uma nota REALISTA de 1 a 10.

CRITÉRIOS PARA PONTUAÇÃO (scoring):
- forca_hook (1-10): O quão magnético é o início? 10 = frase que para o scroll imediatamente
- intensidade_emocional (1-10): Quão forte é a emoção? 10 = grito, rage extremo, risada histérica
- compartilhabilidade (1-10): Alguém enviaria para um amigo? 10 = "olha isso!" imperdível
- potencial_debate (1-10): Geraria comentários/argumentos? 10 = hot take controverso

REGRAS DE OURO:
- NUNCA selecione timestamps que não existem na transcrição
- NUNCA corte no meio de um diálogo ou raciocínio: finalize sempre na pausa ou término da frase
- NUNCA selecione momentos com apenas silêncio ou barulho de fundo
- PREFIRA momentos com falas claras e emoção detectável
- Se não encontrar nenhum momento viral, retorne um array vazio []

RETORNE EXCLUSIVAMENTE UM ARRAY JSON VÁLIDO. SEM TEXTO ANTES OU DEPOIS."""

    @staticmethod
    def prompt_analise_completa(texto_transcricao, metadados_resumo="", topico_detectado="HIBRIDO"):
        """Prompt cirúrgico otimizado para resposta rápida e precisa em 9B."""
        return f"""Analise a transcrição abaixo e selecione os MELHORES CORTES VIRAIS.
Cada corte deve ter entre 25 e 55 segundos de duração (concluindo o raciocínio completo).

METADADOS DETECTADOS AUTOMATICAMENTE:
{metadados_resumo}

TRANSCRICAO DA LIVE COM TIMESTAMPS (use APENAS timestamps que existem aqui):
{texto_transcricao}

INSTRUÇÕES:
1. Identifique os momentos de maior pico emocional e engajamento.
2. Defina tempo_inicio e tempo_fim exatos (formato HH:MM:SS ou MM:SS).
3. Crie uma HEADLINE chamativa em caixa alta (ex: "🔥 O STREAMER ENLOUQUECEU AO VIVO").
4. Atribua notas de scoring (1 a 10) para cada critério.

FORMATO DE RESPOSTA (ARRAY JSON PURO):
[
  {{
    "titulo_viral": "NOME_DO_CORTE",
    "headline_overlay": "🔥 MANCHETE CHAMATIVA EM MAIÚSCULAS",
    "hook": "Primeira frase que para o scroll",
    "tempo_inicio": "00:01:23",
    "tempo_fim": "00:02:05",
    "categoria": "RAGE",
    "pontuacao_viral": 9,
    "motivo": "Streamer tiltou após perder o item raro",
    "scoring": {{
      "forca_hook": 8,
      "intensidade_emocional": 9,
      "compartilhabilidade": 8,
      "potencial_debate": 6
    }}
  }}
]

RETORNE APENAS O JSON:"""

    @staticmethod
    def prompt_fallback_simples(texto_transcricao):
        """Prompt simplificado com scoring dimensional para quando o prompt principal falha."""
        return f"""Encontre o melhor momento viral nesta transcrição (duração ideal: 30-55 segundos).

TRANSCRICAO:
{texto_transcricao}

Retorne JSON com APENAS 1 corte no formato:
[
  {{
    "titulo_viral": "TITULO_CHAMATIVO",
    "headline_overlay": "🔥 MANCHETE DO TOPO EM MAIÚSCULAS",
    "tempo_inicio": "HH:MM:SS",
    "tempo_fim": "HH:MM:SS",
    "pontuacao_viral": 7,
    "categoria": "VIRAL",
    "motivo": "Momento de maior retenção da live",
    "scoring": {{
      "forca_hook": 7,
      "intensidade_emocional": 7,
      "compartilhabilidade": 7,
      "potencial_debate": 6
    }}
  }}
]

JSON:"""
