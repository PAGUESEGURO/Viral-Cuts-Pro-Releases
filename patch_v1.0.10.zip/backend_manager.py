import json
import threading
import importlib
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

from backends.base import AIBackend
# Backends NÃO são importados aqui — são carregados sob demanda em _get_backend_instancia()

CONFIG_PATH = Path(__file__).parent / "config_backends.json"


class BackendManager:
    """
    Gerenciador Central de Backends de IA (Singleton Thread-Safe).
    Detecta, persiste configurações e instancia clientes OpenAI-compatíveis.
    Backends são instanciados sob demanda (lazy) para economizar RAM e tempo de startup.
    """
    _instance: Optional['BackendManager'] = None
    _lock = threading.Lock()

    # Registro de classes de backend em ordem de prioridade (local antes de cloud)
    _BACKEND_CLASSES = [
        ("Ollama",      "backends.ollama",      "OllamaBackend"),
        ("LM Studio",   "backends.lmstudio",    "LMStudioBackend"),
        ("Groq",        "backends.groq",         "GroqBackend"),
        ("OpenRouter",  "backends.openrouter",   "OpenRouterBackend"),
    ]

    def __new__(cls) -> 'BackendManager':
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(BackendManager, cls).__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if getattr(self, '_initialized', False):
            return

        self._initialized = True
        self._backends_cache: dict[str, AIBackend] = {}   # lazy: instanciados ao solicitar
        self.config: Dict[str, Any] = self._carregar_config()

    def _get_backend_instancia(self, nome: str) -> Optional[AIBackend]:
        """Instancia (e cacheia) um backend pelo nome, de forma lazy."""
        nome_lower = nome.lower().replace(" ", "")
        for (reg_nome, modulo, classe) in self._BACKEND_CLASSES:
            if reg_nome.lower().replace(" ", "") == nome_lower:
                if reg_nome not in self._backends_cache:
                    try:
                        mod = importlib.import_module(modulo)
                        cls_obj = getattr(mod, classe)
                        self._backends_cache[reg_nome] = cls_obj()
                    except Exception as e:

                        print(f"[BackendManager] Falha ao instanciar {reg_nome}: {e}")
                        return None
                return self._backends_cache[reg_nome]
        return None

    def _get_todos_backends(self) -> list[AIBackend]:
        """Instancia todos os backends registrados (lazy, sob demanda)."""
        result = []
        for (nome, _, _) in self._BACKEND_CLASSES:
            b = self._get_backend_instancia(nome)
            if b:
                result.append(b)
        return result



    def normalizar_url(self, url: str) -> str:
        """Sanitiza e normaliza URLs garantindo protocolo http(s) e terminação /v1."""
        if not url or not isinstance(url, str):
            return "http://localhost:1234/v1"

        u = url.strip().rstrip("/")
        if not u.startswith(("http://", "https://")):
            u = f"http://{u}"

        if not u.endswith("/v1"):
            u = f"{u}/v1"

        return u

    def detectar_todos(self) -> Dict[str, Dict[str, Any]]:
        """Executa detecção em todos os backends (instanciando-os sob demanda)."""
        resultados = {}
        for b in self._get_todos_backends():
            try:
                info = b.detectar()
                resultados[b.nome] = {
                    "tipo": b.tipo,
                    "icone": b.icone,
                    "cor": b.cor,
                    "descricao_ajuda": b.descricao_ajuda,
                    "disponivel": bool(info.get("disponivel", False)),
                    "modelos": info.get("modelos", []),
                    "detalhes": str(info.get("detalhes", ""))
                }
            except Exception as e:
                resultados[b.nome] = {
                    "tipo": b.tipo,
                    "icone": b.icone,
                    "cor": b.cor,
                    "descricao_ajuda": b.descricao_ajuda,
                    "disponivel": False,
                    "modelos": [],
                    "detalhes": f"Erro de detecção: {e}"
                }
        return resultados

    def detectar_backend(self, nome: str) -> Dict[str, Any]:
        """Detecta disponibilidade de um backend específico (sem varrer todos)."""
        b = self._get_backend_instancia(nome)
        if not b:
            return {"disponivel": False, "modelos": [], "detalhes": f"Backend '{nome}' não encontrado"}
        try:
            info = b.detectar()
            return {
                "tipo": b.tipo,
                "icone": b.icone,
                "cor": b.cor,
                "disponivel": bool(info.get("disponivel", False)),
                "modelos": info.get("modelos", []),
                "detalhes": str(info.get("detalhes", ""))
            }
        except Exception as e:
            return {"disponivel": False, "modelos": [], "detalhes": f"Erro: {e}"}

    def get_backend(self, nome: str) -> Optional[AIBackend]:
        """Obtém objeto backend pelo nome (lazy instantiation)."""
        return self._get_backend_instancia(nome)

    def criar_cliente(self, nome_backend: str) -> Tuple[Any, Optional[str]]:
        """
        Cria um cliente OpenAI-compatível para o backend informado.
        Retorna (cliente, None) ou (None, mensagem_de_erro).
        """
        backend = self.get_backend(nome_backend)
        if not backend:
            return None, f"Backend '{nome_backend}' não suportado pelo sistema."

        cfg = self.config.get("backends", {}).get(backend.nome, {})
        url = self.normalizar_url(cfg.get("url", backend.get_url_padrao()))
        api_key = cfg.get("api_key", "")
        modelo = cfg.get("modelo", "")

        try:
            cliente = backend.criar_cliente(url=url, api_key=api_key, modelo=modelo)
            return cliente, None
        except Exception as e:
            return None, str(e)

    def testar_conexao(
        self,
        nome_backend: str,
        url: Optional[str] = None,
        api_key: Optional[str] = None,
        modelo: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Executa um teste REAL de conectividade com o backend via requisição de rede.
        Retorna (sucesso: bool, mensagem_detalhes: str).
        """
        backend = self.get_backend(nome_backend)
        if not backend:
            return False, f"Backend '{nome_backend}' não suportado pelo sistema."

        cfg = self.config.get("backends", {}).get(backend.nome, {})
        url_efetiva = self.normalizar_url(url or cfg.get("url", backend.get_url_padrao()))
        api_key_efetiva = (api_key if api_key is not None else cfg.get("api_key", "")).strip()
        modelo_efetivo = (modelo if modelo is not None else cfg.get("modelo", "")).strip()

        # 1. Backends Locais (LM Studio, Ollama)
        if backend.tipo == "local":
            import requests
            url_test = url_efetiva.rstrip("/")
            if not url_test.endswith("/v1"):
                url_test_models = f"{url_test}/v1/models"
            else:
                url_test_models = f"{url_test}/models"

            try:
                r = requests.get(url_test_models, timeout=3.0)
                if r.status_code == 200:
                    dados = r.json()
                    lista = dados.get("data", []) if isinstance(dados, dict) else []
                    modelos_nomes = [m.get("id", "") for m in lista if isinstance(m, dict) and m.get("id")]
                    if modelos_nomes:
                        return True, f"Servidor {nome_backend} online e respondendo!\n{len(modelos_nomes)} modelo(s) pronto(s) na memória."
                    return True, f"Servidor {nome_backend} online!\nNenhum modelo carregado na memória do LM Studio."
                else:
                    return False, f"Servidor respondeu com código HTTP {r.status_code} ao consultar modelos."
            except (requests.exceptions.ConnectionError, requests.exceptions.ConnectTimeout):
                if backend.nome == "LM Studio":
                    return False, "LM Studio está fechado ou o servidor local não foi iniciado.\nAbra o LM Studio, vá na aba '<-> Local Server' e clique em 'Start Server'."
                elif backend.nome == "Ollama":
                    return False, "Ollama não está em execução.\nInicie o Ollama pelo aplicativo ou terminal ('ollama serve')."
                return False, f"Não foi possível conectar ao endereço {url_test} (Servidor offline)."
            except requests.exceptions.Timeout:
                return False, f"Tempo limite esgotado ao tentar conectar com {nome_backend} em {url_test}."
            except Exception as e:
                return False, f"Erro ao testar conexão: {e}"

        # 2. Backends Cloud (Groq, OpenRouter)
        else:
            if not api_key_efetiva:
                return False, f"A chave de API (API Key) para {nome_backend} é obrigatória e não foi preenchida."

            try:
                cliente = backend.criar_cliente(url=url_efetiva, api_key=api_key_efetiva, modelo=modelo_efetivo)
                # Chamada real de teste para validar credencial
                cliente.models.list()
                return True, f"Chave de API do {nome_backend} validada com sucesso!\nConexão ativa com o provedor."
            except Exception as e_cloud:
                msg_erro = str(e_cloud)
                if "401" in msg_erro or "invalid_api_key" in msg_erro or "Authentication" in msg_erro:
                    return False, f"Chave de API inválida ou expirada para {nome_backend}.\nVerifique a chave cadastrada."
                return False, f"Falha ao validar conexão com {nome_backend}:\n{msg_erro}"

    def get_backend_preferido(self) -> str:
        return self.config.get("backend_preferido", "LM Studio")

    def set_backend_preferido(self, nome: str):
        self.config["backend_preferido"] = nome
        self.salvar_config()

    def get_config_backend(self, nome: str) -> Dict[str, Any]:
        backend = self.get_backend(nome)
        chave = backend.nome if backend else nome
        return self.config.get("backends", {}).get(chave, {})

    def set_config_backend(self, nome: str, cfg: Dict[str, Any]):
        backend = self.get_backend(nome)
        chave = backend.nome if backend else nome
        if "backends" not in self.config:
            self.config["backends"] = {}
        self.config["backends"][chave] = cfg
        self.salvar_config()

    def is_onboarding_completo(self) -> bool:
        return bool(self.config.get("onboarding_completo", False))

    def marcar_onboarding_completo(self):
        self.config["onboarding_completo"] = True
        self.salvar_config()

    def redefinir_config(self):
        """Reseta as configurações para o estado original de fábrica."""
        self.config = self._config_padrao()
        self.salvar_config()

    def salvar_config(self):
        """Salva arquivo de configuração com atomicidade e encoding UTF-8."""
        tmp_p = CONFIG_PATH.parent / f"{CONFIG_PATH.name}.tmp"
        try:
            CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp_p, "w", encoding="utf-8") as f_tmp:
                json.dump(self.config, f_tmp, indent=2, ensure_ascii=False)
                f_tmp.flush()
                import os
                os.fsync(f_tmp.fileno())
            try:
                tmp_p.replace(CONFIG_PATH)
            except (PermissionError, OSError):
                import time, shutil
                time.sleep(0.05)
                shutil.copy2(tmp_p, CONFIG_PATH)
                tmp_p.unlink(missing_ok=True)
        except Exception as e:
            try:
                with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                    json.dump(self.config, f, indent=2, ensure_ascii=False)
            except Exception as e2:
                print(f"[BackendManager] Erro fatal ao salvar config: {e2}")
            if tmp_p.exists():
                tmp_p.unlink(missing_ok=True)

    def _carregar_config(self) -> Dict[str, Any]:
        """Carrega o JSON de configuração com tolerância a arquivos corrompidos."""
        if CONFIG_PATH.exists():
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    dados = json.load(f)
                    if isinstance(dados, dict) and "backends" in dados:
                        return dados
            except Exception as e:
                print(f"[BackendManager] Config corrompida ou inválida ({e}), restaurando padrão.")

        cfg = self._config_padrao()
        self.config = cfg
        self.salvar_config()
        return cfg

    @staticmethod
    def _config_padrao() -> Dict[str, Any]:
        return {
            "backend_preferido": "LM Studio",
            "onboarding_completo": False,
            "backends": {
                "Ollama": {
                    "url": "http://localhost:11434/v1",
                    "modelo": "qwen2.5:7b",
                    "api_key": "ollama"
                },
                "LM Studio": {
                    "url": "http://localhost:1234/v1",
                    "modelo": "qwen3.5-9b.gguf",
                    "api_key": "lm-studio"
                },
                "Groq": {
                    "url": "https://api.groq.com/openai/v1",
                    "modelo": "qwen-2.5-32b",
                    "api_key": ""
                },
                "OpenRouter": {
                    "url": "https://openrouter.ai/api/v1",
                    "modelo": "qwen/qwen-2.5-32b",
                    "api_key": ""
                }
            }
        }
