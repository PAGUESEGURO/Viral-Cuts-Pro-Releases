import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from typing import Optional, Callable

from backend_manager import BackendManager
import ollama_installer


class OnboardingWizard:
    """
    Wizard de Primeiro Acesso e Configuração de IA (Janela Toplevel Premium).
    Permite escolher e testar Ollama, LM Studio, Groq ou OpenRouter de forma guiada.
    """

    BG_DARK = "#0b0f19"
    CARD_BG = "#151c2c"
    BORDER_CLR = "#2a364f"
    CYAN_ACCENT = "#38bdf8"
    SUCCESS = "#4ade80"
    WARNING = "#facc15"
    DANGER = "#f87171"

    def __init__(
        self,
        root: tk.Toplevel,
        manager: Optional[BackendManager] = None,
        callback_finalizar: Optional[Callable[[str], None]] = None,
        on_concluido: Optional[Callable[[], None]] = None
    ):
        self.root = root
        self.manager = manager or BackendManager()
        self.callback = callback_finalizar
        self.on_concluido = on_concluido

        self.root.title("⚡ Configuração Inicial — Viral Cuts Pro")
        self.root.geometry("820x680")
        self.root.minsize(780, 640)
        self.root.configure(bg=self.BG_DARK)

        # Estilos customizados para o tema escuro do onboarding
        style = ttk.Style()
        style.configure(
            "Onb.TButton",
            font=("Segoe UI", 10, "bold"),
            background="#334155",
            foreground="#f8fafc",
            borderwidth=0,
            padding=(14, 8)
        )
        style.map(
            "Onb.TButton",
            background=[("active", "#475569"), ("disabled", "#1e293b")],
            foreground=[("disabled", "#64748b"), ("active", "#ffffff")]
        )

        style.configure(
            "OnbPrimary.TButton",
            font=("Segoe UI", 10, "bold"),
            background="#0284c7",
            foreground="#ffffff",
            borderwidth=0,
            padding=(14, 8)
        )
        style.map(
            "OnbPrimary.TButton",
            background=[("active", "#0369a1"), ("disabled", "#1e293b")],
            foreground=[("disabled", "#64748b"), ("active", "#ffffff")]
        )

        # Blindagem #1 & #6: Tratar fechamento da janela (X)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close_seguro)

        self.step = 1
        self.total_steps = 4
        self.backend_selecionado = self.manager.get_backend_preferido()
        self.status_backends = {}
        self.api_key_visivel = False

        # Variáveis do formulário
        self.var_url = tk.StringVar(value="")
        self.var_modelo = tk.StringVar(value="")
        self.var_api_key = tk.StringVar(value="")

        self._center_window()
        self._setup_ui_structure()
        self._carregar_dados_iniciais()
        self._render_step()

    def _center_window(self):
        self.root.update_idletasks()
        w, h = 820, 680
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x = max(0, (sw - w) // 2)
        y = max(0, (sh - h) // 2)
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def _setup_ui_structure(self):
        # 1. Header Fixo no Topo
        self.header_frame = tk.Frame(self.root, bg=self.CARD_BG, height=75)
        self.header_frame.pack(fill="x", side="top", padx=15, pady=(15, 8))

        lbl_logo = tk.Label(self.header_frame, text="⚡", font=("Segoe UI", 24), bg=self.CARD_BG, fg=self.CYAN_ACCENT)
        lbl_logo.pack(side="left", padx=(15, 10), pady=10)

        header_text = tk.Frame(self.header_frame, bg=self.CARD_BG)
        header_text.pack(side="left", fill="y", pady=12)

        tk.Label(header_text, text="VIRAL CUTS PRO — ASSISTENTE DE IA", font=("Segoe UI", 13, "bold"), bg=self.CARD_BG, fg=self.CYAN_ACCENT).pack(anchor="w")
        self.lbl_subtitulo = tk.Label(header_text, text="Configuração guiada do motor de inteligência artificial", font=("Segoe UI", 9), bg=self.CARD_BG, fg="#cbd5e1")
        self.lbl_subtitulo.pack(anchor="w")

        # 2. Rodapé Fixo no Fundo (Botões nativos tk.Button para contraste impecável em qualquer tema Windows)
        self.footer_frame = tk.Frame(self.root, bg=self.CARD_BG, height=60)
        self.footer_frame.pack(fill="x", side="bottom", padx=15, pady=(8, 15))

        self.btn_pular = tk.Button(
            self.footer_frame,
            text="Pular (Usar Padrão)",
            font=("Segoe UI", 9),
            bg="#1e293b",
            fg="#cbd5e1",
            activebackground="#334155",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=14,
            pady=8,
            cursor="hand2",
            command=self._on_close_seguro
        )
        self.btn_pular.pack(side="left", padx=15, pady=12)

        self.btn_proximo = tk.Button(
            self.footer_frame,
            text="Próximo →",
            font=("Segoe UI", 10, "bold"),
            bg="#0284c7",
            fg="#ffffff",
            activebackground="#0369a1",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=18,
            pady=8,
            cursor="hand2",
            command=self._avancar_etapa
        )
        self.btn_proximo.pack(side="right", padx=15, pady=12)

        self.btn_voltar = tk.Button(
            self.footer_frame,
            text="← Voltar",
            font=("Segoe UI", 10, "bold"),
            bg="#334155",
            fg="#f8fafc",
            activebackground="#475569",
            activeforeground="#ffffff",
            disabledforeground="#475569",
            bd=0,
            relief="flat",
            padx=14,
            pady=8,
            cursor="hand2",
            command=self._voltar_etapa
        )
        self.btn_voltar.pack(side="right", padx=5, pady=12)

        # 3. Barra de Progresso de Etapas
        self.progress_frame = tk.Frame(self.root, bg=self.BG_DARK)
        self.progress_frame.pack(fill="x", padx=25, pady=4)

        self.lbl_step_indicator = tk.Label(self.progress_frame, text="Etapa 1 de 4: Seleção do Backend", font=("Segoe UI", 10, "bold"), bg=self.BG_DARK, fg=self.CYAN_ACCENT)
        self.lbl_step_indicator.pack(anchor="w", pady=(0, 4))

        self.step_progress = ttk.Progressbar(self.progress_frame, maximum=4, value=1)
        self.step_progress.pack(fill="x")

        # 4. Área Central Dinâmica (Preenche o espaço restante com folga total)
        self.content_frame = tk.Frame(self.root, bg=self.BG_DARK)
        self.content_frame.pack(fill="both", expand=True, padx=25, pady=10)

    def _carregar_dados_iniciais(self):
        backend = self.manager.get_backend(self.backend_selecionado)
        cfg = self.manager.get_config_backend(self.backend_selecionado)
        url_padrao = backend.get_url_padrao() if backend else "http://26.242.55.50:1234/v1"
        url_salva = cfg.get("url", "")
        if not url_salva or url_salva == "http://localhost:1234/v1":
            url_salva = url_padrao
        self.var_url.set(url_salva)
        self.var_modelo.set(cfg.get("modelo", "") or (backend.get_modelos_recomendados()[0] if backend and backend.get_modelos_recomendados() else "qwen3.5-9b.gguf"))
        self.var_api_key.set(cfg.get("api_key", ""))

    def _render_step(self):
        # Limpar área de conteúdo dinâmico
        for w in self.content_frame.winfo_children():
            w.destroy()

        self.step_progress["value"] = self.step
        if self.step > 1:
            self.btn_voltar.config(state="normal", bg="#334155", fg="#f8fafc")
        else:
            self.btn_voltar.config(state="disabled", bg="#1e293b", fg="#475569")

        if self.step == 1:
            self.lbl_step_indicator.config(text="Etapa 1 de 4: Escolha o Motor de IA")
            self.btn_proximo.config(text="Próximo →", state="normal", bg="#0284c7")
            self._render_etapa_selecao()
        elif self.step == 2:
            self.lbl_step_indicator.config(text=f"Etapa 2 de 4: Configurar {self.backend_selecionado}")
            self.btn_proximo.config(text="Próximo →", state="normal", bg="#0284c7")
            self._render_etapa_configuracao()
        elif self.step == 3:
            self.lbl_step_indicator.config(text="Etapa 3 de 4: Teste de Conectividade")
            self.btn_proximo.config(text="Validar Conexão", state="normal", bg="#0284c7")
            self._render_etapa_teste()
        elif self.step == 4:
            self.lbl_step_indicator.config(text="Etapa 4 de 4: Conclusão")
            self.btn_proximo.config(text="🚀 Iniciar Viral Cuts Pro", state="normal", bg="#16a34a")
            self._render_etapa_conclusao()

    def _render_etapa_selecao(self):
        tk.Label(self.content_frame, text="Selecione como deseja rodar a Inteligência Artificial:", font=("Segoe UI", 11, "bold"), bg=self.BG_DARK, fg="#f8fafc").pack(anchor="w", pady=(0, 10))

        # Detecção rápida em background
        if not self.status_backends:
            self.status_backends = self.manager.detectar_todos()

        for b in self.manager._get_todos_backends():
            info = self.status_backends.get(b.nome, {})
            selecionado = (self.backend_selecionado == b.nome)
            border = self.CYAN_ACCENT if selecionado else self.BORDER_CLR

            card = tk.Frame(self.content_frame, bg=self.CARD_BG, highlightbackground=border, highlightthickness=2, cursor="hand2")
            card.pack(fill="x", pady=4, ipady=6)

            h_frame = tk.Frame(card, bg=self.CARD_BG)
            h_frame.pack(fill="x", padx=12, pady=(6, 2))

            # Radio & Titulo
            tk.Label(h_frame, text=f"{b.icone} {b.nome}", font=("Segoe UI", 11, "bold"), bg=self.CARD_BG, fg="#ffffff").pack(side="left")

            # Tag Local / Cloud
            tipo_bg = "#064e3b" if b.tipo == "local" else "#7c2d12"
            tipo_fg = "#34d399" if b.tipo == "local" else "#fb923c"
            tk.Label(h_frame, text=f" {b.tipo.upper()} ", font=("Segoe UI", 8, "bold"), bg=tipo_bg, fg=tipo_fg).pack(side="left", padx=8)

            # Botão Tooltip de Ajuda ❓ (Blindagem #7)
            btn_ajuda = tk.Button(
                h_frame,
                text="❓",
                font=("Segoe UI", 9, "bold"),
                bg="#334155",
                fg="#f8fafc",
                activebackground="#475569",
                activeforeground="#ffffff",
                relief="flat",
                bd=0,
                padx=6,
                pady=1,
                cursor="hand2",
                command=lambda desc=b.descricao_ajuda, n=b.nome: messagebox.showinfo(f"Sobre {n}", desc)
            )
            btn_ajuda.pack(side="right", padx=4)

            # Status de detecção
            disp = info.get("disponivel", False)
            det = info.get("detalhes", "")
            st_fg = self.SUCCESS if disp else self.WARNING
            st_icon = "● Conectado / Disponível" if disp else "○ Não detectado no momento"

            sub_frame = tk.Frame(card, bg=self.CARD_BG)
            sub_frame.pack(fill="x", padx=12, pady=(0, 4))
            tk.Label(sub_frame, text=f"{st_icon} — {det}", font=("Segoe UI", 9), bg=self.CARD_BG, fg=st_fg).pack(anchor="w")


            def _bind_click(widget, nome=b.nome):
                widget.bind("<Button-1>", lambda e: self._selecionar_backend_card(nome))
                for child in widget.winfo_children():
                    if child != btn_ajuda:
                        _bind_click(child, nome)

            _bind_click(card, b.nome)

    def _selecionar_backend_card(self, nome: str):
        self.backend_selecionado = nome
        self._carregar_dados_iniciais()
        self._render_step()

    def _render_etapa_configuracao(self):
        backend = self.manager.get_backend(self.backend_selecionado)
        if not backend:
            return

        box = tk.Frame(self.content_frame, bg=self.CARD_BG, highlightbackground=self.BORDER_CLR, highlightthickness=1)
        box.pack(fill="x", pady=5, padx=5, ipady=10)

        # Informações e Download se for Ollama
        if backend.nome == "Ollama":
            instalado = ollama_installer.verificar_ollama_instalado()
            if not instalado:
                aviso = tk.Frame(box, bg="#451a03", highlightbackground="#b45309", highlightthickness=1)
                aviso.pack(fill="x", padx=15, pady=(5, 10), ipady=6)
                tk.Label(aviso, text="⚠️ O Ollama ainda não foi detectado no seu Windows.", font=("Segoe UI", 9, "bold"), bg="#451a03", fg="#fef08a").pack(anchor="w", padx=10)
                
                self.lbl_ollama_prog = tk.Label(aviso, text="Clique abaixo para baixar e instalar automaticamente (~50MB):", font=("Segoe UI", 8), bg="#451a03", fg="#fde047")
                self.lbl_ollama_prog.pack(anchor="w", padx=10, pady=(2, 4))

                self.btn_auto_ollama = tk.Button(
                    aviso,
                    text="📥 Baixar e Instalar Ollama Automaticamente",
                    font=("Segoe UI", 9, "bold"),
                    bg="#0284c7",
                    fg="#ffffff",
                    activebackground="#0369a1",
                    activeforeground="#ffffff",
                    bd=0,
                    relief="flat",
                    padx=12,
                    pady=6,
                    cursor="hand2",
                    command=self._iniciar_download_ollama
                )
                self.btn_auto_ollama.pack(anchor="w", padx=10, pady=4)

        # Header URL com atalhos de clique rápido
        f_url_header = tk.Frame(box, bg=self.CARD_BG)
        f_url_header.pack(fill="x", padx=15, pady=(8, 2))
        tk.Label(f_url_header, text="URL do Endpoint API:", font=("Segoe UI", 9, "bold"), bg=self.CARD_BG, fg="#f8fafc").pack(side="left")

        if backend.nome == "LM Studio":
            btn_rede = tk.Button(
                f_url_header,
                text="⚡ Usar 26.242.55.50:1234",
                font=("Segoe UI", 8),
                bg="#064e3b",
                fg="#34d399",
                activebackground="#065f46",
                activeforeground="#ffffff",
                bd=0,
                relief="flat",
                padx=6,
                pady=1,
                cursor="hand2",
                command=lambda: self.var_url.set("http://26.242.55.50:1234/v1")
            )
            btn_rede.pack(side="right", padx=2)

            btn_local = tk.Button(
                f_url_header,
                text="💻 Usar localhost:1234",
                font=("Segoe UI", 8),
                bg="#1e293b",
                fg="#94a3b8",
                activebackground="#334155",
                activeforeground="#ffffff",
                bd=0,
                relief="flat",
                padx=6,
                pady=1,
                cursor="hand2",
                command=lambda: self.var_url.set("http://localhost:1234/v1")
            )
            btn_local.pack(side="right", padx=2)

        ent_url = ttk.Entry(box, textvariable=self.var_url)
        ent_url.pack(fill="x", padx=15, pady=(0, 8))

        tk.Label(box, text="Modelo de IA:", font=("Segoe UI", 9, "bold"), bg=self.CARD_BG, fg="#f8fafc").pack(anchor="w", padx=15, pady=(4, 2))
        cb_mod = ttk.Combobox(box, textvariable=self.var_modelo, values=backend.get_modelos_recomendados())
        cb_mod.pack(fill="x", padx=15, pady=(0, 8))

        if backend.tipo == "cloud":
            tk.Label(box, text="Chave de API (API Key):", font=("Segoe UI", 9, "bold"), bg=self.CARD_BG, fg="#f8fafc").pack(anchor="w", padx=15, pady=(4, 2))
            
            f_key = tk.Frame(box, bg=self.CARD_BG)
            f_key.pack(fill="x", padx=15, pady=(0, 8))

            self.ent_key = ttk.Entry(f_key, textvariable=self.var_api_key, show="*" if not self.api_key_visivel else "")
            self.ent_key.pack(side="left", fill="x", expand=True)

            btn_eye = tk.Button(
                f_key,
                text="👁️" if not self.api_key_visivel else "🙈",
                font=("Segoe UI", 9),
                bg="#334155",
                fg="#ffffff",
                activebackground="#475569",
                activeforeground="#ffffff",
                bd=0,
                relief="flat",
                padx=8,
                pady=2,
                cursor="hand2",
                command=self._toggle_eye
            )
            btn_eye.pack(side="right", padx=(6, 0))

    def _toggle_eye(self):
        self.api_key_visivel = not self.api_key_visivel
        self._render_step()

    def _iniciar_download_ollama(self):
        self.btn_auto_ollama.config(state="disabled")
        
        def _task():
            def _cb(pct, msg):
                if hasattr(self, 'lbl_ollama_prog') and self.lbl_ollama_prog.winfo_exists():
                    self.lbl_ollama_prog.config(text=msg)

            sucesso, msg_fim = ollama_installer.instalar_ollama_silencioso(_cb)
            if sucesso:
                messagebox.showinfo("Ollama", "Ollama instalado com sucesso! Agora você já pode utilizá-lo.")
                self.status_backends = self.manager.detectar_todos()
                self._render_step()
            else:
                messagebox.showerror("Erro no Download", f"Não foi possível instalar automaticamente:\n{msg_fim}\n\nVocê pode baixá-lo manualmente em ollama.com")
                if hasattr(self, 'btn_auto_ollama') and self.btn_auto_ollama.winfo_exists():
                    self.btn_auto_ollama.config(state="normal")

        threading.Thread(target=_task, daemon=True).start()

    def _render_etapa_teste(self):
        box = tk.Frame(self.content_frame, bg=self.CARD_BG, highlightbackground=self.BORDER_CLR, highlightthickness=1)
        box.pack(fill="both", expand=True, pady=10, padx=5, ipady=10)

        tk.Label(box, text=f"Testando conexão com {self.backend_selecionado}...", font=("Segoe UI", 11, "bold"), bg=self.CARD_BG, fg=self.CYAN_ACCENT).pack(pady=(15, 8))

        self.lbl_teste_resultado = tk.Label(box, text="Clique no botão abaixo para disparar o teste.", font=("Segoe UI", 10), bg=self.CARD_BG, fg="#94a3b8", wraplength=550)
        self.lbl_teste_resultado.pack(pady=10, padx=20)

        self._executar_teste_conexao()

    def _executar_teste_conexao(self):
        # Salvar valores atuais
        url_sanitizada = self.manager.normalizar_url(self.var_url.get())
        self.manager.set_config_backend(self.backend_selecionado, {
            "url": url_sanitizada,
            "modelo": self.var_modelo.get().strip(),
            "api_key": self.var_api_key.get().strip()
        })

        self.lbl_teste_resultado.config(text="🔌 Conectando e validando endpoint...", fg=self.WARNING)

        def _worker():
            sucesso, msg = self.manager.testar_conexao(
                self.backend_selecionado,
                url=url_sanitizada,
                api_key=self.var_api_key.get().strip(),
                modelo=self.var_modelo.get().strip()
            )
            if not sucesso:
                if self.lbl_teste_resultado.winfo_exists():
                    self.lbl_teste_resultado.config(
                        text=f"❌ Falha de Conexão:\n{msg}",
                        fg=self.DANGER
                    )
            else:
                if self.lbl_teste_resultado.winfo_exists():
                    self.lbl_teste_resultado.config(
                        text=f"✅ Conexão bem-sucedida com {self.backend_selecionado}!\n{msg}",
                        fg=self.SUCCESS
                    )

        threading.Thread(target=_worker, daemon=True).start()

    def _render_etapa_conclusao(self):
        box = tk.Frame(self.content_frame, bg=self.CARD_BG, highlightbackground=self.BORDER_CLR, highlightthickness=1)
        box.pack(fill="both", expand=True, pady=10, padx=5, ipady=15)

        tk.Label(box, text="🎉 Tudo Pronto para Cortar Seus Vídeos!", font=("Segoe UI", 14, "bold"), bg=self.CARD_BG, fg=self.SUCCESS).pack(pady=(15, 5))

        resumo = (
            f"• Backend Ativo: {self.backend_selecionado}\n"
            f"• URL: {self.var_url.get()}\n"
            f"• Modelo: {self.var_modelo.get()}\n\n"
            "Suas configurações foram salvas com sucesso. Você pode alterá-las a qualquer momento na aba '⚙️ Backend IA'."
        )

        tk.Label(box, text=resumo, font=("Segoe UI", 10), bg=self.CARD_BG, fg="#cbd5e1", justify="left").pack(pady=15, padx=30, anchor="w")

    def _avancar_etapa(self):
        if self.step == 2:
            # Salvar dados do step 2
            self.manager.set_config_backend(self.backend_selecionado, {
                "url": self.manager.normalizar_url(self.var_url.get()),
                "modelo": self.var_modelo.get().strip(),
                "api_key": self.var_api_key.get().strip()
            })

        if self.step < self.total_steps:
            self.step += 1
            self._render_step()
        else:
            self._finalizar()

    def _voltar_etapa(self):
        if self.step > 1:
            self.step -= 1
            self._render_step()

    def _finalizar(self):
        self.manager.set_backend_preferido(self.backend_selecionado)
        self.manager.marcar_onboarding_completo()
        if self.callback:
            try:
                self.callback(self.backend_selecionado)
            except TypeError:
                try:
                    self.callback()
                except Exception:
                    pass
            except Exception:
                pass
        if self.on_concluido:
            try:
                self.on_concluido()
            except Exception:
                pass
        self.root.destroy()

    def _on_close_seguro(self):
        """Blindagem #1 & #6: Fechamento seguro sem travar o aplicativo."""
        if not self.manager.is_onboarding_completo():
            # Assume LM Studio padrão sem quebrar a esteira
            self.manager.set_backend_preferido("LM Studio")
        if self.callback:
            try:
                self.callback(self.manager.get_backend_preferido())
            except TypeError:
                try:
                    self.callback()
                except Exception:
                    pass
            except Exception:
                pass
        if self.on_concluido:
            try:
                self.on_concluido()
            except Exception:
                pass
        self.root.destroy()
