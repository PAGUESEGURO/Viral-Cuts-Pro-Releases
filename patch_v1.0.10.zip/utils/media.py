import os
import sys
import shutil
from pathlib import Path
from typing import Optional, Callable

def verificar_espaco_em_disco(dir_alvo: Optional[Path] = None, log_fn: Optional[Callable] = None) -> bool:
    """Retorna False se houver menos de 1GB livre."""
    try:
        if dir_alvo is None:
            dir_alvo = Path.cwd()
        total, used, free = shutil.disk_usage(dir_alvo if Path(dir_alvo).exists() else Path.cwd())
        free_gb = free / (1024 ** 3)
        if free_gb < 1.0:
            msg = f"Apenas {free_gb:.2f} GB livres em disco! Libere espaço."
            if log_fn:
                log_fn(msg, "WARNING")
            print(f"ALERTA DE DISCO: {msg}")
            return False
        return True
    except Exception as e:
        if log_fn:
            log_fn(f"Erro ao verificar espaço em disco: {e}", "ERROR")
        return False


def encontrar_ffmpeg(dir_exe: Optional[Path] = None) -> Optional[str]:
    """Encontra ffmpeg.exe - prioriza pasta portátil ao lado do .exe ou do projeto."""
    if dir_exe is None:
        if getattr(sys, "frozen", False):
            dir_exe = Path(sys.executable).parent
        else:
            dir_exe = Path(__file__).parent.parent.resolve()

    ffmpeg_local = Path(dir_exe) / "ffmpeg" / "ffmpeg.exe"
    if ffmpeg_local.exists():
        return str(ffmpeg_local.parent)
    return None


def inicializar_ffmpeg() -> None:
    """Adiciona ffmpeg portátil ao PATH do processo se encontrado."""
    ffmpeg_dir = encontrar_ffmpeg()
    if ffmpeg_dir:
        os.environ["PATH"] = ffmpeg_dir + os.pathsep + os.environ.get("PATH", "")
