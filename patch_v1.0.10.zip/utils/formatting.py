from typing import Union

def formatar_tempo(segundos: Union[int, float]) -> str:
    """Converte segundos para formato HH:MM:SS."""
    try:
        s_float = float(segundos)
        hrs = int(s_float // 3600)
        mins = int((s_float % 3600) // 60)
        secs = int(s_float % 60)
        return f"{hrs:02d}:{mins:02d}:{secs:02d}"
    except Exception:
        return "00:00:00"


def tempo_para_segundos(tempo_str: Union[str, int, float]) -> float:
    """Converte HH:MM:SS, MM:SS ou segundos float para segundos totais em float."""
    try:
        t_clean = str(tempo_str).strip().replace(",", ".").replace("[", "").replace("]", "")
        partes = [float(p) for p in t_clean.split(":") if p]
        if len(partes) == 3:
            return partes[0] * 3600.0 + partes[1] * 60.0 + partes[2]
        elif len(partes) == 2:
            return partes[0] * 60.0 + partes[1]
        elif len(partes) == 1:
            return partes[0]
    except Exception:
        pass
    return 0.0


def estimar_tokens(texto: str) -> int:
    """Estima número de tokens em um texto (aproximação: 1 token ≈ 4 caracteres em PT-BR)."""
    if not texto:
        return 0
    return len(str(texto)) // 4
