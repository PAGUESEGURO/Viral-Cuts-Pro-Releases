"""
=============================================================================
VIRAL CUTS PRO - PACOTE DE UTILITÁRIOS MODULARES (SRP / SOLID)
Exporta todas as funções com retrocompatibilidade total.
=============================================================================
"""

from utils.logging import (
    SafeStreamWrapper,
    setup_safe_streams,
    log_debug
)

from utils.hash import (
    gerar_hash_video
)

from utils.formatting import (
    formatar_tempo,
    tempo_para_segundos,
    estimar_tokens
)

from utils.text import (
    corrigir_vocabulario_streamer,
    eh_linha_musica_ou_lixo
)

from utils.emotion import (
    detectar_emocao_fala,
    detectar_engajamento,
    detectar_tema,
    calcular_densidade_emocional
)

from utils.transcription import (
    truncar_transcript_inteligente,
    encontrar_inicio_frase,
    encontrar_fim_frase,
    encontrar_pausa_proxima
)

from utils.json_utils import (
    extrair_json_robusto
)

from utils.media import (
    encontrar_ffmpeg,
    inicializar_ffmpeg,
    verificar_espaco_em_disco
)

__all__ = [
    "SafeStreamWrapper",
    "setup_safe_streams",
    "log_debug",
    "gerar_hash_video",
    "formatar_tempo",
    "tempo_para_segundos",
    "estimar_tokens",
    "corrigir_vocabulario_streamer",
    "eh_linha_musica_ou_lixo",
    "detectar_emocao_fala",
    "detectar_engajamento",
    "detectar_tema",
    "calcular_densidade_emocional",
    "truncar_transcript_inteligente",
    "encontrar_inicio_frase",
    "encontrar_fim_frase",
    "encontrar_pausa_proxima",
    "extrair_json_robusto",
    "encontrar_ffmpeg",
    "inicializar_ffmpeg",
    "verificar_espaco_em_disco",
]
