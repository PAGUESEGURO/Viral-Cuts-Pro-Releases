import hashlib
from pathlib import Path

def gerar_hash_video(video_path: Path) -> str:
    """Gera um ID único e persistente baseado no nome, tamanho e data de modificação do arquivo."""
    try:
        p = Path(video_path)
        stat = p.stat()
        chave = f"{p.name}_{stat.st_size}_{stat.st_mtime}"
        return hashlib.md5(chave.encode("utf-8")).hexdigest()[:10]
    except Exception:
        return "default"
