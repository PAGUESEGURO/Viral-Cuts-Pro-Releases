import re
from typing import Dict, Any, List

def detectar_emocao_fala(texto: str) -> Dict[str, Any]:
    """
    Detecta emoção predominante em uma linha de transcrição.
    Retorna: {"tipo": str, "intensidade": int(1-10), "sinais": list}
    """
    if not texto:
        return {"tipo": "NEUTRO", "intensidade": 1, "sinais": []}

    t_str = str(texto).strip()
    t_lower = t_str.lower()
    sinais = []
    intensidade = 3

    num_exclamacoes = t_str.count("!")
    num_interrogacoes = t_str.count("?")
    palavras_caps = [w for w in t_str.split() if len(w) >= 3 and w.isupper()]
    tem_repeticao = any(t_lower.count(w) >= 3 for w in ["não", "mano", "cara", "porra", "caralho"])

    # RAGE / TILT / INDIGNAÇÃO
    palavras_rage_forte = ["desgraça", "filho da", "vai se f", "puta que", "caralho do", "roubado", "injustiça", "tilt", "morri de novo"]
    palavras_rage_media = ["droga", "merda", "porra", "caralho", "bosta", "impossível", "desisto"]
    tem_rage_forte = any(p in t_lower for p in palavras_rage_forte)
    tem_rage_media = any(p in t_lower for p in palavras_rage_media)
    
    score_rage = 0
    if tem_rage_forte:
        score_rage += 4
    if tem_rage_media:
        score_rage += 2
    if len(palavras_caps) >= 2:
        score_rage += 2
    if num_exclamacoes >= 2:
        score_rage += 1
    if tem_repeticao:
        score_rage += 1

    if score_rage >= 4:
        sinais.append("raiva_indignacao")
        intensidade = min(10, 4 + score_rage)
        return {"tipo": "RAGE", "intensidade": intensidade, "sinais": sinais}

    # HUMOR / MEME / RISOS
    tem_kkk = "kkk" in t_lower and len([c for c in t_lower if c == 'k']) >= 3
    tem_hahaha = "haha" in t_lower
    tem_risada = ["rsrs", "hahaha", "kkkk", "que burro", "troll", "zoeira", "me ferrei", "piada"]
    tem_humor_claro = any(p in t_lower for p in tem_risada)

    if tem_kkk or tem_hahaha or tem_humor_claro:
        sinais.append("humor_risada")
        num_k = len([c for c in t_lower if c == 'k'])
        intensidade = min(10, 6 + (2 if num_k >= 5 else 1))
        return {"tipo": "HILARIOUS", "intensidade": intensidade, "sinais": sinais}

    # SURPRESA / CHOQUE / HYPE
    palavras_hype = ["inacreditável", "não acredito", "meu deus", "olha essa jogada", "clutch", "ganhei", "salvei", "vencemos", "caraca", "eita", "uau"]
    tem_hype = any(p in t_lower for p in palavras_hype)
    if tem_hype or num_exclamacoes >= 2:
        sinais.append("choque_hype")
        intensidade = min(10, 5 + (3 if tem_hype else 1))
        return {"tipo": "HYPE", "intensidade": intensidade, "sinais": sinais}

    # POLÊMICA / OPINIÃO FORTE
    palavras_polemica = ["a verdade é que", "ninguém fala isso", "opinião sincera", "discordo totalmente", "hipocrisia", "o problema é que", "eu acho que todos"]
    tem_polemica = any(p in t_lower for p in palavras_polemica)
    if tem_polemica:
        sinais.append("polemica_debate")
        intensidade = 8
        return {"tipo": "HOT_TAKE", "intensidade": intensidade, "sinais": sinais}

    # INTERAÇÃO COM CHAT
    palavras_chat = ["chat", "vocês viram", "o que acham", "manda no chat", "comenta aí", "olha o donate"]
    tem_chat = any(p in t_lower for p in palavras_chat)
    if tem_chat and num_interrogacoes >= 1:
        sinais.append("interacao_pergunta")
        intensidade = 6
        return {"tipo": "INTERACAO", "intensidade": intensidade, "sinais": sinais}

    # NEUTRO com palavras caps
    if len(palavras_caps) >= 3:
        sinais.append("fala_acentuada")
        intensidade = 4
        return {"tipo": "HYPE", "intensidade": intensidade, "sinais": sinais}

    return {"tipo": "NEUTRO", "intensidade": 2, "sinais": []}


def detectar_engajamento(texto: str) -> Dict[str, Any]:
    """
    Detecta sinais de engajamento potencial em uma frase.
    Retorna: {"tipo": str, "forca": int(1-10)}
    """
    if not texto:
        return {"tipo": "PADRAO", "forca": 1}

    t_lower = str(texto).lower()

    if any(k in t_lower for k in ["vou contar um segredo", "a verdade oculta", "ninguém sabe disso", "vou revelar", "plot twist"]):
        return {"tipo": "REVELACAO_TEA", "forca": 9}

    if any(k in t_lower for k in ["comente sua opinião", "duvido você", "quem concorda", "discordo totalmente", "e vocês?"]):
        return {"tipo": "DEBATE_BAIT", "forca": 8}

    if any(k in t_lower for k in ["perdi tudo", "quase morri", "o maior erro da minha vida"]):
        return {"tipo": "RELATABLE_CHOCANTE", "forca": 9}

    if any(k in t_lower for k in ["clutch", "jogada épica", "extração", "sobrevivi", "vitória épica"]):
        return {"tipo": "HYPE_MOMENT", "forca": 8}

    if any(k in t_lower for k in ["que mico", "passei vergonha", "me humilharam", "fail épico"]):
        return {"tipo": "MEME_COMICO", "forca": 8}

    return {"tipo": "GERAL", "forca": 3}


def detectar_tema(texto: str) -> Dict[str, Any]:
    """
    Detecta tema / nicho predominante de um trecho.
    Retorna: {"topico": str, "subtopico": str, "confianca": float}
    """
    t_lower = str(texto).lower()
    
    termos_gaming = ["loot", "boss", "masmorra", "dungeon", "dark and darker", "arma", "kill", "pvp", "gameplay", "partida", "mira", "level", "fps", "drop", "cura", "poção", "bau", "extração", "sobrevivi", "morri", "morremos", "morreu"]
    termos_drama = ["fofoca", "treta", "cancelamento", "polêmica", "falou mal", "traição", "exposed", "mentira", "processo", "excluiu", "bloqueou"]
    termos_resenha = ["opinião", "achei bom", "não recomendo", "filme", "série", "música", "análise", "vale a pena", "testei", "conselho", "vida"]

    pontos_gaming = sum(2 if re.search(r'\b' + re.escape(t) + r'\b', t_lower) else 0 for t in termos_gaming)
    pontos_drama = sum(2 if re.search(r'\b' + re.escape(t) + r'\b', t_lower) else 0 for t in termos_drama)
    pontos_resenha = sum(2 if re.search(r'\b' + re.escape(t) + r'\b', t_lower) else 0 for t in termos_resenha)

    total = pontos_gaming + pontos_drama + pontos_resenha
    if total == 0:
        return {"topico": "HIBRIDO", "subtopico": "interacao_geral", "confianca": 0.3}

    conf_gaming = pontos_gaming / total if total > 0 else 0
    conf_drama = pontos_drama / total if total > 0 else 0
    conf_resenha = pontos_resenha / total if total > 0 else 0

    if pontos_gaming >= max(pontos_drama, pontos_resenha):
        return {"topico": "GAMING", "subtopico": "gameplay_clutch", "confianca": round(conf_gaming, 2)}
    elif pontos_drama >= max(pontos_gaming, pontos_resenha):
        return {"topico": "DRAMA", "subtopico": "fofoca_polemica", "confianca": round(conf_drama, 2)}
    else:
        return {"topico": "RESENHA", "subtopico": "opiniao_analise", "confianca": round(conf_resenha, 2)}


def calcular_densidade_emocional(transcricao_linhas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Calcula a densidade emocional ao longo da linha do tempo da transcrição.
    Retorna lista de segmentos de alta energia com seus timestamps.
    """
    if not transcricao_linhas:
        return []

    segmentos_alta_energia = []
    for item in transcricao_linhas:
        txt = item.get("texto", "")
        emocao = detectar_emocao_fala(txt)
        engaj = detectar_engajamento(txt)
        
        score_energia = (emocao["intensidade"] * 0.6) + (engaj["forca"] * 0.4)
        threshold = 5.0 if engaj["tipo"] in ["HYPE_MOMENT", "REVELACAO_TEA"] else 6.0
        
        if score_energia >= threshold:
            segmentos_alta_energia.append({
                "inicio": item.get("inicio", 0),
                "fim": item.get("fim", 0),
                "tempo_formatado": item.get("tempo_formatado", ""),
                "texto": txt,
                "emocao": emocao["tipo"],
                "engajamento": engaj["tipo"],
                "score_energia": round(score_energia, 1)
            })

    return segmentos_alta_energia
