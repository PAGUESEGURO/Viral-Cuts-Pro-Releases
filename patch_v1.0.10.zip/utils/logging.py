import sys
import time
from pathlib import Path

class SafeStreamWrapper:
    """Wrapper seguro para stdout/stderr que previne crash em ambientes frozen/exe."""

    def __init__(self, stream):
        self.stream = stream

    def write(self, text):
        if self.stream is not None:
            try:
                return self.stream.write(text)
            except Exception:
                pass
        return len(text) if text else 0

    def flush(self):
        if self.stream is not None:
            try:
                self.stream.flush()
            except Exception:
                pass

    def isatty(self):
        return False


def setup_safe_streams():
    """Configura stdout/stderr com SafeStreamWrapper e encoding UTF-8."""
    for attr in ("stdout", "stderr"):
        stream = getattr(sys, attr, None)
        if stream is None or not hasattr(stream, "write"):
            setattr(sys, attr, SafeStreamWrapper(None))
        else:
            try:
                if hasattr(stream, "reconfigure"):
                    stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass
            setattr(sys, attr, SafeStreamWrapper(stream))


def log_debug(mensagem: str, nivel: str = "INFO", arquivo_log=None):
    """Registra mensagens estruturadas no arquivo de log e força flush imediato."""
    if arquivo_log is None:
        return
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    linha = f"[{timestamp}] [{nivel}] {mensagem}\n"
    try:
        with open(arquivo_log, "a", encoding="utf-8") as f:
            f.write(linha)
            f.flush()
    except Exception:
        pass
