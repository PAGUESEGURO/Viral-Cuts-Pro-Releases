from typing import List, Dict, Any
from utils.formatting import estimar_tokens

def truncar_transcript_inteligente(texto: str, max_tokens: int = 2400) -> str:
    """
    Trunca transcript preservando linhas completas com timestamps.
    Retorna texto truncado que cabe no limite de tokens.
    """
    if not texto:
        return ""
    
    tokens_estimados = estimar_tokens(texto)
    if tokens_estimados <= max_tokens:
        return texto
    
    linhas = texto.strip().split("\n")
    linhas_validas = []
    tokens_acumulados = 0
    
    for linha in linhas:
        tokens_linha = estimar_tokens(linha)
        if tokens_acumulados + tokens_linha > max_tokens:
            break
        linhas_validas.append(linha)
        tokens_acumulados += tokens_linha
    
    return "\n".join(linhas_validas)


def encontrar_inicio_frase(transcricao_linhas: List[Dict[str, Any]], sec_alvo: float, margem_max: float = 4.0) -> float:
    """
    Encontra o início exato da frase que contém sec_alvo para evitar começar no meio de fala.
    """
    if not transcricao_linhas:
        return max(0.0, sec_alvo - 0.5)

    melhor_inicio = max(0.0, sec_alvo - 0.5)
    for i, item in enumerate(transcricao_linhas):
        st = item.get("inicio", 0)
        et = item.get("fim", 0)
        
        if st <= sec_alvo <= et:
            melhor_inicio = max(0.0, st - 0.3)
            break
        elif st > sec_alvo:
            if i > 0 and (sec_alvo - transcricao_linhas[i-1].get("fim", 0)) < margem_max:
                melhor_inicio = max(0.0, transcricao_linhas[i-1].get("inicio", 0) - 0.3)
            else:
                melhor_inicio = max(0.0, st - 0.3)
            break

    return melhor_inicio


def encontrar_fim_frase(transcricao_linhas: List[Dict[str, Any]], sec_alvo: float, duracao_max: float = 70.0, sec_inicio: float = 0.0) -> float:
    """
    Encontra o término natural de um raciocínio/fala sem cortar no meio de uma ideia.
    
    Lógica de conclusão de raciocínio:
    - Prioriza frases que terminam com pontuação terminal (., !, ?, ...)
    - Usa gap de silêncio como critério SECUNDÁRIO (só interrompe se frase anterior encerrou)
    - Se o raciocínio ainda flui (frase sem pontuação terminal + próxima fala logo em seguida),
      continua buscando o ponto de conclusão real
    - Respeita o limite de duracao_max
    """
    if not transcricao_linhas:
        return sec_alvo + 0.8

    sec_inicio_ref = sec_inicio if (sec_inicio is not None and sec_inicio > 0) else max(0.0, sec_alvo - 30.0)
    duracao_ate_agora = sec_alvo - sec_inicio_ref
    tempo_restante = duracao_max - duracao_ate_agora
    
    # Se já estamos perto do limite, retorna imediatamente
    if tempo_restante <= 3.0:
        return min(sec_inicio_ref + duracao_max, sec_alvo + 0.5)

    PONTUACAO_TERMINAL = ('.', '!', '?', '...', '…', '😂', '🤣', '🔥', '💀')
    GAP_CONCLUSAO = 1.8      # Gap mínimo para considerar fim de raciocínio
    GAP_FORCA_CORTE = 3.5    # Gap que força o corte mesmo sem pontuação terminal

    melhor_fim = sec_alvo + 0.8
    candidatos = []
    
    for i, item in enumerate(transcricao_linhas):
        st = item.get("inicio", 0)
        et = item.get("fim", 0)
        txt = str(item.get("texto", "")).strip()
        
        if et < sec_alvo - 2.0:
            continue
        
        dur_calculada = et - sec_inicio_ref
        if dur_calculada > duracao_max:
            break

        tem_pontuacao_terminal = txt.endswith(PONTUACAO_TERMINAL)
        
        gap_para_proxima = 0.0
        if i + 1 < len(transcricao_linhas):
            gap_para_proxima = transcricao_linhas[i + 1].get("inicio", 0) - et
        else:
            gap_para_proxima = 999.0
        
        if st >= sec_alvo - 2.0 or (st <= sec_alvo <= et):
            fim_candidato = min(sec_inicio_ref + duracao_max, et + 0.5)
            qualidade = 0
            
            if tem_pontuacao_terminal and gap_para_proxima >= GAP_CONCLUSAO:
                qualidade = 3
            elif tem_pontuacao_terminal:
                qualidade = 2
            elif gap_para_proxima >= GAP_FORCA_CORTE:
                qualidade = 1
            elif gap_para_proxima >= GAP_CONCLUSAO:
                qualidade = 0
            else:
                continue
            
            candidatos.append((qualidade, fim_candidato, i))
            if qualidade == 3:
                break

    if candidatos:
        candidatos.sort(key=lambda x: (-x[0], x[1]))
        melhor_fim = candidatos[0][1]
    
    return min(sec_inicio_ref + duracao_max, melhor_fim)


def encontrar_pausa_proxima(transcricao_linhas: List[Dict[str, Any]], sec_alvo: float, direcao: str = "depois", max_distancia: float = 12.0) -> float:
    """
    Localiza um momento de silêncio natural na transcrição próximo ao ponto desejado.
    """
    if not transcricao_linhas:
        return sec_alvo

    if direcao == "depois":
        for i in range(len(transcricao_linhas) - 1):
            fim_atual = transcricao_linhas[i].get("fim", 0)
            inicio_prox = transcricao_linhas[i+1].get("inicio", 0)
            if fim_atual >= sec_alvo:
                if fim_atual - sec_alvo > max_distancia:
                    break
                gap = inicio_prox - fim_atual
                if gap >= 1.2:
                    return max(sec_alvo, fim_atual + min(0.6, gap / 2.0))
    else:
        for i in range(len(transcricao_linhas) - 1, 0, -1):
            inicio_atual = transcricao_linhas[i].get("inicio", 0)
            fim_ant = transcricao_linhas[i-1].get("fim", 0)
            if inicio_atual <= sec_alvo:
                if sec_alvo - inicio_atual > max_distancia:
                    break
                gap = inicio_atual - fim_ant
                if gap >= 1.2:
                    return min(sec_alvo, inicio_atual - min(0.4, gap / 2.0))

    return sec_alvo
