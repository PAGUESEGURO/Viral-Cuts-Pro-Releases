import re
from typing import Optional, Set

def corrigir_vocabulario_streamer(texto: str) -> str:
    """
    Corrige erros ortográficos comuns, gaguejos, termos de gaming e expressões de stream
    que o Whisper frequentemente transcreve de forma distorcida.
    """
    if not texto or not isinstance(texto, str):
        return ""

    t = texto.strip()

    # 1. Remover gaguejos e repetições consecutivas (ex: "eu eu fui" -> "eu fui", "que que" -> "que")
    t = re.sub(r'\b(\w+)(?:\s+\1\b)+', r'\1', t, flags=re.IGNORECASE)

    # 2. Dicionário de correções contextuais para Streaming / Gaming / PT-BR
    substituicoes = [
        # Jogos e Streamers
        (r'\b(?:daqui\s+em\s+dark|dark\s+and\s+dark|darken\s+darker|dark\s+end\s+darker|darp\s+and\s+darker|dark\s+and\s+darker)\b', 'Dark and Darker'),
        (r'\b(?:pague\s+seguro|pagueseguro)\b', 'PagueSeguro'),

        (r'\b(?:game\s*play)\b', 'gameplay'),
        (r'\b(?:stream\s*er)\b', 'streamer'),
        
        # Termos Gaming / Ação
        (r'\b(?:luti|lute)\b(?!\s+(?:de|para|pela|pelo|contra))', 'loot'),
        (r'\b(?:lutear|lutiar|lotear)\b', 'lootear'),
        (r'\b(?:luteando|lutiando)\b', 'looteando'),
        (r'\b(?:clote|clox)\b', 'clutch'),
        (r'\b(?:head\s*shot|red\s*shot)\b', 'headshot'),
        (r'\b(?:dangeon|danjeon)\b', 'dungeon'),
        (r'\b(?:culdaun|coldown)\b', 'cooldown'),
        (r'\b(?:espawn|ispawn)\b', 'spawn'),
        (r'\b(?:respawn|rispawn)\b', 'respawn'),
        (r'\b(?:estração|extraçao)\b', 'extração'),
        (r'\b(?:masmora)\b', 'masmorra'),
        (r'\b(?:masmoras)\b', 'masmorras'),
        
        # Expressões do Português com erros fonéticos comuns
        (r'\b(?:nada\s+ha\s+ver|nada\s+haver)\b', 'nada a ver'),
        (r'\b(?:comcerteza)\b', 'com certeza'),
        (r'\b(?:derrepente)\b', 'de repente'),
        (r'\b(?:porisso)\b', 'por isso'),
        (r'\b(?:agente\s+fala)\b', 'a gente fala'),
        (r'\b(?:agente\s+vai)\b', 'a gente vai'),
        (r'\b(?:agente\s+tá|agente\s+ta)\b', 'a gente tá'),
        (r'\b(?:morremo|morrimo)\b', 'morremos'),
        (r'\b(?:perdemo|perdimo)\b', 'perdemos'),
    ]

    for padrao, subst in substituicoes:
        t = re.sub(padrao, subst, t, flags=re.IGNORECASE)

    # 3. Limpeza de espaços duplos
    t = re.sub(r'\s+', ' ', t).strip()

    return t


def eh_linha_musica_ou_lixo(texto: str, frases_repetidas_set: Optional[Set[str]] = None) -> bool:
    """Filtro de lixo, músicas gospel em background, alucinações de IA e caracteres não-latinos."""
    if not texto or not isinstance(texto, str):
        return True

    t_lower = texto.strip().lower()
    if not t_lower or len(t_lower) < 4:
        return True

    if frases_repetidas_set and t_lower in frases_repetidas_set:
        return True

    if re.search(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]", texto):
        return True

    padroes_lixo = [
        "mesmerism", "www.", ".info", ".com", "http",
        "[música]", "[musica]", "(música)", "(musica)", "♪", "♫", "🎶",
        "(risos)", "[risos]", "(aplausos)", "[aplausos]",
        "tu és o meu senhor", "vivo pelo teu amor",
        "amor entronizava", "fio o silêncio", "friu o silêncio",
        "filhos de jacob", "meus irmãos viviam",
        "me despreçavam", "me injuriam", "me levaram a nossa casa",
        "meus pesadeiros", "meus pesadiros",
        "no egito sou vendido", "escravo chefe", "faraó que soubido",
        "banner", "obrigado por assistir",
        "deixe o like", "se inscreva no canal", "comunhão com deus",
    ]

    if t_lower in ("música", "musica", "música.", "musica.", "[música]", "[musica]"):
        return True
    for p in padroes_lixo:
        if p in t_lower:
            return True
    return False
