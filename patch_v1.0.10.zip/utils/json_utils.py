import re
import json
from typing import List, Dict, Any

def extrair_json_robusto(texto_resposta: str) -> List[Dict[str, Any]]:
    """
    Extrai e decodifica lista de JSON de uma resposta de IA com sanitização e fallbacks.
    """
    if not texto_resposta or not isinstance(texto_resposta, str):
        return []

    # 0. Limpeza de tags de pensamento
    texto_limpo = re.sub(r'<think>.*?</think>', '', str(texto_resposta), flags=re.DOTALL).strip()
    
    # 1. Tentar extrair conteúdo dentro de ```json ... ``` ou ``` ... ```
    m_code = re.search(r'```(?:json)?\s*(.*?)\s*```', texto_limpo, re.DOTALL)
    if m_code:
        bloco = m_code.group(1).strip()
        try:
            dados = json.loads(bloco)
            if isinstance(dados, list):
                return [d for d in dados if isinstance(d, dict)]
            if isinstance(dados, dict):
                return [dados]
        except Exception:
            pass

    # 2. Tentar parse direto
    try:
        dados = json.loads(texto_limpo)
        if isinstance(dados, list):
            return [d for d in dados if isinstance(d, dict)]
        if isinstance(dados, dict):
            return [dados]
    except Exception:
        pass

    # 3. Extrair substring entre o primeiro '[' e o último ']'
    idx_open = texto_limpo.find('[')
    idx_close = texto_limpo.rfind(']')
    if idx_open != -1 and idx_close != -1 and idx_close > idx_open:
        bloco_arr = texto_limpo[idx_open:idx_close+1]
        try:
            dados = json.loads(bloco_arr)
            if isinstance(dados, list):
                return [d for d in dados if isinstance(d, dict)]
        except Exception:
            pass

    # 4. Extração de objetos isolados {...}
    objetos = []
    for obj_match in re.finditer(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', texto_limpo, re.DOTALL):
        try:
            item = json.loads(obj_match.group(0))
            if isinstance(item, dict) and ("tempo_inicio" in item or "titulo_viral" in item):
                objetos.append(item)
        except Exception:
            continue

    return objetos
