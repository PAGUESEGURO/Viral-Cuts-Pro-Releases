"""
=============================================================================
VIRAL CUTS PRO - PIPELINE CONTROLLER
Controlador de execução, ciclo de vida e eventos de esteira de cortes.
Desacopla a interface de usuário (Tkinter/CLI) do processo de renderização.
=============================================================================
"""

import os
import sys
import subprocess
import threading
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, Callable, Dict, Any, List

DIR_ATUAL = Path(__file__).parent.resolve()
SCRIPT_ESTEIRA_PADRAO = DIR_ATUAL / "esteira.py"


class EstadoPipeline:
    IDLE = "IDLE"
    EXECUTANDO = "EXECUTANDO"
    PAUSADO = "PAUSADO"
    CONCLUIDO = "CONCLUIDO"
    INTERROMPIDO = "INTERROMPIDO"
    ERRO = "ERRO"


@dataclass
class PipelineConfig:
    video_path: Optional[Path] = None
    backend: str = "LM Studio"
    modelo: str = "qwen3.5-9b.gguf"
    nota_minima: int = 6
    url: str = ""
    api_key: str = ""
    transcricao_path: Optional[Path] = None
    nome_canal: str = ""
    forcar: bool = False
    remover_silencios: bool = True
    posicao_webcam: str = "Topo-Esquerdo (Padrão)"
    gerar_legendas: bool = True
    estilo_legenda: str = "TikTok Bold Yellow"
    enquadramento_916: bool = True
    zoom_rosto: bool = True
    tipo_momento: str = "Todos os Momentos"



class PipelineController:
    """
    Controlador central para execução assíncrona da esteira de cortes virais.
    Gerencia subprocessos, captura de streams e despacho de eventos thread-safe.
    """

    def __init__(self, script_esteira: Optional[Path] = None):
        self.script_esteira = script_esteira or SCRIPT_ESTEIRA_PADRAO
        self.processo: Optional[subprocess.Popen] = None
        self.estado: str = EstadoPipeline.IDLE
        self._lock = threading.Lock()
        self._thread_monitor: Optional[threading.Thread] = None

        # Callbacks registrados
        self._callbacks: Dict[str, List[Callable]] = {
            "on_log": [],
            "on_status_change": [],
            "on_corte_gerado": [],
            "on_finalizado": []
        }

    def registrar_callback(self, evento: str, fn: Callable) -> None:
        """Registra uma função de callback para um evento específico."""
        with self._lock:
            if evento in self._callbacks:
                self._callbacks[evento].append(fn)

    def _disparar_evento(self, evento: str, *args, **kwargs) -> None:
        """Dispara callbacks de forma segura contra exceções nos handlers."""
        handlers = []
        with self._lock:
            handlers = list(self._callbacks.get(evento, []))

        for handler in handlers:
            try:
                handler(*args, **kwargs)
            except Exception as e:
                print(f"[PipelineController] Erro no callback '{evento}': {e}", file=sys.stderr)

    def is_rodando(self) -> bool:
        """Verifica se há um processo de esteira em execução."""
        with self._lock:
            return self.estado == EstadoPipeline.EXECUTANDO

    def construir_comando(self, config: PipelineConfig) -> List[str]:
        """Gera a lista de argumentos para a invocação CLI da esteira."""
        if getattr(sys, 'frozen', False):
            cmd = [sys.executable, "--esteira"]
        else:
            cmd = [sys.executable, str(self.script_esteira)]

        nota_val = max(1, min(10, int(config.nota_minima)))
        mod_escolhido = config.modelo.strip() or "qwen3.5-9b.gguf"
        bk_atual = config.backend.strip() or "LM Studio"

        cmd.extend([
            "--backend", bk_atual,
            "--modelo", mod_escolhido,
            "--nota-minima", str(nota_val)
        ])

        if config.url.strip():
            cmd.extend(["--url", config.url.strip()])

        if config.api_key.strip():
            cmd.extend(["--api-key", config.api_key.strip()])

        if config.transcricao_path and Path(config.transcricao_path).exists():
            cmd.extend(["--transcricao", str(Path(config.transcricao_path).resolve())])

        if config.nome_canal.strip():
            cmd.extend(["--canal", config.nome_canal.strip()])

        if config.video_path:
            cmd.append(str(Path(config.video_path).resolve()))

        if config.forcar:
            cmd.append("--force")

        return cmd

    def iniciar(self, config: PipelineConfig) -> bool:
        """Inicia a esteira de cortes em uma thread assíncrona segura e sem subprocessos externos."""
        if self.is_rodando():
            return False

        self.estado = EstadoPipeline.EXECUTANDO
        self._disparar_evento("on_status_change", EstadoPipeline.EXECUTANDO, "Executando esteira de cortes...")

        def _worker():
            try:
                import esteira

                def _log_cb(msg: str):
                    self._disparar_evento("on_log", msg)

                def _corte_cb(info_corte: Dict[str, Any]):
                    self._disparar_evento("on_corte_gerado", info_corte)

                sucesso, msg_status, historico = esteira.executar_esteira_pipeline(
                    video_path=config.video_path,
                    backend=config.backend,
                    modelo=config.modelo,
                    nota_minima=config.nota_minima,
                    url=config.url,
                    api_key=config.api_key,
                    nome_canal=config.nome_canal,
                    transcricao_path=config.transcricao_path,
                    forcar=config.forcar,
                    remover_silencios=config.remover_silencios,
                    gerar_legendas=config.gerar_legendas,
                    estilo_legenda=config.estilo_legenda,
                    enquadramento_916=config.enquadramento_916,
                    zoom_rosto=config.zoom_rosto,
                    log_callback=_log_cb,
                    corte_callback=_corte_cb,
                    cancel_check=lambda: self.estado == EstadoPipeline.INTERROMPIDO
                )

                with self._lock:
                    if self.estado == EstadoPipeline.INTERROMPIDO:
                        status_msg = "● INTERROMPIDO PELO USUÁRIO"
                        exit_code = 1
                    elif sucesso:
                        self.estado = EstadoPipeline.CONCLUIDO
                        status_msg = "● CONCLUÍDO COM SUCESSO"
                        exit_code = 0
                    else:
                        self.estado = EstadoPipeline.ERRO
                        status_msg = f"● {msg_status}"
                        exit_code = 1

                self._disparar_evento("on_status_change", self.estado, status_msg)
                self._disparar_evento("on_finalizado", exit_code, status_msg)

            except Exception as e:
                with self._lock:
                    self.estado = EstadoPipeline.ERRO
                    status_msg = f"● ERRO: {e}"
                self._disparar_evento("on_log", f"\n[PipelineController] Erro na execução da esteira: {e}\n")
                self._disparar_evento("on_status_change", EstadoPipeline.ERRO, status_msg)
                self._disparar_evento("on_finalizado", 1, status_msg)

        self._thread_monitor = threading.Thread(target=_worker, daemon=True)
        self._thread_monitor.start()
        return True

    def parar(self) -> None:
        """Interrompe a execução da esteira de cortes."""
        with self._lock:
            if self.estado == EstadoPipeline.EXECUTANDO:
                self.estado = EstadoPipeline.INTERROMPIDO
                self._disparar_evento("on_status_change", EstadoPipeline.INTERROMPIDO, "● INTERROMPENDO...")
                self._disparar_evento("on_log", "\n🛑 Processamento da esteira interrompido pelo usuário.\n")

    def _processar_linha_log(self, linha: str) -> None:
        """Analisa a linha de log e dispara eventos específicos."""
        self._disparar_evento("on_log", linha)
        if any(term in linha for term in ["gerado com sucesso", "Renderizando corte", "🎬 Corte", "[OK] Corte", "Corte #"]):
            self._disparar_evento("on_corte_gerado", {"log": linha.strip()})


