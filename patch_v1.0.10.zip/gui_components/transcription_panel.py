"""
Componente TranscriptionPanel para exibição interativa e sincronizada de diálogos da live.
Exibe blocos de fala com timestamps precisos, speaker tags e sincronização bidirecional com o player.
"""

from typing import Optional, Callable, List, Dict, Any

import tkinter as tk
from tkinter import ttk

from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    ACCENT_BLUE,
    ACCENT_GREEN,
    CYAN_ACCENT,
    FONT_FAMILY,
    FONT_MONO
)


def formatar_tempo_fala(seg: float) -> str:
    s = max(0.0, float(seg))
    hrs = int(s // 3600)
    mins = int((s % 3600) // 60)
    secs = int(s % 60)
    return f"{hrs:02d}:{mins:02d}:{secs:02d}"


class TranscriptionBlock(tk.Frame):
    """Card individual de fala na lista de transcrição."""

    def __init__(
        self,
        master,
        inicio: float,
        fim: float,
        texto: str,
        speaker: str = "Person 1",
        on_click: Optional[Callable[[float], None]] = None,
        **kwargs
    ):
        super().__init__(master, bg=BG_SECONDARY, bd=1, relief="solid", **kwargs)
        self.inicio = inicio
        self.fim = fim
        self.texto = texto
        self.speaker = speaker
        self.on_click = on_click
        self.is_active = False

        self._build_ui()

    def _build_ui(self):
        self.config(padx=6, pady=4)

        # Header do Bloco: Timestamp + Speaker + Checkmark
        top_frame = tk.Frame(self, bg=BG_SECONDARY)
        top_frame.pack(fill="x")

        t_str = formatar_tempo_fala(self.inicio)
        self.lbl_time = tk.Label(
            top_frame,
            text=t_str,
            bg=BG_SECONDARY,
            fg=CYAN_ACCENT,
            font=(FONT_MONO, 8, "bold")
        )
        self.lbl_time.pack(side="left")

        self.lbl_speaker = tk.Label(
            top_frame,
            text=f" [{self.speaker}]:",
            bg=BG_SECONDARY,
            fg=TEXT_SECONDARY,
            font=(FONT_FAMILY, 8)
        )
        self.lbl_speaker.pack(side="left", padx=2)

        self.lbl_check = tk.Label(
            top_frame,
            text="✓",
            bg=BG_SECONDARY,
            fg=ACCENT_GREEN,
            font=(FONT_FAMILY, 8, "bold")
        )
        self.lbl_check.pack(side="right")

        # Texto da Fala
        self.lbl_texto = tk.Label(
            self,
            text=f'"{self.texto}"',
            bg=BG_SECONDARY,
            fg=TEXT_PRIMARY,
            font=(FONT_FAMILY, 9),
            wraplength=280,
            justify="left"
        )
        self.lbl_texto.pack(fill="x", pady=(2, 0))

        # Evento de clique para seek
        for w in (self, top_frame, self.lbl_time, self.lbl_speaker, self.lbl_check, self.lbl_texto):
            w.bind("<Button-1>", lambda e: self._on_clicked())
            w.config(cursor="hand2")

    def _on_clicked(self):
        if self.on_click:
            self.on_click(self.inicio)

    def set_ativo(self, ativo: bool):
        self.is_active = ativo
        cor_bg = BG_TERTIARY if ativo else BG_SECONDARY
        cor_borda = ACCENT_BLUE if ativo else BORDER_COLOR
        self.config(bg=cor_bg, highlightbackground=cor_borda, highlightthickness=1 if ativo else 0)
        self.lbl_texto.config(bg=cor_bg)
        self.lbl_time.config(bg=cor_bg)
        self.lbl_speaker.config(bg=cor_bg)
        self.lbl_check.config(bg=cor_bg)


class TranscriptionPanel(tk.Frame):
    """
    Painel scrollável com listagem de falas geradas pelo Whisper.
    Destaca a fala correspondente ao tempo atual do player de vídeo.
    """

    def __init__(self, master, on_seek: Optional[Callable[[float], None]] = None, **kwargs):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)
        self.on_seek = on_seek
        self.blocos: List[TranscriptionBlock] = []
        self._bloco_ativo_idx = -1

        self._build_ui()

    def _build_ui(self):
        # Header do Painel
        header = tk.Frame(self, bg=BG_TERTIARY, height=28)
        header.pack(fill="x", padx=2, pady=2)

        tk.Label(
            header,
            text="Transcription Panel",
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            font=(FONT_FAMILY, 9, "bold")
        ).pack(side="left", padx=8)

        # Canvas Scrollável para os blocos
        container = tk.Frame(self, bg=BG_SECONDARY)
        container.pack(fill="both", expand=True, padx=2, pady=2)

        self.canvas = tk.Canvas(container, bg=BG_SECONDARY, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.canvas.yview)
        self.scroll_frame = tk.Frame(self.canvas, bg=BG_SECONDARY)

        self.scroll_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas_window = self.canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width)
        )

        # Botão Inferior de Recalcular Legendas
        btn_recalc = tk.Button(
            self,
            text="⚡ Recalculate AI Subtitles (Whisper)",
            bg=BG_TERTIARY,
            fg=CYAN_ACCENT,
            bd=0,
            padx=8,
            pady=4,
            font=(FONT_FAMILY, 8, "bold")
        )
        btn_recalc.pack(fill="x", padx=4, pady=4)

    def carregar_transcricao(self, lista_falas: List[Dict[str, Any]]):
        """Preenche o painel com os dados de fala da transcrição global."""
        for w in self.scroll_frame.winfo_children():
            w.destroy()
        self.blocos.clear()
        self._bloco_ativo_idx = -1

        for idx, fala in enumerate(lista_falas):
            st = float(fala.get("inicio", 0.0))
            et = float(fala.get("fim", 0.0))
            txt = str(fala.get("texto", "")).strip()
            if not txt:
                continue

            bloco = TranscriptionBlock(
                self.scroll_frame,
                inicio=st,
                fim=et,
                texto=txt,
                speaker="Person 1",
                on_click=self._on_bloco_click
            )
            bloco.pack(fill="x", padx=4, pady=2)
            self.blocos.append(bloco)

    def _on_bloco_click(self, inicio: float):
        if self.on_seek:
            self.on_seek(inicio)

    def sincronizar_com_tempo(self, tempo: float):
        """Destaca o bloco de fala ativo no momento atual do player."""
        idx_encontrado = -1
        for idx, b in enumerate(self.blocos):
            if b.inicio <= tempo <= b.fim:
                idx_encontrado = idx
                break

        if idx_encontrado != self._bloco_ativo_idx:
            if 0 <= self._bloco_ativo_idx < len(self.blocos):
                self.blocos[self._bloco_ativo_idx].set_ativo(False)

            if 0 <= idx_encontrado < len(self.blocos):
                self.blocos[idx_encontrado].set_ativo(True)

            self._bloco_ativo_idx = idx_encontrado
