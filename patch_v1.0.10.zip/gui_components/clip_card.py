"""
=============================================================================
VIRAL CUTS PRO - CARD VISUAL DE CORTE GERADO (CLIP CARD)
Card interativo mostrando título viral, score de viralidade, duração e ações.
=============================================================================
"""

import os
import subprocess
import tkinter as tk
from pathlib import Path
from typing import Optional, Callable

from .theme import (
    BG_CARD,
    BG_TERTIARY,
    BG_HOVER,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    ACCENT_BLUE,
    ACCENT_GREEN,
    ACCENT_YELLOW,
    ACCENT_ORANGE,
    ACCENT_RED,
    BORDER_COLOR,
    FONT_FAMILY,
    FONT_MONO,
)


class ClipCard(tk.Frame):
    """
    Card visual compacto e elegante para cada corte gerado pela esteira:
    ┌───────────────────────────────────┐
    │ 🔥 TÍTULO VIRAL GERADO PELA IA    │
    │ [ Score: 92/100 ] • ⏱️ 45s         │
    │ [ ▶ Assistir ]  [ 📂 Abrir ]       │
    └───────────────────────────────────┘
    """

    def __init__(
        self,
        master,
        titulo: str,
        viral_score: int,
        duracao_seg: float,
        caminho_arquivo: Path,
        on_preview: Optional[Callable[[Path], None]] = None,
        on_open_folder: Optional[Callable[[Path], None]] = None,
        **kwargs
    ):
        super().__init__(master, bg=BG_CARD, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1, **kwargs)

        self.titulo = titulo or "Corte Viral Sem Nome"
        self.viral_score = max(0, min(100, int(viral_score)))
        self.duracao_seg = max(0.0, float(duracao_seg))
        self.caminho_arquivo = Path(caminho_arquivo)
        self.on_preview = on_preview
        self.on_open_folder = on_open_folder

        self._build_ui()

    def _get_score_color(self, score: int) -> tuple[str, str, str]:
        """Retorna (cor_texto, cor_fundo_badge, label_nivel)."""
        if score >= 90:
            return ACCENT_GREEN, "#064e3b", "🔥 ÉPICO"
        elif score >= 70:
            return ACCENT_YELLOW, "#451a03", "⚡ ALTO"
        elif score >= 50:
            return ACCENT_ORANGE, "#431407", "👍 MÉDIO"
        else:
            return ACCENT_RED, "#450a0a", "❄️ BAIXO"

    def _formatar_duracao(self, seg: float) -> str:
        s = int(seg)
        minutos = s // 60
        segundos = s % 60
        if minutos > 0:
            return f"{minutos}m{segundos:02d}s"
        return f"{segundos}s"

    def _build_ui(self):
        # 1. Linha do Título Viral
        fg_score, bg_badge, nivel = self._get_score_color(self.viral_score)

        title_frame = tk.Frame(self, bg=BG_CARD)
        title_frame.pack(fill="x", padx=10, pady=(8, 4))

        tk.Label(
            title_frame,
            text=f"🎬 {self.titulo[:32]}{'...' if len(self.titulo) > 32 else ''}",
            font=(FONT_FAMILY, 9, "bold"),
            bg=BG_CARD,
            fg=TEXT_PRIMARY,
            anchor="w"
        ).pack(side="left", fill="x", expand=True)

        # 2. Linha de Metadados: Score Badge + Duração
        meta_frame = tk.Frame(self, bg=BG_CARD)
        meta_frame.pack(fill="x", padx=10, pady=(0, 6))

        # Badge de Score
        tk.Label(
            meta_frame,
            text=f" {nivel} {self.viral_score}/100 ",
            font=(FONT_FAMILY, 8, "bold"),
            bg=bg_badge,
            fg=fg_score,
            padx=4,
            pady=1
        ).pack(side="left")

        # Duração
        tk.Label(
            meta_frame,
            text=f"⏱️ {self._formatar_duracao(self.duracao_seg)}",
            font=(FONT_FAMILY, 8),
            bg=BG_CARD,
            fg=TEXT_SECONDARY
        ).pack(side="left", padx=(8, 0))

        # 3. Linha de Ações: Assistir & Abrir
        action_frame = tk.Frame(self, bg=BG_CARD)
        action_frame.pack(fill="x", padx=10, pady=(0, 8))

        btn_preview = tk.Button(
            action_frame,
            text="▶ Assistir",
            font=(FONT_FAMILY, 8, "bold"),
            bg="#0284c7",
            fg="#ffffff",
            activebackground="#0369a1",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=8,
            pady=2,
            cursor="hand2",
            command=self._disparar_preview
        )
        btn_preview.pack(side="left", padx=(0, 4))

        btn_folder = tk.Button(
            action_frame,
            text="📂 Abrir",
            font=(FONT_FAMILY, 8),
            bg="#334155",
            fg="#f8fafc",
            activebackground="#475569",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=8,
            pady=2,
            cursor="hand2",
            command=self._abrir_pasta
        )
        btn_folder.pack(side="left")

    def _disparar_preview(self):
        if self.on_preview and self.caminho_arquivo.exists():
            self.on_preview(self.caminho_arquivo)
        elif self.caminho_arquivo.exists():
            # Fallback nativo do Windows
            try:
                os.startfile(str(self.caminho_arquivo))
            except Exception:
                pass

    def _abrir_pasta(self):
        if self.on_open_folder:
            self.on_open_folder(self.caminho_arquivo)
        else:
            # Fallback nativo: abre o Windows Explorer selecionando o arquivo
            try:
                if self.caminho_arquivo.exists():
                    subprocess.run(["explorer", f"/select,{str(self.caminho_arquivo)}"], check=False)
                elif self.caminho_arquivo.parent.exists():
                    subprocess.run(["explorer", str(self.caminho_arquivo.parent)], check=False)
            except Exception:
                pass
