"""
Componente ExportPanel para configuração de exportação vertical e preview de Safe Zones 9:16.
Permite definir formato (TikTok/Reels/Shorts), fontes e estilo visual das legendas.
"""

from typing import Optional, Callable

import tkinter as tk
from tkinter import ttk

from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    ACCENT_BLUE,
    CYAN_ACCENT,
    FONT_FAMILY,
    FONT_MONO
)


class ExportPanel(tk.Frame):
    """
    Painel de parametrização de exportação com mini-simulador 9:16 e zonas de segurança (Safe Zones).
    """

    def __init__(self, master, **kwargs):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)

        self.formato_var = tk.StringVar(value="9:16 (TikTok / Reels / Shorts)")
        self.fonte_var = tk.StringVar(value="Impact")
        self.cor_legenda_var = tk.StringVar(value="#FFFFFF")
        self.plataforma_var = tk.StringVar(value="TikTok & Reels")

        self._build_ui()

    def _build_ui(self):
        # 1. Mini-preview 9:16 com Safe Zones
        preview_frame = tk.Frame(self, bg=BG_SECONDARY)
        preview_frame.pack(fill="x", padx=8, pady=(4, 6))

        tk.Label(
            preview_frame,
            text="Export Format & Safe Zones",
            bg=BG_SECONDARY,
            fg=TEXT_PRIMARY,
            font=(FONT_FAMILY, 9, "bold")
        ).pack(anchor="w", pady=(0, 4))

        self.canvas_safe_zones = tk.Canvas(
            preview_frame,
            width=110,
            height=195,
            bg="#000000",
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        self.canvas_safe_zones.pack(anchor="center")
        self._desenhar_safe_zones()

        # 2. Configuração de Estilo de Legenda
        style_frame = tk.LabelFrame(
            self,
            text="Subtitle Style",
            bg=BG_SECONDARY,
            fg=CYAN_ACCENT,
            font=(FONT_FAMILY, 9, "bold"),
            padx=8,
            pady=6
        )
        style_frame.pack(fill="x", padx=8, pady=4)

        # Seletor de Fonte
        tk.Label(style_frame, text="Font:", bg=BG_SECONDARY, fg=TEXT_SECONDARY, font=(FONT_FAMILY, 8)).grid(row=0, column=0, sticky="w", pady=2)
        cb_font = ttk.Combobox(style_frame, values=["Impact", "Segoe UI", "Arial Black", "Montserrat", "Outfit"], textvariable=self.fonte_var, state="readonly", width=14)
        cb_font.grid(row=0, column=1, sticky="ew", pady=2)

        # Seletor de Plataforma
        tk.Label(style_frame, text="Target Platform:", bg=BG_SECONDARY, fg=TEXT_SECONDARY, font=(FONT_FAMILY, 8)).grid(row=1, column=0, sticky="w", pady=2)
        cb_plat = ttk.Combobox(style_frame, values=["TikTok & Reels", "YouTube Shorts", "Sem Restrição"], textvariable=self.plataforma_var, state="readonly", width=14)
        cb_plat.grid(row=1, column=1, sticky="ew", pady=2)

    def _desenhar_safe_zones(self):
        w = 110
        h = 195
        self.canvas_safe_zones.delete("all")

        # Fundo do vídeo vertical
        self.canvas_safe_zones.create_rectangle(0, 0, w, h, fill="#0b0f19", outline="")

        # Linhas pontilhadas das Zonas Seguras (Safe Zones)
        # Topo (área de busca/tabs)
        self.canvas_safe_zones.create_rectangle(8, 20, w - 8, h - 35, outline="#38bdf8", dash=(2, 2))
        self.canvas_safe_zones.create_text(w // 2, 10, text="Safe Zones", fill="#6e7681", font=(FONT_FAMILY, 7))

        # Texto Central 9:16
        self.canvas_safe_zones.create_text(w // 2, h // 2 - 10, text="9:16", fill="#ffffff", font=(FONT_FAMILY, 10, "bold"))
        self.canvas_safe_zones.create_text(w // 2, h // 2 + 8, text="TikTok / Reels", fill="#8b949e", font=(FONT_FAMILY, 7))

        # Margem inferior (descrição e botões de áudio)
        self.canvas_safe_zones.create_rectangle(8, h - 30, w - 24, h - 8, fill="#161b22", outline="#30363d")
        self.canvas_safe_zones.create_text(w // 2 - 8, h - 19, text="Caption Area", fill="#6e7681", font=(FONT_FAMILY, 6))

        # Ícones simulados da direita (Like, Comentário, Compartilhar)
        for idx, y_pos in enumerate([h - 75, h - 55, h - 35]):
            self.canvas_safe_zones.create_oval(w - 18, y_pos - 4, w - 10, y_pos + 4, fill="#38bdf8", outline="")
