"""
=============================================================================
VIRAL CUTS PRO - GALERIA DE CORTES GERADOS (PROJECT BIN v2.0)
Galeria rica e interativa de cortes gerados com cards, pontuação e ações rápidas.
=============================================================================
"""

import os
import subprocess
from pathlib import Path
from typing import Optional, Callable, List, Dict, Any

import tkinter as tk
from tkinter import ttk

from .clip_card import ClipCard
from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BG_CARD,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    ACCENT_BLUE,
    ACCENT_GREEN,
    CYAN_ACCENT,
    FONT_FAMILY,
    FONT_MONO,
)


class ProjectBin(tk.Frame):
    """
    Galeria moderna de cortes gerados e arquivos de origem com cards interativos.
    """

    def __init__(
        self,
        master,
        on_select_source: Optional[Callable[[Path], None]] = None,
        on_select_clip: Optional[Callable[[Dict[str, Any]], None]] = None,
        pasta_cortes: Optional[Path] = None,
        **kwargs
    ):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)
        self.on_select_source = on_select_source
        self.on_select_clip = on_select_clip
        self.pasta_cortes = pasta_cortes or (Path(__file__).parent.parent / "cortes_prontos")

        self.fontes: List[Path] = []
        self.clipes_gerados: List[Dict[str, Any]] = []

        self._build_ui()
        self._render_empty_state()

    def _build_ui(self):
        # 1. Header com contador de cortes
        header = tk.Frame(self, bg=BG_TERTIARY, height=32)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        self.lbl_header_title = tk.Label(
            header,
            text="⚡ CORTES GERADOS (0)",
            font=(FONT_FAMILY, 9, "bold"),
            bg=BG_TERTIARY,
            fg=CYAN_ACCENT
        )
        self.lbl_header_title.pack(side="left", padx=10, pady=6)

        # 2. Footer com botão "Abrir Pasta"
        footer = tk.Frame(self, bg=BG_TERTIARY, height=42)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)

        btn_abrir_pasta = tk.Button(
            footer,
            text="📂 Abrir Pasta de Cortes",
            font=(FONT_FAMILY, 8, "bold"),
            bg="#1e293b",
            fg="#f8fafc",
            activebackground="#334155",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=8,
            pady=6,
            cursor="hand2",
            command=self._abrir_pasta_cortes_completa
        )
        btn_abrir_pasta.pack(fill="x", padx=8, pady=6)

        # 3. Área Scrollável de Cards
        self.canvas = tk.Canvas(self, bg=BG_SECONDARY, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)

        self.cards_frame = tk.Frame(self.canvas, bg=BG_SECONDARY)
        self.cards_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.cards_frame, anchor="nw")
        self.canvas.configure(xscrollcommand=None, yscrollcommand=self.scrollbar.set)

        self.canvas.bind("<Configure>", self._on_canvas_configure)

        self.canvas.pack(side="left", fill="both", expand=True, padx=(4, 0), pady=4)
        self.scrollbar.pack(side="right", fill="y", pady=4)

        # Suporte a mousewheel
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def _on_mousewheel(self, event):
        if self.winfo_ismapped():
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _render_empty_state(self):
        """Renderiza visual amigável quando ainda não há cortes gerados."""
        for w in self.cards_frame.winfo_children():
            w.destroy()

        empty_box = tk.Frame(self.cards_frame, bg=BG_SECONDARY, pady=40)
        empty_box.pack(fill="both", expand=True, padx=12)

        tk.Label(
            empty_box,
            text="🎬",
            font=("Segoe UI Emoji", 32),
            bg=BG_SECONDARY,
            fg=TEXT_MUTED
        ).pack(pady=(0, 6))

        tk.Label(
            empty_box,
            text="Nenhum corte gerado ainda",
            font=(FONT_FAMILY, 10, "bold"),
            bg=BG_SECONDARY,
            fg=TEXT_SECONDARY
        ).pack()

        tk.Label(
            empty_box,
            text="Carregue um vídeo no Passo 1\ne clique em 'Gerar Cortes Virais'\npara vê-los listados aqui.",
            font=(FONT_FAMILY, 8),
            bg=BG_SECONDARY,
            fg=TEXT_MUTED,
            justify="center"
        ).pack(pady=(4, 0))

    def adicionar_corte_gerado(self, info_corte: Dict[str, Any]):
        """Adiciona um ClipCard com dados reais na galeria."""
        if not self.clipes_gerados:
            # Primeiro corte: limpa o empty state
            for w in self.cards_frame.winfo_children():
                w.destroy()

        self.clipes_gerados.append(info_corte)
        total = len(self.clipes_gerados)
        self.lbl_header_title.config(text=f"⚡ CORTES GERADOS ({total})")

        titulo = info_corte.get("titulo", f"Corte Viral #{total:02d}")
        score = info_corte.get("score", info_corte.get("viral_score", 0))
        duracao = info_corte.get("duracao", info_corte.get("duracao_seg", 0.0))
        caminho = Path(info_corte.get("caminho", info_corte.get("arquivo", "")))

        card = ClipCard(
            self.cards_frame,
            titulo=titulo,
            viral_score=score,
            duracao_seg=duracao,
            caminho_arquivo=caminho,
            on_preview=lambda p, inf=info_corte: self._on_preview_clicado(p, inf),
            on_open_folder=lambda p: self._abrir_pasta_especifica(p)
        )
        card.pack(fill="x", padx=6, pady=4)

    def adicionar_fonte(self, path: Path):
        """Compatibilidade para registro de origens."""
        p = Path(path)
        if p not in self.fontes:
            self.fontes.append(p)

    def limpar(self):
        """Limpa todos os cortes da galeria e reseta para o empty state."""
        self.clipes_gerados.clear()
        self.fontes.clear()
        self.lbl_header_title.config(text="⚡ CORTES GERADOS (0)")
        self._render_empty_state()

    def _on_preview_clicado(self, path: Path, info: Dict[str, Any]):
        if self.on_select_clip:
            self.on_select_clip(info)
        elif self.on_select_source and path.exists():
            self.on_select_source(path)

    def _on_source_clicked(self, path: Path):
        """Dispara callback de seleção de fonte."""
        if self.on_select_source:
            self.on_select_source(path)

    def _on_clip_clicked(self, info: Dict[str, Any]):
        """Dispara callback de seleção de clipe."""
        if self.on_select_clip:
            self.on_select_clip(info)

    def _abrir_pasta_especifica(self, path: Path):
        try:
            if path.exists():
                subprocess.run(["explorer", f"/select,{str(path)}"], check=False)
            elif self.pasta_cortes.exists():
                subprocess.run(["explorer", str(self.pasta_cortes)], check=False)
        except Exception:
            pass

    def _abrir_pasta_cortes_completa(self):
        try:
            self.pasta_cortes.mkdir(parents=True, exist_ok=True)
            subprocess.run(["explorer", str(self.pasta_cortes)], check=False)
        except Exception:
            pass
