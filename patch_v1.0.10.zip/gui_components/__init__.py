"""
=============================================================================
VIRAL CUTS PRO - PACOTE DE COMPONENTES VISUAIS (GOAL-ORIENTED UX v2.0)
=============================================================================
"""

from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BG_CARD,
    BG_STEP_HEADER,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    ACCENT_BLUE,
    ACCENT_BLUE_HOVER,
    ACCENT_GREEN,
    ACCENT_ORANGE,
    ACCENT_RED,
    ACCENT_YELLOW,
    ACCENT_PURPLE_DIM,
    BADGE_BG,
    CYAN_ACCENT,
    FONT_FAMILY,
    FONT_MONO,
    STEP_ACTIVE_COLOR,
    STEP_INACTIVE_COLOR,
)

from .video_player import VideoPlayer
from .waveform import WaveformDisplay
from .timeline import TimelineWidget
from .transcription_panel import TranscriptionPanel, TranscriptionBlock
from .export_panel import ExportPanel
from .ai_highlights import AIHighlightsPanel
from .project_bin import ProjectBin
from .pipeline_monitor import PipelineMonitor
from .clip_card import ClipCard
from .step_panel import StepPanel

__all__ = [
    "BG_PRIMARY",
    "BG_SECONDARY",
    "BG_TERTIARY",
    "BG_CARD",
    "BG_STEP_HEADER",
    "BORDER_COLOR",
    "TEXT_PRIMARY",
    "TEXT_SECONDARY",
    "TEXT_MUTED",
    "ACCENT_BLUE",
    "ACCENT_BLUE_HOVER",
    "ACCENT_GREEN",
    "ACCENT_ORANGE",
    "ACCENT_RED",
    "ACCENT_YELLOW",
    "ACCENT_PURPLE_DIM",
    "BADGE_BG",
    "CYAN_ACCENT",
    "FONT_FAMILY",
    "FONT_MONO",
    "STEP_ACTIVE_COLOR",
    "STEP_INACTIVE_COLOR",

    "VideoPlayer",
    "WaveformDisplay",
    "TimelineWidget",
    "TranscriptionPanel",
    "TranscriptionBlock",
    "ExportPanel",
    "AIHighlightsPanel",
    "ProjectBin",
    "PipelineMonitor",
    "ClipCard",
    "StepPanel",
]
