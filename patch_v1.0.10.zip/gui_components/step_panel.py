"""
=============================================================================
VIRAL CUTS PRO - PAINEL DE FLUXO LINEAR (STEP PANEL)
Guia o streamer nos 3 passos: 1. Vídeo ➔ 2. Opções de IA & Estilo ➔ 3. Gerar.
=============================================================================
"""

import tkinter as tk
from tkinter import ttk
from pathlib import Path
from typing import Optional, Callable

from .theme import (
    BG_SECONDARY,
    BG_TERTIARY,
    BG_CARD,
    BG_STEP_HEADER,
    BG_HOVER,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    ACCENT_BLUE,
    ACCENT_BLUE_HOVER,
    ACCENT_GREEN,
    ACCENT_YELLOW,
    CYAN_ACCENT,
    BORDER_COLOR,
    FONT_FAMILY,
    FONT_MONO,
    STEP_ACTIVE_COLOR,
    STEP_INACTIVE_COLOR,
)


class StepPanel(tk.Frame):
    """
    Painel lateral esquerdo com os 3 passos do fluxo do streamer:
    Passo 1: Seleção de vídeo
    Passo 2: Opções de IA (legendas, silêncios, 9:16, zoom, score)
    Passo 3: Botão Hero de Execução da Esteira
    """

    def __init__(
        self,
        master,
        on_select_video: Callable[[], None],
        on_generate: Callable[[], None],
        var_legendas: tk.BooleanVar,
        var_estilo_legenda: tk.StringVar,
        var_silencios: tk.BooleanVar,
        var_916: tk.BooleanVar,
        var_zoom_rosto: tk.BooleanVar,
        var_nota_minima: tk.IntVar,
        var_tipo_momento: tk.StringVar,
        **kwargs
    ):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)

        self.on_select_video = on_select_video
        self.on_generate = on_generate

        self.var_legendas = var_legendas
        self.var_estilo_legenda = var_estilo_legenda
        self.var_silencios = var_silencios
        self.var_916 = var_916
        self.var_zoom_rosto = var_zoom_rosto
        self.var_nota_minima = var_nota_minima
        self.var_tipo_momento = var_tipo_momento

        self.video_carregado = False

        self._build_ui()

    def _build_ui(self):
        # ═════════════════════════════════════════════════════════════════════
        # PASSO 1: VÍDEO DE ENTRADA
        # ═════════════════════════════════════════════════════════════════════
        self.p1_card = tk.Frame(self, bg=BG_TERTIARY, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1)
        self.p1_card.pack(fill="x", padx=8, pady=(8, 4))

        p1_header = tk.Frame(self.p1_card, bg=BG_STEP_HEADER, height=26)
        p1_header.pack(fill="x")
        p1_header.pack_propagate(False)

        self.lbl_p1_title = tk.Label(
            p1_header,
            text="📂 PASSO 1: VÍDEO DE ENTRADA",
            font=(FONT_FAMILY, 8, "bold"),
            bg=BG_STEP_HEADER,
            fg=CYAN_ACCENT
        )
        self.lbl_p1_title.pack(side="left", padx=8, pady=3)

        self.lbl_p1_status = tk.Label(
            p1_header,
            text="○ Pendente",
            font=(FONT_FAMILY, 8),
            bg=BG_STEP_HEADER,
            fg=STEP_INACTIVE_COLOR
        )
        self.lbl_p1_status.pack(side="right", padx=8, pady=3)

        p1_body = tk.Frame(self.p1_card, bg=BG_TERTIARY, padx=8, pady=8)
        p1_body.pack(fill="x")

        self.btn_select_video = tk.Button(
            p1_body,
            text="📁 Escolher Vídeo da Live...",
            font=(FONT_FAMILY, 9, "bold"),
            bg="#1e293b",
            fg="#f8fafc",
            activebackground="#334155",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=10,
            pady=8,
            cursor="hand2",
            command=self.on_select_video
        )
        self.btn_select_video.pack(fill="x")

        self.lbl_video_nome = tk.Label(
            p1_body,
            text="Nenhum arquivo selecionado",
            font=(FONT_FAMILY, 8),
            bg=BG_TERTIARY,
            fg=TEXT_MUTED,
            anchor="w"
        )
        self.lbl_video_nome.pack(fill="x", pady=(4, 0))

        # ═════════════════════════════════════════════════════════════════════
        # PASSO 2: OPÇÕES DA ESTEIRA
        # ═════════════════════════════════════════════════════════════════════
        self.p2_card = tk.Frame(self, bg=BG_TERTIARY, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1)
        self.p2_card.pack(fill="x", padx=8, pady=4)

        p2_header = tk.Frame(self.p2_card, bg=BG_STEP_HEADER, height=26)
        p2_header.pack(fill="x")
        p2_header.pack_propagate(False)

        tk.Label(
            p2_header,
            text="⚙️ PASSO 2: OPÇÕES DA ESTEIRA",
            font=(FONT_FAMILY, 8, "bold"),
            bg=BG_STEP_HEADER,
            fg=CYAN_ACCENT
        ).pack(side="left", padx=8, pady=3)

        p2_body = tk.Frame(self.p2_card, bg=BG_TERTIARY, padx=10, pady=8)
        p2_body.pack(fill="x")

        # 1. Legendas com IA
        chk_legendas = tk.Checkbutton(
            p2_body,
            text="💬 Gerar Legendas com IA (Whisper)",
            variable=self.var_legendas,
            font=(FONT_FAMILY, 9, "bold"),
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            selectcolor="#0f172a",
            activebackground=BG_TERTIARY,
            activeforeground=TEXT_PRIMARY,
            command=self._on_toggle_legendas
        )
        chk_legendas.pack(anchor="w", pady=(0, 2))

        # Estilo de Legenda
        self.f_estilo = tk.Frame(p2_body, bg=BG_TERTIARY)
        self.f_estilo.pack(fill="x", padx=(20, 0), pady=(0, 6))

        tk.Label(self.f_estilo, text="Estilo Visual:", font=(FONT_FAMILY, 8), bg=BG_TERTIARY, fg=TEXT_SECONDARY).pack(side="left")
        cb_estilo = ttk.Combobox(
            self.f_estilo,
            textvariable=self.var_estilo_legenda,
            values=["TikTok Bold Yellow", "Glow Cyan Modern", "Classic White"],
            state="readonly",
            width=18
        )
        cb_estilo.pack(side="left", padx=(6, 0))

        # 2. Silêncios
        chk_silencios = tk.Checkbutton(
            p2_body,
            text="✂️ Remover Silêncios (Dead Air)",
            variable=self.var_silencios,
            font=(FONT_FAMILY, 9),
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            selectcolor="#0f172a",
            activebackground=BG_TERTIARY,
            activeforeground=TEXT_PRIMARY
        )
        chk_silencios.pack(anchor="w", pady=(0, 4))

        # 3. Enquadramento 9:16 Vertical
        chk_916 = tk.Checkbutton(
            p2_body,
            text="📱 Formato 9:16 (TikTok/Reels)",
            variable=self.var_916,
            font=(FONT_FAMILY, 9),
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            selectcolor="#0f172a",
            activebackground=BG_TERTIARY,
            activeforeground=TEXT_PRIMARY
        )
        chk_916.pack(anchor="w", pady=(0, 4))

        # 4. Zoom no Rosto
        chk_zoom = tk.Checkbutton(
            p2_body,
            text="🔍 Auto-Zoom Inteligente no Rosto",
            variable=self.var_zoom_rosto,
            font=(FONT_FAMILY, 9),
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            selectcolor="#0f172a",
            activebackground=BG_TERTIARY,
            activeforeground=TEXT_PRIMARY
        )
        chk_zoom.pack(anchor="w", pady=(0, 6))

        # 5. Nota Mínima e Tipo de Momento
        f_score_row = tk.Frame(p2_body, bg=BG_TERTIARY)
        f_score_row.pack(fill="x", pady=(2, 4))

        tk.Label(f_score_row, text="Nota Mínima (1-10):", font=(FONT_FAMILY, 8), bg=BG_TERTIARY, fg=TEXT_SECONDARY).pack(side="left")
        sp_nota = tk.Spinbox(f_score_row, from_=1, to=10, textvariable=self.var_nota_minima, width=4, font=(FONT_FAMILY, 8))
        sp_nota.pack(side="left", padx=(6, 0))

        f_tipo_row = tk.Frame(p2_body, bg=BG_TERTIARY)
        f_tipo_row.pack(fill="x", pady=(2, 2))

        tk.Label(f_tipo_row, text="Tipo de Corte:", font=(FONT_FAMILY, 8), bg=BG_TERTIARY, fg=TEXT_SECONDARY).pack(side="left")
        cb_tipo = ttk.Combobox(
            f_tipo_row,
            textvariable=self.var_tipo_momento,
            values=["Todos os Momentos", "Apenas Épicos", "Apenas Engraçados"],
            state="readonly",
            width=16
        )
        cb_tipo.pack(side="left", padx=(6, 0))

        # ═════════════════════════════════════════════════════════════════════
        # PASSO 3: BOTÃO HERO DE EXECUÇÃO
        # ═════════════════════════════════════════════════════════════════════
        self.p3_card = tk.Frame(self, bg=BG_TERTIARY, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1)
        self.p3_card.pack(fill="x", padx=8, pady=(4, 8))

        p3_header = tk.Frame(self.p3_card, bg=BG_STEP_HEADER, height=26)
        p3_header.pack(fill="x")
        p3_header.pack_propagate(False)

        tk.Label(
            p3_header,
            text="🚀 PASSO 3: GERAR CORTES",
            font=(FONT_FAMILY, 8, "bold"),
            bg=BG_STEP_HEADER,
            fg=CYAN_ACCENT
        ).pack(side="left", padx=8, pady=3)

        p3_body = tk.Frame(self.p3_card, bg=BG_TERTIARY, padx=8, pady=8)
        p3_body.pack(fill="x")

        self.btn_gerar_cortes = tk.Button(
            p3_body,
            text="🚀 GERAR CORTES VIRAIS",
            font=(FONT_FAMILY, 10, "bold"),
            bg="#0284c7",
            fg="#ffffff",
            activebackground="#0369a1",
            activeforeground="#ffffff",
            disabledforeground="#64748b",
            bd=0,
            relief="flat",
            padx=12,
            pady=12,
            cursor="hand2",
            command=self.on_generate
        )
        self.btn_gerar_cortes.pack(fill="x")

    def _on_toggle_legendas(self):
        if self.var_legendas.get():
            for child in self.f_estilo.winfo_children():
                child.configure(state="normal")
        else:
            for child in self.f_estilo.winfo_children():
                child.configure(state="disabled")

    def marcar_video_selecionado(self, caminho_ou_nome: str):
        """Atualiza visual do Passo 1 para estado concluído."""
        self.video_carregado = True
        nome = Path(caminho_ou_nome).name if caminho_ou_nome else "Vídeo Carregado"
        self.lbl_video_nome.config(text=f"🎥 {nome[:26]}{'...' if len(nome) > 26 else ''}", fg=TEXT_PRIMARY)
        self.lbl_p1_status.config(text="● Carregado", fg=ACCENT_GREEN)
        self.p1_card.config(highlightbackground=ACCENT_GREEN)
        self.btn_select_video.config(bg="#064e3b", fg="#34d399", text="✓ Trocar Vídeo")

    def set_gerando(self, rodando: bool):
        """Habilita ou desabilita controles durante o processamento da esteira."""
        if rodando:
            self.btn_gerar_cortes.config(state="disabled", text="⏳ Processando Esteira...", bg="#1e293b")
            self.btn_select_video.config(state="disabled")
        else:
            self.btn_gerar_cortes.config(state="normal", text="🚀 GERAR CORTES VIRAIS", bg="#0284c7")
            self.btn_select_video.config(state="normal")
