"""
Componente VideoPlayer para pré-visualização interativa de vídeo.
Extração rápida de frames sob demanda via FFmpeg com exibição em Canvas.
"""

import os
import sys
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional, Callable

import tkinter as tk
from tkinter import ttk

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    ACCENT_BLUE,
    FONT_FAMILY,
    FONT_MONO
)


def formatar_timecode(segundos: float) -> str:
    """Converte segundos para string HH:MM:SS."""
    seg = max(0.0, float(segundos))
    hrs = int(seg // 3600)
    mins = int((seg % 3600) // 60)
    secs = int(seg % 60)
    return f"{hrs:02d}:{mins:02d}:{secs:02d}"


class VideoPlayer(tk.Frame):
    """
    Player de vídeo nativo em Canvas com extração de frames via FFmpeg.
    Permite busca precisa (seek), controle play/pause e timecode display.
    """

    def __init__(self, master, on_seek: Optional[Callable[[float], None]] = None, **kwargs):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)
        self.on_seek_callback = on_seek
        self.video_path: Optional[Path] = None
        self.duracao: float = 0.0
        self.posicao_atual: float = 0.0
        self.is_playing: bool = False
        self._lock = threading.Lock()
        self._current_photo_image = None
        self._seek_job = None

        self._build_ui()

    def _build_ui(self):
        # 1. Canvas de Visualização do Frame
        self.canvas_frame = tk.Frame(self, bg="#000000", bd=1, relief="solid")
        self.canvas_frame.pack(fill="both", expand=True, padx=4, pady=(4, 2))

        self.canvas = tk.Canvas(
            self.canvas_frame,
            bg="#000000",
            highlightthickness=0,
            cursor="crosshair"
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        # Mensagem inicial se nenhum vídeo estiver carregado
        self._draw_placeholder("Nenhum vídeo carregado no player")

        # 2. Barra de Controles Inferior
        self.ctrl_bar = tk.Frame(self, bg=BG_SECONDARY)
        self.ctrl_bar.pack(fill="x", padx=4, pady=4)

        # Botões de Navegação
        self.btn_jump_back = tk.Button(
            self.ctrl_bar, text="⏮", bg=BG_TERTIARY, fg=TEXT_PRIMARY,
            bd=0, padx=6, pady=2, font=(FONT_FAMILY, 9),
            command=lambda: self.seek(self.posicao_atual - 5.0)
        )
        self.btn_jump_back.pack(side="left", padx=2)

        self.btn_play = tk.Button(
            self.ctrl_bar, text="▶", bg=ACCENT_BLUE, fg="#ffffff",
            bd=0, padx=10, pady=2, font=(FONT_FAMILY, 10, "bold"),
            command=self.toggle_play
        )
        self.btn_play.pack(side="left", padx=2)

        self.btn_jump_fwd = tk.Button(
            self.ctrl_bar, text="⏭", bg=BG_TERTIARY, fg=TEXT_PRIMARY,
            bd=0, padx=6, pady=2, font=(FONT_FAMILY, 9),
            command=lambda: self.seek(self.posicao_atual + 5.0)
        )
        self.btn_jump_fwd.pack(side="left", padx=2)

        # Slider de Posição
        self.slider_var = tk.DoubleVar(value=0.0)
        self.slider = ttk.Scale(
            self.ctrl_bar,
            from_=0.0,
            to=100.0,
            orient="horizontal",
            variable=self.slider_var,
            command=self._on_slider_moved
        )
        self.slider.pack(side="left", fill="x", expand=True, padx=8)

        # Label de Timecode
        self.lbl_timecode = tk.Label(
            self.ctrl_bar,
            text="00:00:00 / 00:00:00",
            bg=BG_SECONDARY,
            fg=TEXT_SECONDARY,
            font=(FONT_MONO, 9)
        )
        self.lbl_timecode.pack(side="right", padx=4)

    def _draw_placeholder(self, texto: str):
        self.canvas.delete("all")
        w = max(200, self.canvas.winfo_width())
        h = max(150, self.canvas.winfo_height())
        self.canvas.create_text(
            w // 2, h // 2,
            text=f"🎬 {texto}",
            fill=TEXT_SECONDARY,
            font=(FONT_FAMILY, 11)
        )

    def _on_canvas_resize(self, event):
        if self.video_path:
            self._render_current_frame()
        else:
            self._draw_placeholder("Nenhum vídeo carregado no player")

    def carregar_video(self, path: Path):
        """Carrega um novo arquivo de vídeo e inicializa a duração e o primeiro frame."""
        if not path or not Path(path).exists():
            return

        self.video_path = Path(path)
        self.duracao = self._obter_duracao_video(self.video_path)
        self.slider.config(to=max(1.0, self.duracao))
        self.posicao_atual = 0.0
        self.slider_var.set(0.0)
        self._atualizar_timecode_label()
        self.seek(0.0)

    def _obter_duracao_video(self, path: Path) -> float:
        """Obtém duração precisa do vídeo via ffprobe."""
        try:
            cmd = [
                "ffprobe", "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(path)
            ]
            cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == 'nt' else 0
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10, creationflags=cflags)
            if res.returncode == 0 and res.stdout.strip():
                return float(res.stdout.strip())
        except Exception:
            pass
        return 60.0

    def _on_slider_moved(self, val):
        try:
            pos = float(val)
            if self._seek_job:
                self.after_cancel(self._seek_job)
            self._seek_job = self.after(30, lambda: self.seek(pos, disparar_callback=True))
        except Exception:
            pass

    def seek(self, segundos: float, disparar_callback: bool = True):
        """Posiciona a agulha de reprodução no tempo especificado e renderiza o frame."""
        seg = max(0.0, min(self.duracao, float(segundos)))
        self.posicao_atual = seg
        self.slider_var.set(seg)
        self._atualizar_timecode_label()

        threading.Thread(target=self._extrair_e_exibir_frame, args=(seg,), daemon=True).start()

        if disparar_callback and self.on_seek_callback:
            try:
                self.on_seek_callback(seg)
            except Exception:
                pass

    def _extrair_e_exibir_frame(self, pos: float):
        """Extrai o frame via FFmpeg pipe de forma rápida e segura."""
        if not self.video_path or not HAS_PIL:
            return

        try:
            cmd = [
                "ffmpeg", "-ss", f"{pos:.3f}",
                "-i", str(self.video_path),
                "-vframes", "1",
                "-f", "image2pipe",
                "-vcodec", "png",
                "-"
            ]
            cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == 'nt' else 0
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                creationflags=cflags
            )
            stdout_data, _ = proc.communicate(timeout=4)
            if stdout_data:
                import io
                img = Image.open(io.BytesIO(stdout_data))
                self.after(0, self._desenhar_imagem_no_canvas, img)
        except Exception:
            pass

    def _desenhar_imagem_no_canvas(self, img: Image.Image):
        """Redimensiona e plota o frame centralizado no Canvas respeitando aspect ratio."""
        if not HAS_PIL:
            return

        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw <= 10 or ch <= 10:
            return

        iw, ih = img.size
        escala = min(cw / iw, ch / ih)
        nw, nh = max(1, int(iw * escala)), max(1, int(ih * escala))

        img_redimensionada = img.resize((nw, nh), Image.Resampling.BILINEAR)
        self._current_photo_image = ImageTk.PhotoImage(img_redimensionada)

        self.canvas.delete("all")
        x_centro = cw // 2
        y_centro = ch // 2
        self.canvas.create_image(x_centro, y_centro, image=self._current_photo_image, anchor="center")

    def _render_current_frame(self):
        if self.video_path:
            self._extrair_e_exibir_frame(self.posicao_atual)

    def _atualizar_timecode_label(self):
        t_atual = formatar_timecode(self.posicao_atual)
        t_total = formatar_timecode(self.duracao)
        self.lbl_timecode.config(text=f"{t_atual} / {t_total}")

    def toggle_play(self):
        if self.is_playing:
            self.pause()
        else:
            self.play()

    def play(self):
        if not self.video_path:
            return
        self.is_playing = True
        self.btn_play.config(text="⏸", bg="#eab308")
        self._play_loop()

    def pause(self):
        self.is_playing = False
        self.btn_play.config(text="▶", bg=ACCENT_BLUE)

    def _play_loop(self):
        if not self.is_playing:
            return
        proxima_pos = self.posicao_atual + 0.1
        if proxima_pos >= self.duracao:
            self.pause()
            self.seek(0.0)
            return
        self.seek(proxima_pos)
        self.after(100, self._play_loop)
