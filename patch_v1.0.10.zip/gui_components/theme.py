"""
Design System e Paleta de Cores para a interface Pro.
Inspirado na estética moderna do LiveCutter / DaVinci Resolve.
"""

# Cores de Fundo (Obsidian Profundo & Camadas)
BG_PRIMARY = "#0d1117"       # Fundo principal da aplicação
BG_SECONDARY = "#161b22"     # Painéis laterais e cartões
BG_TERTIARY = "#21262d"      # Inputs, cards internos e áreas ativas
BG_HOVER = "#30363d"         # Hover de botões e itens selecionados

# Bordas e Divisores
BORDER_COLOR = "#30363d"     # Linhas estruturais sutis
BORDER_FOCUS = "#58a6ff"     # Destaque de foco

# Tipografia
TEXT_PRIMARY = "#f0f6fc"     # Branco brilhante para leitura
TEXT_SECONDARY = "#8b949e"   # Cinza suave para metadados e timestamps
TEXT_MUTED = "#6e7681"       # Texto desabilitado ou placeholders

# Cores de Acento e Status
ACCENT_BLUE = "#58a6ff"      # Acento principal (Playhead, botões primários)
ACCENT_BLUE_HOVER = "#388bfd"# Hover do botão primário
ACCENT_GREEN = "#3fb950"     # Sucesso, áudio track, render concluído
ACCENT_ORANGE = "#d29922"    # Alertas, transcrição track, avisos
ACCENT_RED = "#f85149"       # Parar, erros, marcação inicial de corte
CYAN_ACCENT = "#38bdf8"      # Destaque dinâmico e legendas
PURPLE_ACCENT = "#bc8cff"    # Emoções / IA destaques

# Timeline Track Colors
COLOR_TRACK_VIDEO = "#1f6feb" # Azul vídeo
COLOR_TRACK_AUDIO = "#238636" # Verde áudio
COLOR_TRACK_SUBS = "#9e6a03"  # Âmbar legendas

# Fontes Padrão do Sistema
FONT_FAMILY = "Segoe UI"
FONT_MONO = "Cascadia Code"

# Cards e Superfícies (Redesign v2.0)
BG_CARD = "#1c2128"              # Fundo de cards de corte na galeria
BG_STEP_HEADER = "#0d1117"       # Fundo dos headers de passo

# Acentos Novos
ACCENT_YELLOW = "#f0b429"        # Destaque amarelo TikTok Bold
ACCENT_PURPLE_DIM = "#8b5cf6"    # Roxo suave para badges e scores
BADGE_BG = "#1f2937"             # Fundo de badges de score

# Estados do Pipeline
STEP_ACTIVE_COLOR = "#3fb950"    # Verde para passo/etapa ativa
STEP_INACTIVE_COLOR = "#6e7681"  # Cinza para passo/etapa inativo

