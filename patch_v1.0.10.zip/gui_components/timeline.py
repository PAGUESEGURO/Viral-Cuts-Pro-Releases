"""
Componente TimelineWidget para edição e visualização multi-track (Vídeo, Áudio, Legendas).
Permite visualização em camadas com playhead sincronizado e blocos de corte interativos.
"""

from pathlib import Path
from typing import Optional, Callable, Dict, Any, List

import tkinter as tk

from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    ACCENT_BLUE,
    ACCENT_RED,
    CYAN_ACCENT,
    COLOR_TRACK_VIDEO,
    COLOR_TRACK_AUDIO,
    COLOR_TRACK_SUBS,
    FONT_FAMILY,
    FONT_MONO
)


class TimelineWidget(tk.Frame):
    """
    Timeline multi-track profissional com faixas de Vídeo, Áudio e Legendas.
    Suporta playhead vertical, blocos de cortes e interação de zoom/scroll.
    """

    def __init__(self, master, on_seek: Optional[Callable[[float], None]] = None, **kwargs):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)
        self.on_seek = on_seek
        self.duracao: float = 60.0
        self.playhead_pos: float = 0.0
        self.zoom_factor: float = 1.0  # pixels por segundo

        # Estrutura de Faixas (Tracks)
        self.tracks = {
            "video": {"nome": "🎥 Video Track 1", "cor": COLOR_TRACK_VIDEO, "blocos": []},
            "audio": {"nome": "🎵 Audio Track 1", "cor": COLOR_TRACK_AUDIO, "blocos": []},
            "subtitles": {"nome": "💬 Subtitles", "cor": COLOR_TRACK_SUBS, "blocos": []}
        }

        self._build_ui()

    def _build_ui(self):
        # 1. Toolbar superior da Timeline
        self.toolbar = tk.Frame(self, bg=BG_TERTIARY, height=28)
        self.toolbar.pack(fill="x", padx=2, pady=2)

        tk.Label(
            self.toolbar,
            text="Timeline",
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            font=(FONT_FAMILY, 9, "bold")
        ).pack(side="left", padx=8)

        # Botões de Ferramentas
        for icone, txt in [("✂️", "Split"), ("🔍+", "Zoom In"), ("🔍-", "Zoom Out")]:
            btn = tk.Button(
                self.toolbar,
                text=f"{icone} {txt}",
                bg=BG_SECONDARY,
                fg=TEXT_SECONDARY,
                bd=0,
                padx=6,
                pady=1,
                font=(FONT_FAMILY, 8),
                command=lambda t=txt: self._on_tool_click(t)
            )
            btn.pack(side="left", padx=2)

        # 2. Área Central Canvas
        self.canvas = tk.Canvas(
            self,
            bg=BG_PRIMARY,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR,
            cursor="crosshair"
        )
        self.canvas.pack(fill="both", expand=True, padx=2, pady=2)

        self.canvas.bind("<Configure>", lambda e: self._redesenhar())
        self.canvas.bind("<ButtonPress-1>", self._on_click)
        self.canvas.bind("<B1-Motion>", self._on_drag)

    def _on_tool_click(self, tool_name: str):
        if tool_name == "Zoom In":
            self.zoom_factor = min(5.0, self.zoom_factor * 1.3)
            self._redesenhar()
        elif tool_name == "Zoom Out":
            self.zoom_factor = max(0.5, self.zoom_factor / 1.3)
            self._redesenhar()

    def set_duracao(self, duracao: float):
        self.duracao = max(1.0, float(duracao))
        self._redesenhar()

    def posicionar_playhead(self, segundos: float):
        self.playhead_pos = max(0.0, min(self.duracao, float(segundos)))
        self._redesenhar()

    def adicionar_bloco_corte(self, track: str, start: float, end: float, rotulo: str = ""):
        """Adiciona um bloco visual representando um trecho de vídeo, áudio ou legenda."""
        if track in self.tracks:
            self.tracks[track]["blocos"].append({
                "start": float(start),
                "end": float(end),
                "label": rotulo
            })
            self._redesenhar()

    def limpar_blocos(self):
        for k in self.tracks:
            self.tracks[k]["blocos"].clear()
        self._redesenhar()

    def _tempo_para_x(self, t: float) -> float:
        w_canvas = self.canvas.winfo_width() - 120  # Reserva 120px para nomes das faixas
        if self.duracao <= 0 or w_canvas <= 0:
            return 120
        return 120 + (t / self.duracao) * w_canvas * self.zoom_factor

    def _x_para_tempo(self, x: float) -> float:
        w_canvas = self.canvas.winfo_width() - 120
        if w_canvas <= 0 or self.zoom_factor <= 0:
            return 0.0
        rel_x = max(0, x - 120)
        return max(0.0, min(self.duracao, (rel_x / (w_canvas * self.zoom_factor)) * self.duracao))

    def _redesenhar(self):
        self.canvas.delete("all")
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w <= 10 or h <= 10:
            return

        track_h = 28
        track_gap = 4
        y_offset = 24  # Espaço para régua de tempo

        # 1. Régua de Tempo Superior
        self.canvas.create_rectangle(0, 0, w, y_offset, fill=BG_TERTIARY, outline=BORDER_COLOR)
        passo_tempo = max(5.0, 15.0 / self.zoom_factor)
        t = 0.0
        while t <= self.duracao:
            x = self._tempo_para_x(t)
            if 120 <= x <= w:
                mins = int(t // 60)
                secs = int(t % 60)
                self.canvas.create_line(x, 14, x, y_offset, fill=BORDER_COLOR)
                self.canvas.create_text(x + 2, 8, text=f"{mins:02d}:{secs:02d}", fill=TEXT_MUTED, font=(FONT_MONO, 7), anchor="nw")
            t += passo_tempo

        # 2. Faixas (Tracks)
        for chave, track_info in self.tracks.items():
            # Cabeçalho da faixa
            self.canvas.create_rectangle(0, y_offset, 120, y_offset + track_h, fill=BG_SECONDARY, outline=BORDER_COLOR)
            self.canvas.create_text(
                8, y_offset + track_h // 2,
                text=track_info["nome"],
                fill=TEXT_PRIMARY,
                font=(FONT_FAMILY, 8, "bold"),
                anchor="w"
            )

            # Linha de fundo da faixa
            self.canvas.create_rectangle(120, y_offset, w, y_offset + track_h, fill=BG_PRIMARY, outline=BORDER_COLOR)

            # Blocos na faixa
            for b in track_info["blocos"]:
                bx1 = self._tempo_para_x(b["start"])
                bx2 = self._tempo_para_x(b["end"])
                if bx2 > 120 and bx1 < w:
                    self.canvas.create_rectangle(
                        max(120, bx1), y_offset + 2,
                        min(w, bx2), y_offset + track_h - 2,
                        fill=track_info["cor"],
                        outline="#ffffff",
                        width=1
                    )
                    lbl = b.get("label", "")
                    if lbl and (bx2 - bx1) > 30:
                        self.canvas.create_text(
                            max(124, bx1 + 4), y_offset + track_h // 2,
                            text=lbl[:15],
                            fill="#ffffff",
                            font=(FONT_FAMILY, 8),
                            anchor="w"
                        )

            y_offset += track_h + track_gap

        # 3. Agulha de Reprodução (Playhead Vermelho)
        px = self._tempo_para_x(self.playhead_pos)
        if 120 <= px <= w:
            self.canvas.create_line(px, 0, px, h, fill=ACCENT_RED, width=2)
            self.canvas.create_polygon(px - 5, 0, px + 5, 0, px, 8, fill=ACCENT_RED)

    def _on_click(self, event):
        t = self._x_para_tempo(event.x)
        self.posicionar_playhead(t)
        if self.on_seek:
            self.on_seek(t)

    def _on_drag(self, event):
        t = self._x_para_tempo(event.x)
        self.posicionar_playhead(t)
        if self.on_seek:
            self.on_seek(t)
