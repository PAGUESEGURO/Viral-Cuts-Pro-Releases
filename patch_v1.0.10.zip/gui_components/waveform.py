"""
Componente WaveformDisplay para visualização e seleção interativa da forma de onda de áudio.
Gera o mapa sonoro via FFmpeg showwavespic e suporta seleção visual de recorte [Clip Segment].
"""

import os
import sys
import subprocess
import threading
from pathlib import Path
from typing import Optional, Callable

import tkinter as tk

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

from .theme import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    ACCENT_BLUE,
    ACCENT_RED,
    CYAN_ACCENT,
    FONT_FAMILY,
    FONT_MONO
)


class WaveformDisplay(tk.Canvas):
    """
    Forma de onda interativa com marcadores de início (vermelho) e fim (azul) de corte.
    Permite arrastar a região e clicar para posicionar a agulha de reprodução.
    """

    def __init__(
        self,
        master,
        height: int = 76,
        on_region_change: Optional[Callable[[float, float], None]] = None,
        on_seek: Optional[Callable[[float], None]] = None,
        **kwargs
    ):
        super().__init__(
            master,
            height=height,
            bg=BG_PRIMARY,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR,
            cursor="hand2",
            **kwargs
        )
        self.on_region_change = on_region_change
        self.on_seek = on_seek

        self.video_path: Optional[Path] = None
        self.duracao: float = 60.0
        self.playhead_pos: float = 0.0

        # Região de recorte selecionada [Clip Segment]
        self.clip_start: float = 0.0
        self.clip_end: float = 30.0

        self._waveform_img: Optional[Image.Image] = None
        self._photo_waveform = None
        self._dragging_handle = None  # "start", "end", "middle", "playhead"

        self.bind("<Configure>", self._on_resize)
        self.bind("<ButtonPress-1>", self._on_mouse_down)
        self.bind("<B1-Motion>", self._on_mouse_drag)
        self.bind("<ButtonRelease-1>", self._on_mouse_up)

    def _on_resize(self, event):
        self._redesenhar()

    def carregar_audio_video(self, path: Path, duracao: float):
        """Carrega vídeo e inicia thread para sintetizar a forma de onda."""
        if not path or not Path(path).exists():
            return

        self.video_path = Path(path)
        self.duracao = max(1.0, float(duracao))
        self.clip_start = 0.0
        self.clip_end = min(self.duracao, 60.0)

        threading.Thread(target=self._gerar_waveform_ffmpeg, daemon=True).start()

    def _gerar_waveform_ffmpeg(self):
        """Executa FFmpeg showwavespic para criar o gráfico sonoro."""
        if not self.video_path or not HAS_PIL:
            return

        w = max(400, self.winfo_width())
        h = max(40, self.winfo_height())

        try:
            cmd = [
                "ffmpeg", "-y",
                "-i", str(self.video_path),
                "-filter_complex", f"aformat=channel_layouts=mono,showwavespic=s={w}x{h}:colors=#38bdf8@0.75|#0284c7@0.9",
                "-frames:v", "1",
                "-f", "image2pipe",
                "-vcodec", "png",
                "-"
            ]
            cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == 'nt' else 0
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=cflags)
            stdout_data, _ = proc.communicate(timeout=15)
            if stdout_data:
                import io
                self._waveform_img = Image.open(io.BytesIO(stdout_data))
                self.after(0, self._redesenhar)
        except Exception:
            pass

    def posicionar_playhead(self, segundos: float):
        """Move o marcador vertical da agulha de reprodução."""
        self.playhead_pos = max(0.0, min(self.duracao, float(segundos)))
        self._redesenhar()

    def definir_regiao_corte(self, start: float, end: float):
        """Atualiza a região selecionada do corte."""
        self.clip_start = max(0.0, min(self.duracao, float(start)))
        self.clip_end = max(self.clip_start + 1.0, min(self.duracao, float(end)))
        self._redesenhar()

    def _tempo_para_x(self, t: float) -> float:
        w = self.winfo_width()
        if self.duracao <= 0 or w <= 0:
            return 0
        return (t / self.duracao) * w

    def _x_para_tempo(self, x: float) -> float:
        w = self.winfo_width()
        if w <= 0:
            return 0.0
        return max(0.0, min(self.duracao, (x / w) * self.duracao))

    def _redesenhar(self):
        self.delete("all")
        w = self.winfo_width()
        h = self.winfo_height()
        if w <= 10 or h <= 10:
            return

        # 1. Desenhar imagem da forma de onda
        if self._waveform_img and HAS_PIL:
            img_redim = self._waveform_img.resize((w, h), Image.Resampling.BILINEAR)
            self._photo_waveform = ImageTk.PhotoImage(img_redim)
            self.create_image(0, 0, image=self._photo_waveform, anchor="nw")
        else:
            # Placeholder estilizado
            self.create_line(0, h // 2, w, h // 2, fill="#1e293b", width=2)
            self.create_text(
                w // 2, h // 2,
                text="Forma de onda de áudio",
                fill=TEXT_SECONDARY,
                font=(FONT_FAMILY, 9)
            )

        # 2. Desenhar Área de Recorte [Clip Segment]
        x1 = self._tempo_para_x(self.clip_start)
        x2 = self._tempo_para_x(self.clip_end)

        # Retângulo sombreado da seleção
        self.create_rectangle(x1, 0, x2, h, fill="#38bdf8", stipple="gray25", outline="")

        # Alça Inicial (Vermelha)
        self.create_line(x1, 0, x1, h, fill=ACCENT_RED, width=3)
        self.create_oval(x1 - 5, h - 14, x1 + 5, h - 2, fill=ACCENT_RED, outline="#ffffff")

        # Alça Final (Azul)
        self.create_line(x2, 0, x2, h, fill=ACCENT_BLUE, width=3)
        self.create_oval(x2 - 5, h - 14, x2 + 5, h - 2, fill=ACCENT_BLUE, outline="#ffffff")

        # Rótulo de Região Centralizado
        cx = (x1 + x2) / 2
        dur_clip = self.clip_end - self.clip_start
        self.create_text(
            cx, h // 2,
            text=f"Clip Segment ({dur_clip:.1f}s)",
            fill="#ffffff",
            font=(FONT_FAMILY, 9, "bold")
        )

        # 3. Playhead Atual
        px = self._tempo_para_x(self.playhead_pos)
        self.create_line(px, 0, px, h, fill="#ffffff", width=2)

    def _on_mouse_down(self, event):
        x = event.x
        x_start = self._tempo_para_x(self.clip_start)
        x_end = self._tempo_para_x(self.clip_end)

        if abs(x - x_start) <= 10:
            self._dragging_handle = "start"
        elif abs(x - x_end) <= 10:
            self._dragging_handle = "end"
        elif x_start < x < x_end:
            self._dragging_handle = "middle"
            self._drag_offset_t = self._x_para_tempo(x) - self.clip_start
        else:
            self._dragging_handle = "playhead"
            t = self._x_para_tempo(x)
            self.posicionar_playhead(t)
            if self.on_seek:
                self.on_seek(t)

    def _on_mouse_drag(self, event):
        if not self._dragging_handle:
            return

        t_mouse = self._x_para_tempo(event.x)

        if self._dragging_handle == "start":
            self.clip_start = max(0.0, min(self.clip_end - 1.0, t_mouse))
        elif self._dragging_handle == "end":
            self.clip_end = max(self.clip_start + 1.0, min(self.duracao, t_mouse))
        elif self._dragging_handle == "middle":
            dur = self.clip_end - self.clip_start
            n_start = max(0.0, min(self.duracao - dur, t_mouse - self._drag_offset_t))
            self.clip_start = n_start
            self.clip_end = n_start + dur
        elif self._dragging_handle == "playhead":
            self.posicionar_playhead(t_mouse)
            if self.on_seek:
                self.on_seek(t_mouse)

        self._redesenhar()
        if self.on_region_change and self._dragging_handle in ("start", "end", "middle"):
            self.on_region_change(self.clip_start, self.clip_end)

    def _on_mouse_up(self, event):
        self._dragging_handle = None
