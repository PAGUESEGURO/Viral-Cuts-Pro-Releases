"""
=============================================================================
VIRAL CUTS PRO - PAINEL DE DESTAQUES DE IA (SIMPLIFICADO)
=============================================================================
"""

import tkinter as tk
from typing import Optional, Callable

from .theme import (
    BG_SECONDARY,
    BG_TERTIARY,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    CYAN_ACCENT,
    FONT_FAMILY
)


class AIHighlightsPanel(tk.Frame):
    """
    Painel complementar de atalhos rápidos e destaques de IA.
    """

    def __init__(self, master, on_generate: Optional[Callable[[], None]] = None, **kwargs):
        super().__init__(master, bg=BG_SECONDARY, **kwargs)
        self.on_generate = on_generate

        self._build_ui()

    def _build_ui(self):
        header = tk.Frame(self, bg=BG_SECONDARY)
        header.pack(fill="x", padx=8, pady=(6, 4))

        tk.Label(
            header,
            text="✨ AI Highlights & Ações",
            bg=BG_SECONDARY,
            fg=CYAN_ACCENT,
            font=(FONT_FAMILY, 9, "bold")
        ).pack(side="left")

        # Botão CTA Principal
        self.btn_gerar = tk.Button(
            self,
            text="🚀 Generate Clips & Subtitles",
            bg="#0284c7",
            fg="#ffffff",
            activebackground="#0369a1",
            activeforeground="#ffffff",
            bd=0,
            padx=12,
            pady=10,
            font=(FONT_FAMILY, 10, "bold"),
            cursor="hand2",
            command=self._on_generate_click
        )
        self.btn_gerar.pack(fill="x", padx=8, pady=(6, 4))

        # Ações complementares
        btn_busca = tk.Button(
            self,
            text="🔍 Buscar Momentos Mais Engraçados",
            bg=BG_TERTIARY,
            fg=TEXT_PRIMARY,
            activebackground="#30363d",
            activeforeground="#ffffff",
            bd=0,
            padx=8,
            pady=6,
            font=(FONT_FAMILY, 8),
            anchor="w",
            cursor="hand2",
            command=self._on_generate_click
        )
        btn_busca.pack(fill="x", padx=8, pady=2)

        tk.Label(
            self,
            text="Novos modos virais automáticos em breve...",
            font=(FONT_FAMILY, 7),
            bg=BG_SECONDARY,
            fg=TEXT_MUTED
        ).pack(pady=(4, 0))

    def _on_generate_click(self):
        if self.on_generate:
            self.on_generate()
