"""
=============================================================================
VIRAL CUTS PRO - MONITOR VISUAL DO PIPELINE (ETAPAS PROGRESSIVAS)
Exibe o progresso em tempo real das 5 etapas da esteira de cortes.
=============================================================================
"""

import tkinter as tk
from tkinter import ttk
from typing import Optional

from .theme import (
    BG_TERTIARY,
    BG_SECONDARY,
    BG_CARD,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    ACCENT_BLUE,
    ACCENT_GREEN,
    ACCENT_RED,
    ACCENT_ORANGE,
    CYAN_ACCENT,
    BORDER_COLOR,
    FONT_FAMILY,
    FONT_MONO,
    STEP_ACTIVE_COLOR,
    STEP_INACTIVE_COLOR,
)


class PipelineMonitor(tk.Frame):
    """
    Componente visual que exibe as 5 etapas da esteira de cortes:
    ✅ Concluído | ▶ Em andamento (azul) | ⏸ Pendente (cinza) | ❌ Erro (vermelho)
    """

    ETAPAS = [
        ("🎵", "Extraindo Áudio"),
        ("📝", "Whisper Transcrição"),
        ("🧠", "Análise IA (LLM)"),
        ("🔥", "Scoring Viral"),
        ("🎬", "Renderizando"),
    ]

    def __init__(self, master, **kwargs):
        super().__init__(master, bg=BG_SECONDARY, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1, **kwargs)

        self.etapa_atual = -1  # -1 = IDLE / Não iniciado
        self._step_widgets = []

        self._build_ui()
        self.reset()

    def _build_ui(self):
        # 1. Header do Monitor
        header = tk.Frame(self, bg=BG_TERTIARY, height=28)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        tk.Label(
            header,
            text="📊 PIPELINE STATUS",
            font=(FONT_FAMILY, 9, "bold"),
            bg=BG_TERTIARY,
            fg=CYAN_ACCENT
        ).pack(side="left", padx=10, pady=4)

        self.lbl_status_badge = tk.Label(
            header,
            text="IDLE",
            font=(FONT_FAMILY, 8, "bold"),
            bg="#1f2937",
            fg=TEXT_MUTED,
            padx=6, pady=1
        )
        self.lbl_status_badge.pack(side="right", padx=10, pady=4)

        # 2. Container das 5 Etapas
        self.steps_container = tk.Frame(self, bg=BG_SECONDARY, padx=12, pady=6)
        self.steps_container.pack(fill="x")

        for idx, (icone, nome) in enumerate(self.ETAPAS):
            row = tk.Frame(self.steps_container, bg=BG_SECONDARY)
            row.pack(fill="x", pady=2)

            lbl_icon = tk.Label(row, text=icone, font=(FONT_FAMILY, 9), bg=BG_SECONDARY, fg=TEXT_SECONDARY, width=2)
            lbl_icon.pack(side="left")

            lbl_name = tk.Label(row, text=nome, font=(FONT_FAMILY, 9), bg=BG_SECONDARY, fg=TEXT_MUTED, anchor="w")
            lbl_name.pack(side="left", padx=(4, 0), fill="x", expand=True)

            lbl_state = tk.Label(row, text="⏸", font=(FONT_FAMILY, 9), bg=BG_SECONDARY, fg=STEP_INACTIVE_COLOR, width=3)
            lbl_state.pack(side="right")

            self._step_widgets.append((lbl_icon, lbl_name, lbl_state))

        # 3. Barra de Progresso
        prog_frame = tk.Frame(self, bg=BG_SECONDARY, padx=12, pady=3)
        prog_frame.pack(fill="x", pady=(4, 2))

        self.progress_bar = ttk.Progressbar(prog_frame, maximum=100, value=0)
        self.progress_bar.pack(fill="x")

        # 4. Mensagem de Log em Tempo Real
        self.lbl_log = tk.Label(
            self,
            text="Aguardando início do processamento...",
            font=(FONT_FAMILY, 8),
            bg=BG_SECONDARY,
            fg=TEXT_SECONDARY,
            anchor="w",
            padx=12,
            pady=4
        )
        self.lbl_log.pack(fill="x", side="bottom")

    def set_etapa(self, index: int, texto_log: str = ""):
        """
        Marca a etapa atual como em andamento (▶), as anteriores como concluídas (✅)
        e as posteriores como pendentes (⏸).
        """
        if index < 0 or index >= len(self.ETAPAS):
            return

        self.etapa_atual = index
        self.lbl_status_badge.config(text="PROCESSANDO", bg="#0c4a6e", fg=CYAN_ACCENT)

        for i, (lbl_icon, lbl_name, lbl_state) in enumerate(self._step_widgets):
            if i < index:
                # Concluída
                lbl_name.config(fg=TEXT_PRIMARY, font=(FONT_FAMILY, 9))
                lbl_state.config(text="✅", fg=ACCENT_GREEN)
            elif i == index:
                # Etapa Atual Ativa
                lbl_name.config(fg=CYAN_ACCENT, font=(FONT_FAMILY, 9, "bold"))
                lbl_state.config(text="▶ 🔵", fg=ACCENT_BLUE)
            else:
                # Pendente
                lbl_name.config(fg=TEXT_MUTED, font=(FONT_FAMILY, 9))
                lbl_state.config(text="⏸", fg=STEP_INACTIVE_COLOR)

        # Atualiza a barra de progresso (ex: etapa 0/5 = 10%, 1/5 = 30%, ..., 4/5 = 85%)
        pct = int(((index + 0.5) / len(self.ETAPAS)) * 100)
        self.progress_bar["value"] = pct

        if texto_log:
            self.set_log(texto_log)

    def set_log(self, msg: str):
        """Atualiza a mensagem de log inferior."""
        self.lbl_log.config(text=f"💬 {msg[:75]}{'...' if len(msg) > 75 else ''}")

    def concluir(self):
        """Marca todas as etapas como concluídas ✅ e barra em 100%."""
        self.etapa_atual = len(self.ETAPAS)
        self.lbl_status_badge.config(text="CONCLUÍDO", bg="#064e3b", fg=ACCENT_GREEN)

        for _, lbl_name, lbl_state in self._step_widgets:
            lbl_name.config(fg=TEXT_PRIMARY, font=(FONT_FAMILY, 9))
            lbl_state.config(text="✅", fg=ACCENT_GREEN)

        self.progress_bar["value"] = 100
        self.lbl_log.config(text="🎉 Todos os cortes foram processados com sucesso!", fg=ACCENT_GREEN)

    def reset(self):
        """Reseta o monitor para o estado IDLE."""
        self.etapa_atual = -1
        self.lbl_status_badge.config(text="IDLE", bg="#1f2937", fg=TEXT_MUTED)

        for _, lbl_name, lbl_state in self._step_widgets:
            lbl_name.config(fg=TEXT_MUTED, font=(FONT_FAMILY, 9))
            lbl_state.config(text="⏸", fg=STEP_INACTIVE_COLOR)

        self.progress_bar["value"] = 0
        self.lbl_log.config(text="Pronto para iniciar novo processamento.", fg=TEXT_SECONDARY)

    def set_erro(self, etapa_index: int, msg: str):
        """Marca a etapa atual como ❌ com mensagem de erro."""
        self.lbl_status_badge.config(text="ERRO", bg="#451a03", fg=ACCENT_RED)
        if 0 <= etapa_index < len(self._step_widgets):
            _, lbl_name, lbl_state = self._step_widgets[etapa_index]
            lbl_name.config(fg=ACCENT_RED, font=(FONT_FAMILY, 9, "bold"))
            lbl_state.config(text="❌", fg=ACCENT_RED)

        self.lbl_log.config(text=f"❌ Erro: {msg[:75]}", fg=ACCENT_RED)
