import os
import re
import sys
import subprocess
from pathlib import Path

from utils import log_debug, detectar_emocao_fala, detectar_engajamento


POSICOES_WEBCAM = {
    "top_left": {
        "x": 0.035,
        "y": 0.14,
        "w": 0.20,
        "h": 0.34,
        "center_x": 0.135,
        "center_y": 0.31,
        "descricao": "Canto Esquerdo Superior (Layout Atual do Streamer)"
    },
    "top_right": {
        "x": 0.765,
        "y": 0.14,
        "w": 0.20,
        "h": 0.34,
        "center_x": 0.865,
        "center_y": 0.31,
        "descricao": "Canto Direito Superior"
    },
    "bottom_left": {
        "x": 0.035,
        "y": 0.60,
        "w": 0.20,
        "h": 0.34,
        "center_x": 0.135,
        "center_y": 0.77,
        "descricao": "Canto Esquerdo Inferior"
    },
    "bottom_right": {
        "x": 0.765,
        "y": 0.60,
        "w": 0.20,
        "h": 0.34,
        "center_x": 0.865,
        "center_y": 0.77,
        "descricao": "Canto Direito Inferior"
    },
    "center": {
        "x": 0.25,
        "y": 0.25,
        "w": 0.50,
        "h": 0.50,
        "center_x": 0.50,
        "center_y": 0.50,
        "descricao": "Centro"
    },
}



def detectar_silencios_audio(video_path, sec_in, sec_out, threshold_db=-30, min_dur=1.0):
    """
    Detecta intervalos de silêncio morto usando FFmpeg silencedetect.
    Retorna lista de tuplas (silence_start_abs, silence_end_abs).
    """
    video_p = Path(video_path)
    if not video_p.exists():
        return []

    dur = max(1.0, sec_out - sec_in)
    cmd = [
        "ffmpeg", "-y",
        "-ss", str(sec_in),
        "-i", str(video_p),
        "-t", str(dur),
        "-af", f"silencedetect=noise={threshold_db}dB:d={min_dur}",
        "-f", "null",
        "-"
    ]

    cflags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    silencios = []

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            creationflags=cflags
        )
        _, stderr_bytes = proc.communicate(timeout=60)
        stderr_txt = stderr_bytes.decode('utf-8', errors='replace') if stderr_bytes else ""

        current_start = None
        for linha in stderr_txt.splitlines():
            m_start = re.search(r'silence_start:\s*([\d\.]+)', linha)
            if m_start:
                current_start = float(m_start.group(1)) + sec_in

            m_end = re.search(r'silence_end:\s*([\d\.]+)', linha)
            if m_end and current_start is not None:
                end_time = float(m_end.group(1)) + sec_in
                if end_time - current_start >= min_dur:
                    silencios.append((current_start, end_time))
                current_start = None

    except Exception as e:
        log_debug(f"Falha ao detectar silêncios via FFmpeg ({e})", "WARNING")

    return silencios


def calcular_intervalos_fala_ativa(falas, sec_in, sec_out, max_pausa_permitida=0.75, margem_inicio=0.08, margem_fim=0.12):
    """
    Calcula os blocos de fala ativa a partir dos segmentos da transcrição,
    removendo silêncios mortos (> max_pausa_permitida) com jump cuts profissionais.
    Garante que falas curtas ("sim", "ok") NÃO sejam descartadas.
    Retorna: lista de tuplas (inicio_abs, fim_abs)
    """
    falas_do_trecho = []
    if falas:
        for f in falas:
            if not isinstance(f, dict):
                continue
            try:
                st = float(f.get("inicio", 0))
                et = float(f.get("fim", 0))
            except (ValueError, TypeError):
                continue
            txt = str(f.get("texto", "")).strip()
            if not txt:
                continue
            if et > sec_in and st < sec_out:
                falas_do_trecho.append((max(sec_in, st), min(sec_out, et)))

    if not falas_do_trecho:
        return [(sec_in, sec_out)]

    falas_do_trecho.sort(key=lambda x: x[0])

    blocos = []
    bloco_atual_in = max(sec_in, falas_do_trecho[0][0] - margem_inicio)
    bloco_atual_out = min(sec_out, falas_do_trecho[0][1] + margem_fim)

    for st, et in falas_do_trecho[1:]:
        st_com_margem = max(sec_in, st - margem_inicio)
        et_com_margem = min(sec_out, et + margem_fim)

        if st_com_margem - bloco_atual_out <= max_pausa_permitida:
            bloco_atual_out = max(bloco_atual_out, et_com_margem)
        else:
            if bloco_atual_out > bloco_atual_in + 0.05:
                blocos.append((bloco_atual_in, bloco_atual_out))
            bloco_atual_in = st_com_margem
            bloco_atual_out = et_com_margem

    if bloco_atual_out > bloco_atual_in + 0.05:
        blocos.append((bloco_atual_in, bloco_atual_out))

    return blocos if blocos else [(sec_in, sec_out)]


def mapear_falas_para_tempo_compactado(falas, blocos_ativos, sec_in, sec_out):
    """
    Recalcula os timestamps de cada fala da transcrição para a nova linha do tempo
    compactada (sem os silêncios cortados), garantindo sincronização milimétrica de legendas.
    Trata falas curtas e falas que interceptam múltiplos blocos ativos.
    """
    falas_compactadas = []
    if not falas or not blocos_ativos:
        return falas

    for item in falas:
        if not isinstance(item, dict):
            continue
        try:
            st = float(item.get("inicio", 0))
            et = float(item.get("fim", 0))
        except (ValueError, TypeError):
            continue
        txt = str(item.get("texto", "")).strip()
        if not txt or et <= sec_in or st >= sec_out:
            continue

        # Calcula o mapeamento sobre a lista de blocos ativos
        t_acumulado = 0.0
        segmentos_mapeados = []

        for b_in, b_out in blocos_ativos:
            b_dur = b_out - b_in
            if st < b_out and et > b_in:
                # Interceptação válida com este bloco
                st_clamped = max(st, b_in)
                et_clamped = min(et, b_out)
                st_rel = t_acumulado + (st_clamped - b_in)
                et_rel = t_acumulado + (et_clamped - b_in)
                if et_rel > st_rel:
                    segmentos_mapeados.append((st_rel, et_rel))
            t_acumulado += b_dur

        if segmentos_mapeados:
            # Pega o início do primeiro segmento e o fim do último segmento mapeado
            st_novo = segmentos_mapeados[0][0]
            et_novo = segmentos_mapeados[-1][1]
            if et_novo > st_novo:
                item_copia = dict(item)
                item_copia["inicio"] = st_novo
                item_copia["fim"] = et_novo
                falas_compactadas.append(item_copia)

    return falas_compactadas


def calcular_intervalos_ativos(sec_in, sec_out, silencios, min_silencio=1.0):
    """
    Calcula os intervalos de fala ativa subtraindo pausas mortas longas.
    Retorna lista de tuplas (inicio_seg, fim_seg).
    """
    if not silencios:
        return [(sec_in, sec_out)]

    intervalos = []
    cursor = sec_in

    for s_start, s_end in sorted(silencios, key=lambda x: x[0]):
        if s_end <= sec_in or s_start >= sec_out:
            continue

        c_start = max(sec_in, s_start)
        c_end = min(sec_out, s_end)

        if c_start - cursor >= 0.5:
            intervalos.append((cursor, c_start))
        cursor = max(cursor, c_end)

    if sec_out - cursor >= 0.5:
        intervalos.append((cursor, sec_out))

    return intervalos if intervalos else [(sec_in, sec_out)]


def gerar_edit_decision_list(corte_info, transcricao_linhas, sec_in, sec_out):
    """
    Cria a Edit Decision List (EDL) autônoma para orientar o renderizador.
    """
    duracao_total = sec_out - sec_in
    edicao_ia = corte_info.get("edicao", {}) if isinstance(corte_info.get("edicao"), dict) else {}

    remover_silencios = edicao_ia.get("remover_silencios", True)
    zoom_punchline = edicao_ia.get("zoom_punchline", True)
    posicao_webcam = edicao_ia.get("posicao_webcam", "top_left")

    momentos_zoom = []

    if transcricao_linhas and zoom_punchline:
        for item in transcricao_linhas:
            st = item.get("inicio", 0)
            et = item.get("fim", 0)
            txt = str(item.get("texto", ""))

            # Se a fala estiver dentro do corte
            if st >= sec_in and et <= sec_out:
                emocao = detectar_emocao_fala(txt)
                engaj = detectar_engajamento(txt)

                # Momentos de alta energia recebem zoom dinâmico de ênfase
                if emocao["tipo"] in ["RAGE", "HILARIOUS", "HYPE"] or engaj["tipo"] in ["HYPE_MOMENT", "REVELACAO_TEA"]:
                    st_rel = max(0.0, st - sec_in)
                    dur_fala = max(1.5, min(4.0, et - st))
                    momentos_zoom.append({
                        "inicio_rel": round(st_rel, 2),
                        "duracao": round(dur_fala, 2),
                        "intensidade": 1.25,
                        "motivo": emocao["tipo"]
                    })
                    break  # Um momento de zoom principal por corte para não cansar

    blocos_ativos = []
    if remover_silencios and transcricao_linhas:
        blocos_ativos = calcular_intervalos_fala_ativa(transcricao_linhas, sec_in, sec_out, max_pausa_permitida=0.8)

    duracao_compactada = sum(b_out - b_in for b_in, b_out in blocos_ativos) if blocos_ativos else duracao_total

    return {
        "titulo": corte_info.get("titulo_viral", "Corte"),
        "sec_in": sec_in,
        "sec_out": sec_out,
        "duracao_total": duracao_total,
        "duracao_compactada": duracao_compactada,
        "remover_silencios": remover_silencios,
        "blocos_ativos": blocos_ativos,
        "posicao_webcam": posicao_webcam if posicao_webcam in POSICOES_WEBCAM else "top_left",
        "momentos_zoom": momentos_zoom,
        "categoria": corte_info.get("categoria", "VIRAL"),
        "pontuacao": corte_info.get("pontuacao_viral", 7)
    }


def construir_filtro_video_edicao(edl, target_w=1080, target_h=1920, legenda_path=None, base_dir=None):
    """
    Constrói a cadeia de filtros FFmpeg para o vídeo vertical 9:16 com zoom dinâmico e legenda.
    Usa caminhos relativos para legendas para evitar problemas de escape de dois pontos (C\\:) no Windows.
    """
    filtro_legenda = ""
    if legenda_path and Path(legenda_path).exists():
        nome_leg = Path(legenda_path).name
        nome_leg_esc = nome_leg.replace(":", "\\:").replace("'", "\\'").replace(";", "\\;").replace("[", "\\[").replace("]", "\\]")
        if Path(legenda_path).suffix.lower() == ".ass":
            filtro_legenda = f",ass=filename='{nome_leg_esc}'"
        else:
            filtro_legenda = f",subtitles=filename='{nome_leg_esc}':force_style='Fontname=Impact,Fontsize=96,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=5,Shadow=2,Alignment=2,MarginV=300,MarginL=60,MarginR=60'"

    # Zoom dinâmico de ênfase para momentos de clímax/punchline
    filtro_zoom = ""
    momentos_zoom = edl.get("momentos_zoom", []) if isinstance(edl, dict) else []
    if momentos_zoom and isinstance(momentos_zoom, list) and len(momentos_zoom) > 0:
        m0 = momentos_zoom[0]
        z_in = float(m0.get("inicio_rel", 0.0))
        z_dur = float(m0.get("duracao", 2.0))
        z_out = z_in + z_dur
        z_factor = float(m0.get("intensidade", 1.15))
        filtro_zoom = f",crop=w='if(between(t,{z_in:.2f},{z_out:.2f}),in_w/{z_factor:.2f},in_w)':h='if(between(t,{z_in:.2f},{z_out:.2f}),in_h/{z_factor:.2f},in_h)':x=(in_w-out_w)/2:y=(in_h-out_h)/2"

    # Realce de vídeo HD: nitidez espacial para mobile e contraste/saturação profissional
    filtro_realce_fg = f"scale=1080:-1:force_original_aspect_ratio=decrease{filtro_zoom},unsharp=5:5:0.8:5:5:0.0,eq=contrast=1.05:saturation=1.12"

    # Auto Silence Cut / Jump Cut (Sincronizado entre Áudio e Vídeo)
    blocos_ativos = edl.get("blocos_ativos", []) if isinstance(edl, dict) else []
    remover_silencios = edl.get("remover_silencios", False) if isinstance(edl, dict) else False
    sec_in = float(edl.get("sec_in", 0.0)) if isinstance(edl, dict) else 0.0

    if remover_silencios and blocos_ativos and len(blocos_ativos) > 1:
        condicoes_select = "+".join(
            f"between(t,{max(0.0, b_in - sec_in):.3f},{max(0.0, b_out - sec_in):.3f})"
            for b_in, b_out in blocos_ativos
        )
        prefixo_silence_cut = (
            f"[0:v]select='{condicoes_select}',setpts=PTS-STARTPTS,split=2[v_bg_in][v_fg_in];"
        )
        src_bg = "[v_bg_in]"
        src_fg = "[v_fg_in]"
        filtro_audio = f"[0:a:0]aselect='{condicoes_select}',asetpts=PTS-STARTPTS,loudnorm=I=-16:TP=-1.5:LRA=11[a_final]"
    else:
        prefixo_silence_cut = ""
        src_bg = "[0:v]"
        src_fg = "[0:v]"
        filtro_audio = f"[0:a:0]loudnorm=I=-16:TP=-1.5:LRA=11[a_final]"

    filter_complex = (
        f"{prefixo_silence_cut}"
        f"{src_bg}scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=10:2,scale={target_w}:{target_h}[bg];"
        f"{src_fg}{filtro_realce_fg}[fg];"
        f"[bg][fg]overlay=(W-w)/2:(H-h)/2{filtro_legenda}[v_final];"
        f"{filtro_audio}"
    )

    return filter_complex





