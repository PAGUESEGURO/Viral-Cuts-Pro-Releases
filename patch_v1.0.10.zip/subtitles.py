"""
=============================================================================
VIRAL CUTS PRO - MOTOR DE LEGENDAS PROFISSIONAL (ASS & SRT)
Estilo TikTok / Reels: Branco Puro + Destaque Dinâmico + Word-Level Micro-Sync
=============================================================================
"""

import re
import os
import threading
import subprocess
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple

from utils import (
    detectar_emocao_fala,
    corrigir_vocabulario_streamer,
    log_debug
)

DIR_ATUAL = Path(__file__).parent.resolve()

# Margens vocais padronizadas para captura perfeita da fala (0.00s drift)
PAD_INICIO_FALA: float = 0.20  # 200ms de margem vocal para respiração/ataque inicial
PAD_FIM_FALA: float = 0.35     # 350ms de margem vocal para decaimento final


# Paleta de Cores ASS no formato BGR Hexadecimal (&HAABBGGRR&)
CORES_EMOCAO_ASS = {
    "RAGE": "&H000000FF&",       # Vermelho Neon
    "HILARIOUS": "&H0000FF00&",  # Verde Limão Neon
    "HYPE": "&H00FFFF00&",       # Ciano Neon
    "HOT_TAKE": "&H00FF00FF&",   # Magenta / Roxo Neon
    "SADGE": "&H00FFAA00&",      # Azul Aço Suave
    "NEUTRO": "&H0000FFFF&",     # Amarelo Ouro Neon (Destaque de punchline)
}

ANIMACOES_EMOCAO_ASS = {
    "HYPE": r"{\fad(60,40)\t(0,80,\fscx115\fscy115)\t(80,160,\fscx100\fscy100)}",
    "RAGE": r"{\fad(40,30)\frz2\t(0,60,\frz-2)\t(60,120,\frz0)}",
    "HILARIOUS": r"{\fad(70,50)\t(0,90,\fscx110\fscy110)\t(90,170,\fscx100\fscy100)}",
    "HOT_TAKE": r"{\fad(80,60)\frz-2}",
    "SADGE": r"{\fad(130,100)}",
    "NEUTRO": r"{\fad(70,50)}",
}


def formatar_ass_time(sec: float) -> str:
    """Formata segundos float para o formato de tempo do ASS: H:MM:SS.cs (centissegundos)."""
    hrs = int(sec // 3600)
    mins = int((sec % 3600) // 60)
    secs = int(sec % 60)
    centis = int(round((sec - int(sec)) * 100))
    if centis >= 100:
        centis = 99
    return f"{hrs:d}:{mins:02d}:{secs:02d}.{centis:02d}"


def calcular_tamanho_fonte_ass(texto: str) -> int:
    """Calcula tamanho de fonte proporcional ao comprimento do texto para legibilidade 9:16 ideal."""
    tam = len(str(texto).strip())
    if tam <= 12:
        return 106
    elif tam <= 24:
        return 92
    elif tam <= 36:
        return 80
    else:
        return 68


def destacar_palavras_chave(texto: str, emocao_tipo: str = "NEUTRO") -> str:
    """Destaca palavras-chave com cores temáticas adaptadas à emoção detectada."""
    cor_destaque = CORES_EMOCAO_ASS.get(emocao_tipo, "&H0000FFFF&")
    palavras_chave_regex = r'\b(mano|olha|meu deus|caraca|velho|nunca|muito|demais|insano|absurdo|morri|socorro|clutch|rage|fail|jogada|deu ruim|inédito|\d+)\b'
    
    def _repl(match):
        w = match.group(0)
        return f"{{\\c{cor_destaque}}}{w}{{\\c&H00FFFFFF&}}"
    
    txt_destacado = re.sub(palavras_chave_regex, _repl, texto, flags=re.IGNORECASE)
    return txt_destacado


def obter_header_ass() -> str:
    """Retorna os blocos de cabeçalho padrão ASS para 1080x1920."""
    return """[Script Info]
Title: Viral Cuts Pro Subtitles
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: None
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: TikTokStyle,Impact,92,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,1,0,0,0,100,100,1,0,1,5.5,2.5,2,60,60,300,1
Style: WatermarkStyle,Segoe UI,38,&H70FFFFFF,&H000000FF,&H00000000,&H80000000,1,0,0,0,100,100,1,0,1,2.5,1.5,8,40,40,120,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def agrupar_palavras_em_chunks(words: List[Dict[str, Any]], max_words: int = 3, max_gap: float = 0.35) -> List[Tuple[float, float, str]]:
    """
    Agrupa palavras com timestamps exatos em blocos dinâmicos estilo TikTok (2 a 4 palavras por popup).
    Respeita pausas de fala e pontuação terminal.
    """
    if not words:
        return []

    chunks = []
    current_chunk = []

    for w in words:
        w_clean = str(w.get("word", "")).strip()
        if not w_clean:
            continue
        w_dict = {"word": w_clean, "start": float(w.get("start", 0)), "end": float(w.get("end", 0))}

        if not current_chunk:
            current_chunk.append(w_dict)
            continue

        pausa = w_dict["start"] - current_chunk[-1]["end"]
        termina_frase = any(current_chunk[-1]["word"].endswith(p) for p in [".", "!", "?", ","])

        if len(current_chunk) >= max_words or pausa > max_gap or termina_frase:
            chunks.append(current_chunk)
            current_chunk = [w_dict]
        else:
            current_chunk.append(w_dict)

    if current_chunk:
        chunks.append(current_chunk)

    resultado = []
    for c in chunks:
        st = c[0]["start"]
        et = c[-1]["end"]
        # Garante duração mínima para legibilidade visual (evita flicker menor que 0.18s)
        if et - st < 0.20:
            et = st + 0.22
        txt = " ".join(item["word"] for item in c)
        txt_corrigido = corrigir_vocabulario_streamer(txt)
        if txt_corrigido:
            resultado.append((st, et, txt_corrigido))

    return resultado




_MODELO_WHISPER_CACHE = None
_WHISPER_LOCK = threading.Lock()


def obter_whisper_singleton():
    """Retorna uma instância única em cache do WhisperModel com thread-safety garantido."""
    global _MODELO_WHISPER_CACHE
    if _MODELO_WHISPER_CACHE is not None:
        return _MODELO_WHISPER_CACHE
    with _WHISPER_LOCK:
        if _MODELO_WHISPER_CACHE is not None:
            return _MODELO_WHISPER_CACHE
        try:
            from faster_whisper import WhisperModel
            try:
                _MODELO_WHISPER_CACHE = WhisperModel("small", device="cuda", compute_type="float16")
            except Exception:
                try:
                    _MODELO_WHISPER_CACHE = WhisperModel("small", device="cuda", compute_type="int8_float16")
                except Exception:
                    num_threads = min(os.cpu_count() or 4, 8)
                    _MODELO_WHISPER_CACHE = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=num_threads)
            return _MODELO_WHISPER_CACHE
        except Exception as e:
            log_debug(f"Aviso ao carregar Whisper singleton: {e}", "WARNING")
            return None



def transcrever_audio_corte_word_level(
    video_path: Path,
    sec_in: float,
    duracao: float,
    initial_prompt: str = "Transcrição em português do Brasil com pontuação e gírias de games."
) -> Optional[List[Dict[str, Any]]]:
    """
    Extrai áudio WAV do corte curto e realiza micro-transcrição word-level ultra-rápida (1-2s).
    """
    if not video_path or not Path(video_path).exists() or duracao <= 0.5:
        return None

    audio_temp = DIR_ATUAL / f"temp_whisper_{os.getpid()}_{int(sec_in*100)}.wav"
    try:
        # Extração direta 16kHz mono PCM (sem filtros pesados para velocidade instantânea)
        cmd_audio = [
            "ffmpeg", "-y",
            "-ss", f"{sec_in:.3f}",
            "-i", str(video_path),
            "-t", f"{duracao:.3f}",
            "-vn",
            "-acodec", "pcm_s16le",
            "-ar", "16000",
            "-ac", "1",
            str(audio_temp)
        ]
        cflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        res = subprocess.run(cmd_audio, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20, creationflags=cflags)
        if res.returncode != 0 or not audio_temp.exists() or audio_temp.stat().st_size < 1000:
            return None

        model = obter_whisper_singleton()
        if model is None:
            return None

        segments, _ = model.transcribe(
            str(audio_temp),
            language="pt",
            beam_size=1,
            word_timestamps=True,
            vad_filter=False,
            initial_prompt=initial_prompt
        )

        words = []
        for s in segments:
            if getattr(s, 'no_speech_prob', 0) > 0.90:
                continue
            if s.words:
                for w in s.words:
                    w_txt = w.word.strip()
                    if w_txt:
                        words.append({
                            "word": w_txt,
                            "start": max(0.0, float(w.start)),
                            "end": min(duracao, float(w.end)),
                            "prob": float(getattr(w, 'probability', 1.0))
                        })

        return words if words else None

    except Exception:
        return None
    finally:
        if audio_temp.exists():
            try: audio_temp.unlink(missing_ok=True)
            except Exception: pass


def gerar_ass_para_corte(
    sec_in: float,
    sec_out: float,
    transcricao: List[Dict[str, Any]],
    num_corte: int,
    dir_saida: Optional[Path] = None,
    nome_canal: Optional[str] = None,
    palavras_word_level: Optional[List[Dict[str, Any]]] = None
) -> Optional[Path]:
    """Gera arquivo de legenda animada ASS (.ass) estilo TikTok com chunks perfeitamente sincronizados."""
    if dir_saida is None:
        dir_saida = DIR_ATUAL

    caminho_ass = dir_saida / f"temp_legenda_{num_corte:02d}.ass"
    duracao_total = max(0.1, sec_out - sec_in)
    linhas_corte = []

    # 1. Se possuir palavras word-level da micro-transcrição, usa chunks exatos
    if palavras_word_level:
        linhas_corte = agrupar_palavras_em_chunks(palavras_word_level)

    # 2. Fallback para transcrição por segmentos
    if not linhas_corte and transcricao:
        transcricao_local = list(transcricao)
        for item in transcricao_local:
            st = float(item.get("inicio", 0))
            et = float(item.get("fim", 0))
            txt_raw = str(item.get("texto", "")).strip()
            if not txt_raw or et <= sec_in or st >= sec_out:
                continue

            txt = corrigir_vocabulario_streamer(txt_raw)
            if not txt:
                continue

            st_rel = max(0.0, st - sec_in)
            et_rel = min(duracao_total, et - sec_in)
            dur_fala = et_rel - st_rel
            if dur_fala >= 0.15:
                palavras = txt.split()
                if len(palavras) > 4 and dur_fala >= 1.2:
                    chunk_size = 3
                    chunks = [" ".join(palavras[i:i+chunk_size]) for i in range(0, len(palavras), chunk_size)]
                    total_chars = max(1, sum(len(c) for c in chunks))
                    cursor_t = st_rel
                    for idx_c, c_txt in enumerate(chunks):
                        fracao = len(c_txt) / total_chars
                        c_dur = dur_fala * fracao
                        c_end = min(et_rel, cursor_t + c_dur)
                        if idx_c == len(chunks) - 1:
                            c_end = et_rel
                        if c_end > cursor_t:
                            linhas_corte.append((cursor_t, c_end, c_txt))
                        cursor_t = c_end
                else:
                    linhas_corte.append((st_rel, et_rel, txt))

    if not linhas_corte:
        return None

    eventos = []
    if nome_canal and str(nome_canal).strip():
        canal_clean = str(nome_canal).strip().replace("{", "").replace("}", "")
        t_fim_total = formatar_ass_time(duracao_total)
        eventos.append(f"Dialogue: 1,0:00:00.00,{t_fim_total},WatermarkStyle,,0,0,0,,{{\\fad(200,200)}}{canal_clean}")

    for st_rel, et_rel, txt in linhas_corte:
        t1 = formatar_ass_time(st_rel)
        t2 = formatar_ass_time(et_rel)
        txt_clean = txt.replace("{", "").replace("}", "").replace("\n", " ").strip()
        
        emocao = detectar_emocao_fala(txt_clean)
        emocao_tipo = emocao.get("tipo", "NEUTRO")
        
        fs_dinamico = calcular_tamanho_fonte_ass(txt_clean)
        anim_dinamica = ANIMACOES_EMOCAO_ASS.get(emocao_tipo, ANIMACOES_EMOCAO_ASS["NEUTRO"])
        txt_formatado = destacar_palavras_chave(txt_clean, emocao_tipo)
        
        linha_evento = f"Dialogue: 0,{t1},{t2},TikTokStyle,,0,0,0,,{{\\fs{fs_dinamico}}}{anim_dinamica}{txt_formatado}"
        eventos.append(linha_evento)

    try:
        with open(caminho_ass, "w", encoding="utf-8") as f:
            f.write(obter_header_ass())
            f.write("\n".join(eventos) + "\n")
        return caminho_ass
    except Exception as e:
        log_debug(f"Erro ao gerar arquivo ASS para corte {num_corte}: {e}", "WARNING")
        return None


def gerar_srt_para_corte(
    sec_in: float,
    sec_out: float,
    transcricao: List[Dict[str, Any]],
    num_corte: int,
    dir_saida: Optional[Path] = None,
    palavras_word_level: Optional[List[Dict[str, Any]]] = None
) -> Optional[Path]:
    """Gera arquivo .srt sincronizado com proteção contra legendas fantasmas."""
    if dir_saida is None:
        dir_saida = DIR_ATUAL

    caminho_srt = dir_saida / f"temp_legenda_{num_corte:02d}.srt"
    duracao_total = max(0.1, sec_out - sec_in)
    linhas_corte = []

    if palavras_word_level:
        linhas_corte = agrupar_palavras_em_chunks(palavras_word_level)
    elif transcricao:
        for item in list(transcricao):
            st = float(item.get("inicio", 0))
            et = float(item.get("fim", 0))
            txt = str(item.get("texto", "")).strip()
            if not txt or et <= sec_in or st >= sec_out:
                continue

            st_rel = max(0.0, st - sec_in)
            et_rel = min(duracao_total, et - sec_in)
            if et_rel - st_rel >= 0.15:
                linhas_corte.append((st_rel, et_rel, txt))

    if not linhas_corte:
        return None

    def _fmt_srt(sec: float) -> str:
        hrs = int(sec // 3600)
        mins = int((sec % 3600) // 60)
        secs = int(sec % 60)
        millis = int(round((sec - int(sec)) * 1000))
        if millis >= 1000:
            millis = 999
        return f"{hrs:02d}:{mins:02d}:{secs:02d},{millis:03d}"

    conteudo_srt = []
    idx = 1
    for st_rel, et_rel, txt in linhas_corte:
        t1 = _fmt_srt(st_rel)
        t2 = _fmt_srt(et_rel)
        txt_limpo = corrigir_vocabulario_streamer(txt)
        conteudo_srt.append(f"{idx}\n{t1} --> {t2}\n{txt_limpo.upper()}\n")
        idx += 1

    try:
        with open(caminho_srt, "w", encoding="utf-8") as f:
            f.write("\n".join(conteudo_srt))
        return caminho_srt
    except Exception as e:
        log_debug(f"Erro ao salvar SRT para corte {num_corte}: {e}", "WARNING")
        return None


def mesclar_cobertura_com_global(
    palavras_word_level: List[Dict[str, Any]],
    transcricao_global: List[Dict[str, Any]],
    sec_in: float,
    sec_out: float,
    limiar_lacuna: float = 1.5
) -> List[Dict[str, Any]]:
    """
    Detecta lacunas temporais nos chunks word-level e preenche com segmentos
    da transcrição global. Preserva a prioridade do word-level onde ele existe.

    Args:
        palavras_word_level: Palavras com timestamps relativos ao clipe (start=0)
        transcricao_global: Segmentos com timestamps absolutos do vídeo original
        sec_in: Timestamp absoluto de início do corte no vídeo original
        sec_out: Timestamp absoluto de fim do corte no vídeo original
        limiar_lacuna: Lacunas >= este valor (em segundos) serão preenchidas

    Returns:
        Lista unificada de palavras no formato word-level (timestamps relativos)
    """
    if not palavras_word_level:
        return palavras_word_level or []
    if not transcricao_global:
        return palavras_word_level

    duracao = max(0.1, sec_out - sec_in)

    # 1. Construir timeline de cobertura word-level
    #    Ordenar por start para garantir intervalos sequenciais
    wl_sorted = sorted(palavras_word_level, key=lambda w: float(w.get("start", 0)))
    if not wl_sorted:
        return palavras_word_level

    # 2. Compor intervalos cobertos (merge de intervalos sobrepostos)
    cobertos = []
    for w in wl_sorted:
        ws = float(w.get("start", 0))
        we = float(w.get("end", 0))
        if cobertos and ws <= cobertos[-1][1] + 0.3:  # tolerância de 300ms entre palavras
            cobertos[-1] = (cobertos[-1][0], max(cobertos[-1][1], we))
        else:
            cobertos.append((ws, we))

    # 3. Detectar lacunas: [0, primeiro_start], [fim_N, inicio_N+1], [ultimo_fim, duracao]
    lacunas = []
    primeiro_inicio = cobertos[0][0] if cobertos else 0.0
    if primeiro_inicio >= limiar_lacuna:
        lacunas.append((0.0, primeiro_inicio))

    for i in range(len(cobertos) - 1):
        gap_start = cobertos[i][1]
        gap_end = cobertos[i + 1][0]
        if (gap_end - gap_start) >= limiar_lacuna:
            lacunas.append((gap_start, gap_end))

    ultimo_fim = cobertos[-1][1] if cobertos else 0.0
    if (duracao - ultimo_fim) >= limiar_lacuna:
        lacunas.append((ultimo_fim, duracao))

    if not lacunas:
        # Word-level cobre tudo, sem necessidade de fallback
        return palavras_word_level

    # 4. Para cada lacuna, extrair segmentos da transcrição global
    palavras_fallback = []
    for gap_start_rel, gap_end_rel in lacunas:
        # Converter lacuna relativa para timestamps absolutos
        gap_start_abs = sec_in + gap_start_rel
        gap_end_abs = sec_in + gap_end_rel

        for item in transcricao_global:
            st_abs = float(item.get("inicio", 0))
            et_abs = float(item.get("fim", 0))
            txt = str(item.get("texto", "")).strip()

            if not txt or et_abs <= gap_start_abs or st_abs >= gap_end_abs:
                continue

            # Converter para timestamps relativos ao clipe
            st_rel = max(0.0, st_abs - sec_in)
            et_rel = min(duracao, et_abs - sec_in)

            # Clampar dentro da lacuna para evitar sobreposição com word-level
            st_rel = max(st_rel, gap_start_rel)
            et_rel = min(et_rel, gap_end_rel)

            if (et_rel - st_rel) < 0.15:
                continue

            # Criar entradas no formato word-level (uma por palavra para chunking natural)
            palavras_seg = txt.split()
            if not palavras_seg:
                continue

            dur_seg = et_rel - st_rel
            dur_por_palavra = dur_seg / len(palavras_seg)

            for idx_p, pal in enumerate(palavras_seg):
                p_start = st_rel + (idx_p * dur_por_palavra)
                p_end = p_start + dur_por_palavra
                palavras_fallback.append({
                    "word": pal,
                    "start": round(p_start, 3),
                    "end": round(min(p_end, et_rel), 3),
                    "prob": 0.85  # Marcador de confiança para fallback global
                })

    if not palavras_fallback:
        return palavras_word_level

    # 5. Unificar word-level + fallback, ordenado por timestamp
    resultado = list(palavras_word_level) + palavras_fallback
    resultado.sort(key=lambda w: float(w.get("start", 0)))

    log_debug(
        f"Fusão word-level+global: {len(palavras_word_level)} palavras WL + "
        f"{len(palavras_fallback)} palavras fallback em {len(lacunas)} lacuna(s)",
        "INFO"
    )

    return resultado


def gerar_legendas_para_corte(
    video_path: Path,
    sec_in: float,
    sec_out: float,
    num_corte: int,
    nome_canal: Optional[str] = None,
    transcricao_global: Optional[List[Dict[str, Any]]] = None
) -> Tuple[Optional[Path], Optional[Path]]:
    """
    Orquestrador de geração de legendas de alta precisão.
    Tenta micro-transcrição word-level do clipe isolado para sincronia milimétrica (0.00s drift).
    Caso indisponível, usa a transcrição global como fallback transparente.
    """
    duracao = max(0.1, sec_out - sec_in)
    palavras_words = None

    if video_path and Path(video_path).exists():
        palavras_words = transcrever_audio_corte_word_level(Path(video_path), sec_in, duracao)

    # Fusão: Se word-level existe mas tem lacunas >= 1.5s, preencher com transcrição global
    if palavras_words and transcricao_global:
        palavras_words = mesclar_cobertura_com_global(
            palavras_words, transcricao_global, sec_in, sec_out
        )

    caminho_ass = gerar_ass_para_corte(
        sec_in, sec_out, transcricao_global or [], num_corte,
        nome_canal=nome_canal, palavras_word_level=palavras_words
    )
    caminho_srt = gerar_srt_para_corte(
        sec_in, sec_out, transcricao_global or [], num_corte,
        palavras_word_level=palavras_words
    )

    return caminho_ass, caminho_srt
