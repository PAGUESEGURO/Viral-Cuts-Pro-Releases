"""
=============================================================================
VIRAL CUTS PRO v2.0 - GOAL-ORIENTED WORKSPACE
Interface Otimizada para Streamers: Fluxo Linear de 3 Passos + IA Automática
=============================================================================
"""

import os
import sys
import json
import threading
from pathlib import Path
from typing import Optional, Dict, Any, List

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from utils import SafeStreamWrapper, setup_safe_streams
from pipeline_controller import PipelineController, PipelineConfig, EstadoPipeline
from updater import AutoUpdater

from gui_components import (
    BG_PRIMARY,
    BG_SECONDARY,
    BG_TERTIARY,
    BG_CARD,
    BG_STEP_HEADER,
    BORDER_COLOR,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    TEXT_MUTED,
    ACCENT_BLUE,
    ACCENT_BLUE_HOVER,
    ACCENT_GREEN,
    ACCENT_ORANGE,
    ACCENT_RED,
    ACCENT_YELLOW,
    CYAN_ACCENT,
    FONT_FAMILY,
    FONT_MONO,
    VideoPlayer,
    WaveformDisplay,
    TimelineWidget,
    TranscriptionPanel,
    ExportPanel,
    AIHighlightsPanel,
    ProjectBin,
    PipelineMonitor,
    ClipCard,
    StepPanel,
)

setup_safe_streams()

DIR_ATUAL = Path(__file__).parent.resolve()
DIR_SAIDA = DIR_ATUAL / "cortes_prontos"
ARQUIVO_HISTORICO = DIR_ATUAL / "historico_cortes.json"
SCRIPT_ESTEIRA = DIR_ATUAL / "esteira.py"


class LiveCutterProGUI:
    """
    Interface Goal-Oriented v2.0 para geração automatizada de cortes com IA.
    Estrutura limpa em 3 colunas:
    1. Painel de Passos (Entrada ➔ Opções de IA ➔ Gerar)
    2. Player de Vídeo & Monitor de Pipeline
    3. Galeria Rica de Cortes Gerados
    """

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("⚡ ViralCuts Pro v2.0: AI-Powered Stream Highlights")
        self.root.geometry("1340x880")
        self.root.minsize(1100, 720)
        self.root.configure(bg=BG_PRIMARY)

        # Controlador do Pipeline
        self.controller = PipelineController(script_esteira=SCRIPT_ESTEIRA)
        self.controller.registrar_callback("on_log", self._on_log_recebido)
        self.controller.registrar_callback("on_status_change", self._on_status_change)
        self.controller.registrar_callback("on_corte_gerado", self._on_corte_gerado)
        self.controller.registrar_callback("on_finalizado", self._on_finalizado)

        # Estado Local
        self.caminho_video_selecionado: Optional[Path] = None
        self.duracao_video_atual: float = 0.0

        # Backend e Configurações de IA
        try:
            from backend_manager import BackendManager
            self.backend_manager = BackendManager()
            preferido = self.backend_manager.get_backend_preferido()
        except Exception:
            self.backend_manager = None
            preferido = "LM Studio"

        self.backend_selecionado = tk.StringVar(value=preferido)
        self.modelo_selecionado = tk.StringVar(value="qwen3.5-9b.gguf")
        self.nota_minima = tk.IntVar(value=6)

        # Variáveis de Opções da Esteira (Expostas no Passo 2)
        self.var_legendas = tk.BooleanVar(value=True)
        self.var_estilo_legenda = tk.StringVar(value="TikTok Bold Yellow")
        self.var_remover_silencios = tk.BooleanVar(value=True)
        self.var_enquadramento_916 = tk.BooleanVar(value=True)
        self.var_zoom_rosto = tk.BooleanVar(value=True)
        self.var_tipo_momento = tk.StringVar(value="Todos os Momentos")

        # Auto-Updater
        self._updater = AutoUpdater(
            on_update_disponivel=self._on_update_disponivel,
            on_patch_aplicado=self._on_patch_aplicado
        )
        self._banner_update_frame: Optional[tk.Frame] = None

        self._build_menu_bar()
        self._build_layout()
        self._carregar_historico_inicial()

        # Assistente de Onboarding no primeiro uso
        self.root.after(600, self._check_onboarding_startup)
        # Verificação de atualização em background (após 3s para não impactar startup)
        self.root.after(3000, self._iniciar_verificacao_atualizacao)

    def _check_onboarding_startup(self):
        if self.backend_manager and not self.backend_manager.is_onboarding_completo():
            self._abrir_config_ia()

    def _build_menu_bar(self):
        menubar = tk.Menu(self.root, bg=BG_SECONDARY, fg=TEXT_PRIMARY, bd=0)

        # File Menu
        file_menu = tk.Menu(menubar, tearoff=0, bg=BG_TERTIARY, fg=TEXT_PRIMARY)
        file_menu.add_command(label="Open Video...", command=self._abrir_arquivo_video)
        file_menu.add_command(label="Open Transcription...", command=self._abrir_arquivo_transcricao)
        file_menu.add_separator()
        file_menu.add_command(label="Open Cuts Folder", command=self._abrir_pasta_cortes)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        # Edit Menu
        edit_menu = tk.Menu(menubar, tearoff=0, bg=BG_TERTIARY, fg=TEXT_PRIMARY)
        edit_menu.add_command(label="Reset Waveform Cache", command=self._reset_cache)
        menubar.add_cascade(label="Edit", menu=edit_menu)

        # Tools Menu
        tools_menu = tk.Menu(menubar, tearoff=0, bg=BG_TERTIARY, fg=TEXT_PRIMARY)
        tools_menu.add_command(label="Open Cuts Folder", command=self._abrir_pasta_cortes)
        menubar.add_cascade(label="Tools", menu=tools_menu)

        # AI Settings Menu
        ai_menu = tk.Menu(menubar, tearoff=0, bg=BG_TERTIARY, fg=TEXT_PRIMARY)
        ai_menu.add_command(label="Configure AI Backends...", command=self._abrir_config_ia)
        menubar.add_cascade(label="AI Settings", menu=ai_menu)

        # Help Menu
        help_menu = tk.Menu(menubar, tearoff=0, bg=BG_TERTIARY, fg=TEXT_PRIMARY)
        help_menu.add_command(label="🔄 Verificar Atualizações...", command=self._verificar_update_manual)
        help_menu.add_separator()
        help_menu.add_command(label="About ViralCuts Pro", command=self._mostrar_sobre)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.root.config(menu=menubar)

    def _build_layout(self):
        """Layout Goal-Oriented em 3 colunas estratégicas."""
        # 0. Top Bar com Status de IA em Tempo Real
        top_bar = tk.Frame(self.root, bg=BG_SECONDARY, height=36, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1)
        top_bar.pack(fill="x", padx=4, pady=(4, 2))
        top_bar.pack_propagate(False)

        tk.Label(
            top_bar,
            text="⚡ VIRAL CUTS PRO v2.0",
            font=(FONT_FAMILY, 10, "bold"),
            bg=BG_SECONDARY,
            fg=CYAN_ACCENT
        ).pack(side="left", padx=10)

        # Botão de Configuração Rápida de IA
        self.btn_ai_indicator = tk.Button(
            top_bar,
            text=f"● {self.backend_selecionado.get()}: {self.modelo_selecionado.get()}",
            font=(FONT_FAMILY, 8, "bold"),
            bg="#064e3b",
            fg="#34d399",
            activebackground="#065f46",
            activeforeground="#ffffff",
            bd=0,
            relief="flat",
            padx=8,
            pady=2,
            cursor="hand2",
            command=self._abrir_config_ia
        )
        self.btn_ai_indicator.pack(side="right", padx=10, pady=4)

        # 1. Área Principal Dividida em 3 Colunas
        main_workspace = tk.Frame(self.root, bg=BG_PRIMARY)
        main_workspace.pack(fill="both", expand=True, padx=4, pady=2)

        # ═════════════════════════════════════════════════════════════════════
        # COLUNA 1: StepPanel (Passos 1 a 3 - Entrada, Opções e Disparo)
        # ═════════════════════════════════════════════════════════════════════
        coluna_esquerda = tk.Frame(main_workspace, bg=BG_SECONDARY, width=310, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1)
        coluna_esquerda.pack(side="left", fill="y", padx=(0, 2))
        coluna_esquerda.pack_propagate(False)

        self.step_panel = StepPanel(
            coluna_esquerda,
            on_select_video=self._abrir_arquivo_video,
            on_generate=self.iniciar_processamento,
            var_legendas=self.var_legendas,
            var_estilo_legenda=self.var_estilo_legenda,
            var_silencios=self.var_remover_silencios,
            var_916=self.var_enquadramento_916,
            var_zoom_rosto=self.var_zoom_rosto,
            var_nota_minima=self.nota_minima,
            var_tipo_momento=self.var_tipo_momento
        )
        self.step_panel.pack(fill="both", expand=True)

        # ═════════════════════════════════════════════════════════════════════
        # COLUNA 2: Player de Vídeo, Waveform Sonoro & Pipeline Monitor
        # ═════════════════════════════════════════════════════════════════════
        coluna_centro = tk.Frame(main_workspace, bg=BG_PRIMARY)
        coluna_centro.pack(side="left", fill="both", expand=True, padx=2)

        # Video Player
        self.video_player = VideoPlayer(
            coluna_centro,
            on_seek=self._sincronizar_seek_global
        )
        self.video_player.pack(fill="both", expand=True, pady=(0, 2))

        # Waveform Display
        self.waveform = WaveformDisplay(
            coluna_centro,
            height=68,
            on_region_change=self._on_waveform_region_change,
            on_seek=self._sincronizar_seek_global
        )
        self.waveform.pack(fill="x", pady=(2, 2))

        # Pipeline Monitor (Etapas Progressivas)
        self.pipeline_monitor = PipelineMonitor(coluna_centro)
        self.pipeline_monitor.pack(fill="x", pady=(2, 0))

        # ═════════════════════════════════════════════════════════════════════
        # COLUNA 3: Galeria de Cortes Gerados (ProjectBin v2.0)
        # ═════════════════════════════════════════════════════════════════════
        coluna_direita = tk.Frame(main_workspace, bg=BG_SECONDARY, width=300, bd=1, relief="solid", highlightbackground=BORDER_COLOR, highlightthickness=1)
        coluna_direita.pack(side="right", fill="y", padx=(2, 0))
        coluna_direita.pack_propagate(False)

        self.project_bin = ProjectBin(
            coluna_direita,
            on_select_source=self._carregar_video_especifico,
            on_select_clip=self._carregar_clip_especifico,
            pasta_cortes=DIR_SAIDA
        )
        self.project_bin.pack(fill="both", expand=True)

        # Instâncias auxiliares de compatibilidade
        self.timeline = TimelineWidget(self.root, on_seek=self._sincronizar_seek_global)
        self.transcription_panel = TranscriptionPanel(self.root, on_seek=self._sincronizar_seek_global)
        self.export_panel = ExportPanel(self.root)
        self.ai_panel = AIHighlightsPanel(self.root, on_generate=self.iniciar_processamento)

        # ═════════════════════════════════════════════════════════════════════
        # BARRA DE STATUS INFERIOR
        # ═════════════════════════════════════════════════════════════════════
        self.status_bar = tk.Frame(self.root, bg=BG_TERTIARY, height=24)
        self.status_bar.pack(fill="x", side="bottom")

        self.lbl_status_left = tk.Label(
            self.status_bar,
            text="Nenhum vídeo carregado | Pronto para análise",
            bg=BG_TERTIARY,
            fg=TEXT_SECONDARY,
            font=(FONT_FAMILY, 8)
        )
        self.lbl_status_left.pack(side="left", padx=8)

        self.progress_bar = ttk.Progressbar(self.status_bar, orient="horizontal", mode="determinate", length=180)
        self.progress_bar.pack(side="right", padx=8, pady=2)

        self.lbl_status_right = tk.Label(
            self.status_bar,
            text="Status: IDLE",
            bg=BG_TERTIARY,
            fg=CYAN_ACCENT,
            font=(FONT_MONO, 8, "bold")
        )
        self.lbl_status_right.pack(side="right", padx=4)

    def _sincronizar_seek_global(self, pos: float):
        """Sincroniza a posição temporal entre Player e Waveform."""
        self.video_player.posicao_atual = pos
        self.waveform.posicionar_playhead(pos)
        self.timeline.posicionar_playhead(pos)
        self.transcription_panel.sincronizar_com_tempo(pos)

    def _on_waveform_region_change(self, start: float, end: float):
        dur = end - start
        self.lbl_status_left.config(text=f"Região selecionada: {start:.1f}s a {end:.1f}s (Duração: {dur:.1f}s)")

    def _abrir_arquivo_video(self):
        caminho = filedialog.askopenfilename(
            title="Selecionar Vídeo de Live",
            filetypes=[("Arquivos de Vídeo", "*.mp4 *.mkv *.ts *.mov *.avi *.mpg"), ("Todos os Arquivos", "*.*")]
        )
        if caminho:
            self._carregar_video_especifico(Path(caminho))

    def _carregar_video_especifico(self, path: Path):
        self.caminho_video_selecionado = path
        self.step_panel.marcar_video_selecionado(str(path))
        self.project_bin.adicionar_fonte(path)
        self.video_player.carregar_video(path)
        self.duracao_video_atual = self.video_player.duracao

        self.waveform.carregar_audio_video(path, self.duracao_video_atual)
        self.timeline.set_duracao(self.duracao_video_atual)
        self.timeline.limpar_blocos()
        self.timeline.adicionar_bloco_corte("video", 0, self.duracao_video_atual, path.name[:12])
        self.pipeline_monitor.reset()

        self.lbl_status_left.config(text=f"Vídeo: {path.name} | Duração: {self.duracao_video_atual:.1f}s | Pronto")

    def _abrir_arquivo_transcricao(self):
        caminho = filedialog.askopenfilename(
            title="Selecionar Transcrição TXT",
            filetypes=[("Arquivos de Texto", "*.txt *.json"), ("Todos os Arquivos", "*.*")]
        )
        if caminho:
            self._carregar_transcricao_arquivo(Path(caminho))

    def _carregar_transcricao_arquivo(self, path: Path):
        try:
            linhas = []
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    partes = line.strip().split(" ", 2)
                    if len(partes) >= 3:
                        try:
                            st = float(partes[0])
                            et = float(partes[1])
                            txt = partes[2]
                            linhas.append({"inicio": st, "fim": et, "texto": txt})
                        except Exception:
                            pass
            if linhas:
                self.transcription_panel.carregar_transcricao(linhas)
                for l in linhas:
                    self.timeline.adicionar_bloco_corte("subtitles", l["inicio"], l["fim"], l["texto"][:8])
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao ler transcrição: {e}")

    def _carregar_clip_especifico(self, info: Dict[str, Any]):
        arq = info.get("arquivo") or info.get("caminho")
        if arq and Path(arq).exists():
            self._carregar_video_especifico(Path(arq))

    def iniciar_processamento(self):
        """Inicia a esteira de cortes virais usando todas as opções configuradas."""
        if not self.caminho_video_selecionado or not self.caminho_video_selecionado.exists():
            messagebox.showwarning("Vídeo Necessário", "Por favor, escolha um arquivo de vídeo no Passo 1 antes de iniciar.")
            return

        if self.controller.is_rodando():
            messagebox.showinfo("Em Execução", "A esteira de cortes já está em processamento.")
            return

        # Obter configurações de URL / chave do backend ativo
        url_bk = ""
        api_key_bk = ""
        if self.backend_manager:
            cfg = self.backend_manager.get_config_backend(self.backend_selecionado.get())
            url_bk = cfg.get("url", "")
            api_key_bk = cfg.get("api_key", "")

        config = PipelineConfig(
            video_path=self.caminho_video_selecionado,
            backend=self.backend_selecionado.get(),
            modelo=self.modelo_selecionado.get(),
            nota_minima=self.nota_minima.get(),
            url=url_bk,
            api_key=api_key_bk,
            remover_silencios=self.var_remover_silencios.get(),
            gerar_legendas=self.var_legendas.get(),
            estilo_legenda=self.var_estilo_legenda.get(),
            enquadramento_916=self.var_enquadramento_916.get(),
            zoom_rosto=self.var_zoom_rosto.get(),
            tipo_momento=self.var_tipo_momento.get()
        )

        self.step_panel.set_gerando(True)
        self.pipeline_monitor.set_etapa(0, "Iniciando esteira e extraindo áudio...")
        self.progress_bar.config(mode="indeterminate")
        self.progress_bar.start(10)
        self.lbl_status_right.config(text="Status: PROCESSANDO", fg=ACCENT_BLUE)

        sucesso = self.controller.iniciar(config)
        if not sucesso:
            self.step_panel.set_gerando(False)
            self.progress_bar.stop()
            self.pipeline_monitor.set_erro(0, "Não foi possível inicializar a esteira.")
            self.lbl_status_right.config(text="Status: ERRO", fg=ACCENT_RED)
            messagebox.showerror("Erro", "Não foi possível inicializar a esteira. Verifique se há um vídeo válido selecionado.")
        else:
            # Desabilitar botão do painel de IA para evitar duplo disparo
            try:
                self.ai_panel.btn_gerar.config(state="disabled")
            except Exception:
                pass

    def _on_log_recebido(self, linha: str):
        # Mapeia logs em tempo real para as 5 etapas do PipelineMonitor
        txt = linha.strip()
        if txt:
            txt_lower = txt.lower()
            if "audio" in txt_lower or "extra" in txt_lower:
                self.root.after(0, lambda: self.pipeline_monitor.set_etapa(0, txt))
            elif "whisper" in txt_lower or "transcri" in txt_lower:
                self.root.after(0, lambda: self.pipeline_monitor.set_etapa(1, txt))
            elif "analis" in txt_lower or "llm" in txt_lower or "ia" in txt_lower:
                self.root.after(0, lambda: self.pipeline_monitor.set_etapa(2, txt))
            elif "scor" in txt_lower or "viral" in txt_lower:
                self.root.after(0, lambda: self.pipeline_monitor.set_etapa(3, txt))
            elif "render" in txt_lower or "corte" in txt_lower or "ffmpeg" in txt_lower:
                self.root.after(0, lambda: self.pipeline_monitor.set_etapa(4, txt))

            self.root.after(0, lambda: self.lbl_status_left.config(text=f"Processando: {txt[:60]}..."))

    def _on_status_change(self, estado: str, msg: str):
        self.root.after(0, lambda: self.lbl_status_right.config(text=f"Status: {estado}"))

    def _on_corte_gerado(self, info: Dict[str, Any]):
        self.root.after(0, lambda: self._adicionar_corte_concluido(info))

    def _adicionar_corte_concluido(self, info: Dict[str, Any]):
        self.project_bin.adicionar_corte_gerado(info)

    def _on_finalizado(self, exit_code: int, status_msg: str):
        def _atualizar_ui_fim():
            self.step_panel.set_gerando(False)
            self.progress_bar.stop()
            # Reabilitar botão do painel de IA
            try:
                self.ai_panel.btn_gerar.config(state="normal")
            except Exception:
                pass
            if exit_code == 0:
                self.pipeline_monitor.concluir()
                self.lbl_status_right.config(text="Status: CONCLUÍDO", fg=ACCENT_GREEN)
                self._carregar_historico_inicial()
            else:
                self.pipeline_monitor.set_erro(self.pipeline_monitor.etapa_atual, status_msg or "Processamento interrompido")
                self.lbl_status_right.config(text="Status: ERRO / INTERROMPIDO", fg=ACCENT_RED)
        self.root.after(0, _atualizar_ui_fim)

    def _carregar_historico_inicial(self):
        if not ARQUIVO_HISTORICO.exists():
            return
        try:
            with open(ARQUIVO_HISTORICO, "r", encoding="utf-8") as f:
                dados = json.load(f)
                if isinstance(dados, list) and dados:
                    self.project_bin.limpar()
                    for item in dados:
                        nome_arq = item.get("arquivo_mp4") or item.get("arquivo") or ""
                        caminho_real = DIR_SAIDA / Path(nome_arq).name if nome_arq else None
                        
                        if caminho_real and caminho_real.exists():
                            p_final = caminho_real
                        elif nome_arq and Path(nome_arq).exists():
                            p_final = Path(nome_arq)
                        else:
                            # BUG #4 fix: arquivo não existe no disco, ignorar entrada
                            continue

                        # BUG #3 fix: ignorar arquivos corrompidos (< 50KB = não renderizados)
                        try:
                            if p_final.stat().st_size < 50_000:
                                continue
                        except Exception:
                            continue

                        score = item.get("score_viral")
                        if score is None:
                            pv = item.get("pontuacao_viral")
                            if pv is not None:
                                score = int(pv) * 10 if int(pv) <= 10 else int(pv)
                            else:
                                score = 70
                        
                        dur = item.get("duracao_seg")
                        if dur is None:
                            dur = item.get("duracao")
                        if dur is None and "sec_out" in item and "sec_in" in item:
                            dur = round(float(item.get("sec_out", 0)) - float(item.get("sec_in", 0)), 1)
                        if dur is None or dur <= 0:
                            dur = 30.0

                        titulo_final = item.get("titulo_viral") or item.get("titulo") or item.get("headline") or p_final.stem

                        self.project_bin.adicionar_corte_gerado({
                            "titulo": titulo_final,
                            "caminho": str(p_final),
                            "score": score,
                            "duracao": dur
                        })
        except Exception:
            pass

    def _abrir_pasta_cortes(self):
        DIR_SAIDA.mkdir(exist_ok=True)
        try:
            os.startfile(DIR_SAIDA)
        except Exception:
            pass

    def _reset_cache(self):
        if messagebox.askyesno("Reset Cache", "Deseja limpar os arquivos temporários e cache?"):
            messagebox.showinfo("Cache", "Cache resetado com sucesso.")

    def _abrir_config_ia(self):
        try:
            from onboarding import OnboardingWizard
            top = tk.Toplevel(self.root)
            top.transient(self.root)
            top.lift()
            top.focus_force()

            def _on_done(escolhido=None):
                if self.backend_manager:
                    pref = escolhido or self.backend_manager.get_backend_preferido()
                    self.backend_selecionado.set(pref)
                    cfg = self.backend_manager.get_config_backend(pref)
                    self.modelo_selecionado.set(cfg.get("modelo", "qwen3.5-9b.gguf"))
                    self.btn_ai_indicator.config(text=f"● {pref}: {self.modelo_selecionado.get()}")

            OnboardingWizard(top, manager=self.backend_manager, callback_finalizar=_on_done, on_concluido=_on_done)
        except Exception as e:
            messagebox.showerror("Erro", f"Falha ao abrir assistente de IA: {e}")

    def _mostrar_sobre(self):
        from updater import AutoUpdater
        v_local = AutoUpdater.versao_local()
        messagebox.showinfo(
            "ViralCuts Pro",
            f"⚡ ViralCuts Pro v{v_local}: AI-Powered Stream Highlights\n"
            f"Editor Profissional com Automação Total de Cortes e Legendas.\n\n"
            f"Versão instalada: {v_local}"
        )

    # ─── Auto-Updater ───────────────────────────────────────────────────────────

    def _iniciar_verificacao_atualizacao(self):
        def _on_silent(tem_update, dados, msg):
            if tem_update and dados:
                self._on_update_disponivel(dados)

        self._updater.verificar_em_background(root=self.root, callback=_on_silent)

    def _on_update_disponivel(self, dados_remoto: dict):
        versao_nova = dados_remoto.get("version", "?")
        notas = dados_remoto.get("notas", "")
        self._exibir_banner_update(versao_nova, notas)

    def _exibir_banner_update(self, versao_nova: str, notas: str):
        if self._banner_update_frame:
            self._banner_update_frame.destroy()

        banner = tk.Frame(self.root, bg="#0c4a6e", height=28)
        banner.pack(fill="x", side="bottom", before=self.status_bar)
        banner.pack_propagate(False)
        self._banner_update_frame = banner

        tk.Label(
            banner,
            text=f"🔄 Nova versão disponível: v{versao_nova} — {notas[:55]}{'...' if len(notas) > 55 else ''}",
            bg="#0c4a6e",
            fg="#e0f2fe",
            font=(FONT_FAMILY, 8)
        ).pack(side="left", padx=10)

        tk.Button(
            banner,
            text="Atualizar agora",
            bg="#0284c7",
            fg="#ffffff",
            bd=0, padx=10, pady=0,
            font=(FONT_FAMILY, 8, "bold"),
            cursor="hand2",
            command=self._aplicar_update
        ).pack(side="left", padx=4)

        tk.Button(
            banner,
            text="✕",
            bg="#0c4a6e",
            fg="#7dd3fc",
            bd=0, padx=6,
            font=(FONT_FAMILY, 9),
            cursor="hand2",
            command=lambda: banner.destroy()
        ).pack(side="right", padx=4)

    def _aplicar_update(self):
        """Bloqueia interações do usuário, exibe modal com progresso e aplica a atualização."""
        if self._banner_update_frame:
            self._banner_update_frame.destroy()
            self._banner_update_frame = None

        modal = tk.Toplevel(self.root)
        modal.title("Atualizando ViralCuts Pro")
        modal.geometry("440x210")
        modal.resizable(False, False)
        modal.configure(bg=BG_SECONDARY)
        modal.transient(self.root)
        modal.grab_set()

        try:
            modal.update_idletasks()
            x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 220
            y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 105
            modal.geometry(f"+{x}+{y}")
        except Exception:
            pass

        self._modal_update = modal

        tk.Label(
            modal,
            text="⚡ Atualizando ViralCuts Pro...",
            font=(FONT_FAMILY, 11, "bold"),
            bg=BG_SECONDARY,
            fg=CYAN_ACCENT
        ).pack(pady=(22, 6))

        lbl_modal_status = tk.Label(
            modal,
            text="Baixando atualização do servidor...",
            font=(FONT_FAMILY, 9),
            bg=BG_SECONDARY,
            fg=TEXT_PRIMARY
        )
        lbl_modal_status.pack(pady=4)
        self._lbl_modal_update_status = lbl_modal_status

        modal_prog = ttk.Progressbar(modal, mode="determinate", length=380)
        modal_prog.pack(pady=(8, 8))

        lbl_modal_hint = tk.Label(
            modal,
            text="Aguarde. O aplicativo será reiniciado automaticamente ao concluir.",
            font=(FONT_FAMILY, 8),
            bg=BG_SECONDARY,
            fg=TEXT_MUTED
        )
        lbl_modal_hint.pack(pady=(2, 0))

        def _log(msg: str):
            self.root.after(0, lambda: lbl_modal_status.config(text=msg[:50]))

        def _progresso(pct: int):
            self.root.after(0, lambda: modal_prog.config(value=pct))

        self.step_panel.set_gerando(True)

        self._updater.aplicar_update(
            progresso_cb=_progresso,
            log_cb=_log,
            root=self.root
        )

    def _on_patch_aplicado(self, sucesso: bool):
        self.step_panel.set_gerando(False)
        self.progress_bar.stop()
        if sucesso:
            self.lbl_status_right.config(text="Atualização aplicada! Reiniciando...", fg=ACCENT_GREEN)
            if hasattr(self, "_lbl_modal_update_status") and self._lbl_modal_update_status:
                try:
                    self._lbl_modal_update_status.config(text="Atualização aplicada! Reiniciando...", fg=ACCENT_GREEN)
                except Exception:
                    pass
        else:
            self.lbl_status_right.config(text="Falha na atualização", fg=ACCENT_RED)
            if hasattr(self, "_modal_update") and self._modal_update:
                try:
                    self._modal_update.destroy()
                except Exception:
                    pass
            messagebox.showerror("Erro", "Não foi possível aplicar a atualização.\nVerifique sua conexão com a internet.")

    def _verificar_update_manual(self):
        self.lbl_status_right.config(text="Verificando atualizações...", fg=CYAN_ACCENT)
        self.lbl_status_left.config(text="Consultando GitHub por novas versões...")

        def _on_manual(tem_update, dados, msg):
            if tem_update and dados:
                self.lbl_status_right.config(text="Update Disponível!", fg=CYAN_ACCENT)
                self.lbl_status_left.config(text=msg)
                self._on_update_disponivel(dados)
            else:
                self.lbl_status_right.config(text="Status: Concluído", fg=ACCENT_GREEN)
                self.lbl_status_left.config(text=msg.split('\n')[0])
                messagebox.showinfo("Verificação de Atualizações", msg)

        self._updater.verificar_em_background(root=self.root, callback=_on_manual)


def main():
    root = tk.Tk()
    app = LiveCutterProGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and any(arg in sys.argv for arg in ["--esteira", "--backend", "--nota-minima", "--url", "--force"]):
        import esteira
        if "--esteira" in sys.argv:
            sys.argv.remove("--esteira")
        esteira.main()
    else:
        main()

