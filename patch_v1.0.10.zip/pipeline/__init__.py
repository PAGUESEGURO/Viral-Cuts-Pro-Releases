"""
=============================================================================
VIRAL CUTS PRO - PACOTE PRINCIPAL DA PIPELINE (CLEAN ARCHITECTURE)
=============================================================================
"""

from pipeline.models import TranscriptionSegment, CutSegment, PipelineState
from pipeline.exceptions import (
    PipelineError,
    ValidationError,
    TranscriptionError,
    RenderingError,
    AIAnalysisError
)
from pipeline.validation import (
    validar_video_path,
    validar_transcricao,
    validar_intervalo_tempo,
    validar_config_ia
)
from pipeline.interfaces import (
    ITranscriptionService,
    ISubtitleService,
    IRenderService,
    IHistoryRepository,
    IAIAnalyzerService
)
from pipeline.observability import logger, PipelineLogger
from pipeline.use_cases import ProcessVideoPipelineUseCase
from pipeline.adapters import (
    WhisperTranscriptionAdapter,
    ASSEngineAdapter,
    FFmpegRenderAdapter,
    JSONHistoryAdapter,
    ViralAnalyzerAdapter
)

def criar_pipeline_completo(
    transcription_service: ITranscriptionService = None,
    ai_analyzer: IAIAnalyzerService = None,
    render_service: IRenderService = None,
    history_repo: IHistoryRepository = None,
    subtitle_service: ISubtitleService = None
) -> ProcessVideoPipelineUseCase:
    """Fábrica de Injeção de Dependências que monta a esteira pronta para execução com Clean Architecture."""
    return ProcessVideoPipelineUseCase(
        transcription_service=transcription_service or WhisperTranscriptionAdapter(),
        ai_analyzer=ai_analyzer or ViralAnalyzerAdapter(),
        render_service=render_service or FFmpegRenderAdapter(),
        history_repo=history_repo or JSONHistoryAdapter(),
        subtitle_service=subtitle_service or ASSEngineAdapter()
    )

__all__ = [
    "TranscriptionSegment",
    "CutSegment",
    "PipelineState",
    "PipelineError",
    "ValidationError",
    "TranscriptionError",
    "RenderingError",
    "AIAnalysisError",
    "validar_video_path",
    "validar_transcricao",
    "validar_intervalo_tempo",
    "validar_config_ia",
    "ITranscriptionService",
    "ISubtitleService",
    "IRenderService",
    "IHistoryRepository",
    "IAIAnalyzerService",
    "logger",
    "PipelineLogger",
    "ProcessVideoPipelineUseCase",
    "criar_pipeline_completo",
    "WhisperTranscriptionAdapter",
    "ASSEngineAdapter",
    "FFmpegRenderAdapter",
    "JSONHistoryAdapter",
    "ViralAnalyzerAdapter"
]

