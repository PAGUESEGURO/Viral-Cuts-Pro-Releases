from pathlib import Path
from typing import Dict, Any, Optional
import esteira
from pipeline.interfaces import IRenderService

class FFmpegRenderAdapter(IRenderService):
    """Adaptador que conecta a interface IRenderService ao pipeline de renderização FFmpeg com Two-Stage Seeking."""

    def renderizar_corte(
        self,
        sec_in: float,
        sec_out: float,
        titulo: str,
        video_path: Path,
        num_corte: int,
        corte_dict: Optional[Dict[str, Any]] = None,
        nome_canal: Optional[str] = None
    ) -> Optional[str]:
        return esteira.renderizar_corte_single(
            sec_in=sec_in,
            sec_out=sec_out,
            titulo_bruto=titulo,
            video_path=video_path,
            num_corte=num_corte,
            corte_dict=corte_dict,
            nome_canal=nome_canal
        )
