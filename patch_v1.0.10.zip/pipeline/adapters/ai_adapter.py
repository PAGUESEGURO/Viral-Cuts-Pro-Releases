from typing import List, Dict, Any, Optional
import viral_intelligence
from pipeline.interfaces import IAIAnalyzerService

class ViralAnalyzerAdapter(IAIAnalyzerService):
    """Adaptador que conecta a interface IAIAnalyzerService ao motor de inteligência viral multi-backend."""

    def __init__(self, analyzer: Optional[viral_intelligence.ViralAnalyzer] = None):
        self._analyzer = analyzer or viral_intelligence.ViralAnalyzer()

    def analisar_trecho(self, texto_pacote: str, transcricao_linhas_pacote: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        return self._analyzer.analisar_trecho(texto_pacote, transcricao_linhas_pacote=transcricao_linhas_pacote)
