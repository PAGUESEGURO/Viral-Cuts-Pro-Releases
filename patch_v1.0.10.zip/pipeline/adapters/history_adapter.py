from pathlib import Path
from typing import List, Dict, Any, Optional
import history_manager
from pipeline.interfaces import IHistoryRepository

class JSONHistoryAdapter(IHistoryRepository):
    """Adaptador que conecta a interface IHistoryRepository ao gerenciador transacional HistoryManager."""

    def __init__(self, manager: Optional[history_manager.HistoryManager] = None):
        self._mgr = manager or history_manager.obter_history_manager()

    def carregar_historico(self, hash_proj: str = "global", forcar_recorte: bool = False) -> List[Dict[str, Any]]:
        return self._mgr.carregar_historico(hash_proj=hash_proj, forcar_recorte=forcar_recorte)

    def salvar_historico(self, historico: List[Dict[str, Any]], hash_proj: str = "global") -> None:
        self._mgr.salvar_historico(historico=historico, hash_proj=hash_proj)

    def sincronizar_com_disco(self, historico: List[Dict[str, Any]], dir_saida: Optional[Path] = None) -> List[Dict[str, Any]]:
        return self._mgr.sincronizar_com_disco(historico=historico, dir_saida=dir_saida)
