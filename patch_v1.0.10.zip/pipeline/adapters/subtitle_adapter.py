from pathlib import Path
from typing import List, Dict, Any, Optional
import subtitles
from pipeline.interfaces import ISubtitleService

class ASSEngineAdapter(ISubtitleService):
    """Adaptador que conecta a interface ISubtitleService ao motor de legendas ASS dinâmico do TikTok."""

    def gerar_ass(
        self,
        sec_in: float,
        sec_out: float,
        transcricao: List[Dict[str, Any]],
        num_corte: int,
        dir_saida: Optional[Path] = None,
        nome_canal: Optional[str] = None
    ) -> Optional[Path]:
        return subtitles.gerar_ass_para_corte(
            sec_in=sec_in,
            sec_out=sec_out,
            transcricao=transcricao,
            num_corte=num_corte,
            dir_saida=dir_saida,
            nome_canal=nome_canal
        )

    def gerar_srt(
        self,
        sec_in: float,
        sec_out: float,
        transcricao: List[Dict[str, Any]],
        num_corte: int,
        dir_saida: Optional[Path] = None
    ) -> Optional[Path]:
        return subtitles.gerar_srt_para_corte(
            sec_in=sec_in,
            sec_out=sec_out,
            transcricao=transcricao,
            num_corte=num_corte,
            dir_saida=dir_saida
        )
