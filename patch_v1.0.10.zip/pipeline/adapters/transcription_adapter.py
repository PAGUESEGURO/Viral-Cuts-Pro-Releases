from pathlib import Path
from typing import List
import esteira
from pipeline.interfaces import ITranscriptionService
from pipeline.models import TranscriptionSegment

class WhisperTranscriptionAdapter(ITranscriptionService):
    """Adaptador que conecta a interface ITranscriptionService ao motor Whisper com cache persistente."""

    def transcrever(self, video_path: Path, hash_proj: str) -> List[TranscriptionSegment]:
        falas_raw = esteira.gerenciar_transcricao_completa(video_path, hash_proj)
        if not falas_raw:
            return []
        return [TranscriptionSegment.from_dict(f) for f in falas_raw if isinstance(f, dict)]
