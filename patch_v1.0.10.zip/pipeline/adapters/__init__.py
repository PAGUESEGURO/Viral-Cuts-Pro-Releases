"""
=============================================================================
VIRAL CUTS PRO - ADAPTADORES CONCRETOS (CLEAN ARCHITECTURE)
Conecta as interfaces puras aos serviços de infraestrutura reais.
=============================================================================
"""

from pipeline.adapters.transcription_adapter import WhisperTranscriptionAdapter
from pipeline.adapters.subtitle_adapter import ASSEngineAdapter
from pipeline.adapters.render_adapter import FFmpegRenderAdapter
from pipeline.adapters.history_adapter import JSONHistoryAdapter
from pipeline.adapters.ai_adapter import ViralAnalyzerAdapter

__all__ = [
    "WhisperTranscriptionAdapter",
    "ASSEngineAdapter",
    "FFmpegRenderAdapter",
    "JSONHistoryAdapter",
    "ViralAnalyzerAdapter"
]
