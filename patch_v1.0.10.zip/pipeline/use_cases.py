"""
=============================================================================
VIRAL CUTS PRO - CASOS DE USO PRINCIPAIS (APPLICATION LAYER)
Orquestração Desacoplada e Testável com Injeção de Dependências
=============================================================================
"""

import time
from pathlib import Path
from typing import List, Dict, Any, Optional

from pipeline.models import TranscriptionSegment, CutSegment, PipelineState
from pipeline.interfaces import (
    ITranscriptionService,
    ISubtitleService,
    IRenderService,
    IHistoryRepository,
    IAIAnalyzerService
)
from pipeline.validation import (
    validar_video_path,
    validar_transcricao,
    validar_intervalo_tempo,
    validar_config_ia
)
from pipeline.exceptions import PipelineError, ValidationError, TranscriptionError, RenderingError
from pipeline.observability import logger


class ProcessVideoPipelineUseCase:
    """Caso de uso orquestrador que executa a esteira ponta a ponta sem acoplamento a frameworks."""

    def __init__(
        self,
        transcription_service: ITranscriptionService,
        ai_analyzer: IAIAnalyzerService,
        render_service: IRenderService,
        history_repo: IHistoryRepository,
        subtitle_service: ISubtitleService,
    ):
        self.transcription_service = transcription_service
        self.ai_analyzer = ai_analyzer
        self.render_service = render_service
        self.history_repo = history_repo
        self.subtitle_service = subtitle_service

    def executar(
        self,
        video_path: Path,
        hash_proj: str,
        nome_canal: Optional[str] = None,
        nota_minima: int = 6,
        forcar_recorte: bool = False
    ) -> List[str]:
        """
        Executa o fluxo completo da esteira:
        1. Validação Fail-Fast do vídeo
        2. Transcrição com cache
        3. Fatiamento em blocos seguros
        4. Extração viral com IA
        5. Renderização frame-accurate 9:16
        6. Persistência atômica transacional
        """
        t_inicio = time.time()
        logger.info(f"Iniciando pipeline para {video_path.name}", {"hash": hash_proj})

        # 1. Validação Fail-Fast
        video_validado = validar_video_path(video_path)

        # 2. Carregamento do histórico
        historico_raw = self.history_repo.carregar_historico(hash_proj, forcar_recorte=forcar_recorte)

        # 3. Transcrição
        segmentos_transcricao = self.transcription_service.transcrever(video_validado, hash_proj)
        if not segmentos_transcricao:
            raise TranscriptionError(f"Não foi possível obter transcrição para o vídeo {video_validado.name}")

        falas_dict = [s.to_dict() for s in segmentos_transcricao]
        validar_transcricao(falas_dict)

        # 4. Fatiamento em blocos de 3 min
        pacotes = self._fatiar_transcricao(falas_dict)
        logger.info(f"Transcrição dividida em {len(pacotes)} pacotes de 3min.")

        # 5. Processamento dos pacotes e renderização imediata
        cortes_finais = []
        num_corte = max([int(h.get("id", 0)) for h in historico_raw], default=0)

        for idx, (t_in_pct, t_out_pct, falas_pct) in enumerate(pacotes, start=1):
            texto_pct = "\n".join(f"{f['tempo_formatado']} {f['texto']}" for f in falas_pct)
            cortes_sugeridos = self.ai_analyzer.analisar_trecho(texto_pct, transcricao_linhas_pacote=falas_pct)

            for c in cortes_sugeridos:
                if not isinstance(c, dict):
                    continue

                pontuacao = int(c.get("pontuacao_viral", 7))
                if pontuacao < nota_minima:
                    continue

                s_in = float(c.get("sec_in", 0.0))
                s_out = float(c.get("sec_out", 0.0))

                try:
                    validar_intervalo_tempo(s_in, s_out)
                except ValidationError as e_val:
                    logger.warning(f"Intervalo de corte inválido ({e_val}), pulando...")
                    continue

                # Verifica sobreposição no histórico
                if hasattr(self.history_repo, 'eh_corte_duplicado') and self.history_repo.eh_corte_duplicado(s_in, s_out, historico_raw):
                    continue

                num_corte += 1
                titulo = c.get("titulo_viral", f"corte_{num_corte}")

                res_arquivo = self.render_service.renderizar_corte(
                    sec_in=s_in,
                    sec_out=s_out,
                    titulo=titulo,
                    video_path=video_validado,
                    num_corte=num_corte,
                    corte_dict=c,
                    nome_canal=nome_canal
                )

                if res_arquivo:
                    cortes_finais.append(res_arquivo)
                    item_hist = {
                        "id": num_corte,
                        "arquivo": res_arquivo,
                        "sec_in": s_in,
                        "sec_out": s_out,
                        "duracao": round(s_out - s_in, 1),
                        "titulo": titulo,
                        "headline": c.get("headline_overlay", ""),
                        "hook": c.get("hook", ""),
                        "pontuacao_viral": pontuacao,
                        "categoria": c.get("categoria", "VIRAL"),
                        "motivo": c.get("motivo", "")
                    }
                    historico_raw.append(item_hist)
                    self.history_repo.salvar_historico(historico_raw, hash_proj)

        logger.performance("Pipeline completa", time.time() - t_inicio, {"cortes_gerados": len(cortes_finais)})
        return cortes_finais

    def _fatiar_transcricao(self, falas: List[Dict[str, Any]], bloco_segundos: float = 180.0, max_linhas: int = 120) -> List[tuple]:
        """Fatia a transcrição em blocos de até 3 minutos ou 120 linhas."""
        pacotes = []
        bloco_atual = []
        t_in_bloco = 0.0
        t_out_bloco = 0.0

        for f in falas:
            if not bloco_atual:
                t_in_bloco = float(f.get("inicio", 0.0))
            bloco_atual.append(f)
            t_out_bloco = float(f.get("fim", 0.0))

            if (t_out_bloco - t_in_bloco >= bloco_segundos) or (len(bloco_atual) >= max_linhas):
                pacotes.append((t_in_bloco, t_out_bloco, list(bloco_atual)))
                bloco_atual = []

        if bloco_atual:
            pacotes.append((t_in_bloco, t_out_bloco, list(bloco_atual)))

        return pacotes
