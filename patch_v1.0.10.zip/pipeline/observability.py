"""
=============================================================================
VIRAL CUTS PRO - OBSERVABILIDADE E LOGGING ESTRUTURADO
Rastreamento com Contexto, Métricas de Desempenho e Auditoria Transacional
=============================================================================
"""

import time
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any

DIR_ATUAL = Path(__file__).parent.parent.resolve()
ARQUIVO_LOG_PADRAO = DIR_ATUAL / "esteira_debug.log"


class PipelineLogger:
    """Logger estruturado com contexto de execução e auditoria de eventos."""

    def __init__(self, arquivo_log: Optional[Path] = None):
        self.arquivo_log = Path(arquivo_log) if arquivo_log else ARQUIVO_LOG_PADRAO

    def log(self, mensagem: str, nivel: str = "INFO", contexto: Optional[Dict[str, Any]] = None):
        """Registra mensagem formatada e estruturada no arquivo de log com timestamp."""
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        ctx_str = f" | {json.dumps(contexto, ensure_ascii=False)}" if contexto else ""
        linha = f"[{ts}] [{nivel.upper()}] {mensagem}{ctx_str}\n"

        try:
            with open(self.arquivo_log, "a", encoding="utf-8") as f:
                f.write(linha)
                f.flush()
        except Exception:
            pass

    def info(self, msg: str, ctx: Optional[Dict[str, Any]] = None):
        self.log(msg, "INFO", ctx)

    def warning(self, msg: str, ctx: Optional[Dict[str, Any]] = None):
        self.log(msg, "WARNING", ctx)

    def error(self, msg: str, ctx: Optional[Dict[str, Any]] = None):
        self.log(msg, "ERROR", ctx)

    def performance(self, operacao: str, duracao_seg: float, detalhes: Optional[Dict[str, Any]] = None):
        """Log especializado para telemetria e benchmarking de etapas pesadas."""
        ctx = {"duracao_seg": round(duracao_seg, 2)}
        if detalhes:
            ctx.update(detalhes)
        self.log(f"[PERFORMANCE] {operacao} finalizada em {duracao_seg:.2f}s", "INFO", ctx)


# Instância global padrão de observabilidade
logger = PipelineLogger()
