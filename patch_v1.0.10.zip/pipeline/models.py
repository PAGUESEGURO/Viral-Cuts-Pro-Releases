"""
=============================================================================
VIRAL CUTS PRO - MODELOS IMUTÁVEIS DE DOMÍNIO (DATACLASSES)
Estruturas de Dados Puras e Imutáveis para Eliminar Estado Global Mutável
=============================================================================
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Tuple, Dict, Any, List


@dataclass(frozen=True)
class TranscriptionSegment:
    """Segmento individual de fala da transcrição."""
    inicio: float
    fim: float
    texto: str
    tempo_formatado: str
    emocao: str = "NEUTRO"
    score_energia: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "inicio": self.inicio,
            "fim": self.fim,
            "texto": self.texto,
            "tempo_formatado": self.tempo_formatado,
            "emocao": self.emocao,
            "score_energia": self.score_energia
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'TranscriptionSegment':
        return cls(
            inicio=float(d.get("inicio", 0.0)),
            fim=float(d.get("fim", 0.0)),
            texto=str(d.get("texto", "")).strip(),
            tempo_formatado=str(d.get("tempo_formatado", "")),
            emocao=str(d.get("emocao", "NEUTRO")),
            score_energia=float(d.get("score_energia", 0.0))
        )


@dataclass(frozen=True)
class CutSegment:
    """Metadados completos de um corte viral selecionado ou renderizado."""
    id: int
    titulo: str
    headline: str
    hook: str
    sec_in: float
    sec_out: float
    duracao: float
    pontuacao_viral: int
    categoria: str
    motivo: str
    arquivo: Optional[str] = None
    edicao: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "arquivo": self.arquivo,
            "sec_in": self.sec_in,
            "sec_out": self.sec_out,
            "duracao": self.duracao,
            "titulo": self.titulo,
            "headline": self.headline,
            "hook": self.hook,
            "pontuacao_viral": self.pontuacao_viral,
            "categoria": self.categoria,
            "motivo": self.motivo,
            "edicao": self.edicao
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'CutSegment':
        return cls(
            id=int(d.get("id", 1)),
            titulo=str(d.get("titulo") or d.get("titulo_viral", "Corte")),
            headline=str(d.get("headline") or d.get("headline_overlay", "")),
            hook=str(d.get("hook", "")),
            sec_in=float(d.get("sec_in", 0.0)),
            sec_out=float(d.get("sec_out", 0.0)),
            duracao=float(d.get("duracao", 0.0)),
            pontuacao_viral=int(d.get("pontuacao_viral", 7)),
            categoria=str(d.get("categoria", "VIRAL")).upper(),
            motivo=str(d.get("motivo", "")),
            arquivo=d.get("arquivo"),
            edicao=d.get("edicao") if isinstance(d.get("edicao"), dict) else {}
        )


@dataclass(frozen=True)
class PipelineState:
    """Estado imutável de execução de uma esteira de cortes."""
    video_path: Path
    hash_proj: str
    tamanho_gb: float
    transcricao: Tuple[TranscriptionSegment, ...]
    pacotes_arquivos: Tuple[Path, ...]
    nome_canal: Optional[str] = None
    modelo_ia: str = "qwen3.5-9b.gguf"
    nota_minima: int = 6
