"""
=============================================================================
VIRAL CUTS PRO - MÓDULO DE VALIDAÇÃO DEFENSIVA (FAIL-FAST)
Garante Integridade de Dados Antes do Início de Qualquer Operação Pesada
=============================================================================
"""

from pathlib import Path
from typing import List, Dict, Any, Optional

from pipeline.exceptions import ValidationError

EXTENSOES_VALIDAS = {".mpg", ".mpeg", ".ts", ".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".wmv", ".m4v"}


def validar_video_path(caminho: Any) -> Path:
    """Valida se o arquivo de vídeo existe, é um arquivo real e tem extensão suportada."""
    if caminho is None:
        raise ValidationError("Caminho do arquivo de vídeo não pode ser nulo (None).")
    
    p = Path(caminho).resolve()
    if not p.exists():
        raise ValidationError(f"Arquivo de vídeo não encontrado no disco: {p}")
    
    if not p.is_file():
        raise ValidationError(f"O caminho informado não é um arquivo válido: {p}")
        
    if p.stat().st_size < 1000:
        raise ValidationError(f"O arquivo de vídeo está vazio ou corrompido (tamanho: {p.stat().st_size} bytes): {p.name}")

    if p.suffix.lower() not in EXTENSOES_VALIDAS:
        raise ValidationError(f"Extensão de vídeo não suportada '{p.suffix}'. Extensões aceitas: {', '.join(sorted(EXTENSOES_VALIDAS))}")

    return p


def validar_transcricao(transcricao: Any) -> List[Dict[str, Any]]:
    """Valida se a lista de transcrição é válida e contém segmentos com falas."""
    if not isinstance(transcricao, (list, tuple)):
        raise ValidationError(f"Transcrição deve ser uma lista ou tupla, recebido: {type(transcricao).__name__}")

    if len(transcricao) == 0:
        raise ValidationError("A transcrição está vazia (0 falas detectadas).")

    for idx, item in enumerate(transcricao):
        if not isinstance(item, dict):
            raise ValidationError(f"Segmento #{idx} da transcrição não é um dicionário válido: {item}")
        if "inicio" not in item or "fim" not in item:
            raise ValidationError(f"Segmento #{idx} da transcrição não possui chaves obrigatórias 'inicio' e 'fim': {item}")
        if float(item["fim"]) < float(item["inicio"]):
            raise ValidationError(f"Segmento #{idx} possui timestamp de fim menor que o início ({item['inicio']} > {item['fim']})")

    return list(transcricao)


def validar_intervalo_tempo(sec_in: float, sec_out: float, duracao_min: float = 8.0, duracao_max: float = 180.0) -> float:
    """Valida se o intervalo de corte tem limites coerentes e duração dentro dos limites."""
    if sec_in < 0:
        raise ValidationError(f"Timestamp de início não pode ser negativo ({sec_in}s)")
    
    if sec_out <= sec_in:
        raise ValidationError(f"Timestamp de fim ({sec_out}s) deve ser estritamente maior que o início ({sec_in}s)")

    duracao = sec_out - sec_in
    if duracao < duracao_min:
        raise ValidationError(f"Duração do corte ({duracao:.1f}s) é menor que o mínimo aceitável ({duracao_min}s)")

    if duracao > duracao_max:
        raise ValidationError(f"Duração do corte ({duracao:.1f}s) excede o limite máximo permitido ({duracao_max}s)")

    return duracao


def validar_config_ia(url: Optional[str], modelo: Optional[str], api_key: Optional[str] = None) -> Dict[str, str]:
    """Valida se a configuração de backend de IA é válida."""
    if not url or not str(url).strip():
        raise ValidationError("URL do servidor de IA não pode ser vazia.")
    
    if not modelo or not str(modelo).strip():
        raise ValidationError("Nome do modelo de IA não pode ser vazio.")

    url_limpa = str(url).strip()
    if not url_limpa.startswith(("http://", "https://")):
        raise ValidationError(f"URL de IA inválida '{url_limpa}'. Deve iniciar com http:// ou https://")

    return {
        "url": url_limpa,
        "modelo": str(modelo).strip(),
        "api_key": str(api_key or "").strip()
    }
