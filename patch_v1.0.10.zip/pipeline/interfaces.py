"""
=============================================================================
VIRAL CUTS PRO - CONTRATOS E INTERFACES (CLEAN ARCHITECTURE / SOLID)
Isola o Núcleo Lógico de Dependências Externas (FFmpeg, Whisper, LLMs, GUI)
=============================================================================
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

from pipeline.models import TranscriptionSegment, CutSegment, PipelineState


class ITranscriptionService(ABC):
    """Contrato abstrato para serviços de transcrição de áudio/vídeo."""

    @abstractmethod
    def transcrever(self, video_path: Path, hash_proj: str) -> List[TranscriptionSegment]:
        """Transcreve o arquivo de vídeo e retorna lista pura de segmentos imutáveis."""
        pass


class ISubtitleService(ABC):
    """Contrato abstrato para geração de legendas formatadas."""

    @abstractmethod
    def gerar_ass(self, sec_in: float, sec_out: float, transcricao: List[Dict[str, Any]], num_corte: int, dir_saida: Optional[Path] = None, nome_canal: Optional[str] = None) -> Optional[Path]:
        """Gera arquivo .ass estilizado."""
        pass

    @abstractmethod
    def gerar_srt(self, sec_in: float, sec_out: float, transcricao: List[Dict[str, Any]], num_corte: int, dir_saida: Optional[Path] = None) -> Optional[Path]:
        """Gera arquivo .srt de fallback."""
        pass


class IRenderService(ABC):
    """Contrato abstrato para renderização de vídeo vertical 9:16."""

    @abstractmethod
    def renderizar_corte(self, sec_in: float, sec_out: float, titulo: str, video_path: Path, num_corte: int, corte_dict: Optional[Dict[str, Any]] = None, nome_canal: Optional[str] = None) -> Optional[str]:
        """Executa renderização frame-accurate e retorna o nome do arquivo gerado."""
        pass


class IHistoryRepository(ABC):
    """Contrato abstrato para persistência transacional de histórico de cortes."""

    @abstractmethod
    def carregar_historico(self, hash_proj: str = "global", forcar_recorte: bool = False) -> List[Dict[str, Any]]:
        """Carrega lista de cortes registrados."""
        pass

    @abstractmethod
    def salvar_historico(self, historico: List[Dict[str, Any]], hash_proj: str = "global") -> None:
        """Persiste atomicamente o histórico no disco."""
        pass

    @abstractmethod
    def sincronizar_com_disco(self, historico: List[Dict[str, Any]], dir_saida: Optional[Path] = None) -> List[Dict[str, Any]]:
        """Sincroniza o histórico com os arquivos existentes no disco."""
        pass


class IAIAnalyzerService(ABC):
    """Contrato abstrato para análise viral de trechos de transcrição."""

    @abstractmethod
    def analisar_trecho(self, texto_pacote: str, transcricao_linhas_pacote: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        """Analisa o texto com modelo de linguagem e retorna cortes sugeridos validados."""
        pass
