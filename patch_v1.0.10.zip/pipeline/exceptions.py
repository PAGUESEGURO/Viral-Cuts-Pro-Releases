"""
=============================================================================
VIRAL CUTS PRO - HIERARQUIA DE EXCEÇÕES DE DOMÍNIO
Tratamento Defensivo e Erros Ricos em Contexto
=============================================================================
"""

class PipelineError(Exception):
    """Exceção base para todas as falhas de processamento da esteira."""
    pass


class ValidationError(PipelineError):
    """Erro de validação de argumentos, arquivos ou entradas (Fail-Fast)."""
    pass


class TranscriptionError(PipelineError):
    """Falha durante extração de áudio ou transcrição Whisper."""
    pass


class RenderingError(PipelineError):
    """Falha durante processamento de filtros de vídeo ou FFmpeg."""
    pass


class AIAnalysisError(PipelineError):
    """Falha na comunicação, timeout ou parsing da resposta do modelo de IA."""
    pass
