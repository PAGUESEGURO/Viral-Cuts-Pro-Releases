from .base import AIBackend


class GroqBackend(AIBackend):
    nome = "Groq"
    tipo = "cloud"
    icone = "⚡"
    cor = "#f97316"
    descricao_ajuda = (
        "Groq Cloud oferece velocidade ultra-rápida de inferência de LLMs em LPU.\n\n"
        "✅ Análise de transcrição em poucos segundos\n"
        "✅ Não consome memória RAM nem placa de vídeo do seu computador\n"
        "🔑 Requer chave de API gratuita cadastrada em console.groq.com"
    )

    URL_BASE = "https://api.groq.com/openai/v1"

    def detectar(self) -> dict:
        return {
            "disponivel": True,
            "modelos": self.get_modelos_recomendados(),
            "detalhes": "Cloud API (requer internet e API Key)"
        }

    def criar_cliente(self, url: str, api_key: str, modelo: str):
        if not api_key or not api_key.strip():
            raise ValueError("API Key do Groq é obrigatória. Obtenha gratuitamente em console.groq.com")
        from openai import OpenAI
        return OpenAI(
            base_url=self.URL_BASE,
            api_key=api_key.strip(),
            timeout=60.0
        )

    def get_url_padrao(self) -> str:
        return self.URL_BASE

    def get_modelos_recomendados(self) -> list:
        return [
            "qwen-2.5-32b",
            "llama-3.3-70b-versatile",
            "llama-3.1-8b-instant",
            "mixtral-8x7b-32768"
        ]
