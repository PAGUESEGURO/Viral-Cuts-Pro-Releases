from .base import AIBackend


class OpenRouterBackend(AIBackend):
    nome = "OpenRouter"
    tipo = "cloud"
    icone = "🌐"
    cor = "#06b6d4"
    descricao_ajuda = (
        "OpenRouter é um gateway unificado para centenas de modelos de IA de ponta.\n\n"
        "✅ Acesso a modelos Claude, Qwen, DeepSeek, Llama e Mistral\n"
        "✅ Sem necessidade de GPU local\n"
        "🔑 Requer chave de API configurada em openrouter.ai"
    )

    URL_BASE = "https://openrouter.ai/api/v1"

    def detectar(self) -> dict:
        return {
            "disponivel": True,
            "modelos": self.get_modelos_recomendados(),
            "detalhes": "Cloud API (requer internet e API Key)"
        }

    def criar_cliente(self, url: str, api_key: str, modelo: str):
        if not api_key or not api_key.strip():
            raise ValueError("API Key do OpenRouter é obrigatória. Obtenha em openrouter.ai")
        from openai import OpenAI
        return OpenAI(
            base_url=self.URL_BASE,
            api_key=api_key.strip(),
            timeout=60.0
        )

    def get_url_padrao(self) -> str:
        return self.URL_BASE

    def get_modelos_recomendados(self) -> list:
        return [
            "qwen/qwen-2.5-72b-instruct",
            "qwen/qwen-2.5-32b-instruct",
            "meta-llama/llama-3.3-70b-instruct",
            "mistralai/mixtral-8x7b-instruct"
        ]
