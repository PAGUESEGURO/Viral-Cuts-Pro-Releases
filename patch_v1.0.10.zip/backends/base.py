from abc import ABC, abstractmethod


class AIBackend(ABC):
    """Interface padrão que todo backend de IA deve implementar."""

    @property
    @abstractmethod
    def nome(self) -> str:
        """Nome legível do backend (ex: 'Ollama', 'LM Studio')."""
        pass

    @property
    @abstractmethod
    def tipo(self) -> str:
        """Tipo de infraestrutura: 'local' ou 'cloud'."""
        pass

    @property
    @abstractmethod
    def icone(self) -> str:
        """Emoji ou ícone para interface gráfica."""
        pass

    @property
    @abstractmethod
    def cor(self) -> str:
        """Cor de destaque em hexadecimal para badges e UI."""
        pass

    @property
    @abstractmethod
    def descricao_ajuda(self) -> str:
        """Texto explicativo para tooltip ou modal de ajuda."""
        pass

    @abstractmethod
    def detectar(self) -> dict:
        """
        Detecta se o serviço está online e quais modelos estão prontos.
        Retorna: {"disponivel": bool, "modelos": list[str], "detalhes": str}
        """
        pass

    @abstractmethod
    def criar_cliente(self, url: str, api_key: str, modelo: str):
        """
        Instancia um cliente compatível com a biblioteca OpenAI.
        Retorna objeto client ou lança exceção em caso de erro.
        """
        pass

    @abstractmethod
    def get_url_padrao(self) -> str:
        """Retorna a URL base padrão do backend."""
        pass

    @abstractmethod
    def get_modelos_recomendados(self) -> list:
        """Retorna lista de modelos recomendados para corte e análise viral."""
        pass
