import requests
from .base import AIBackend


class LMStudioBackend(AIBackend):
    nome = "LM Studio"
    tipo = "local"
    icone = "🎛️"
    cor = "#a855f7"
    descricao_ajuda = (
        "LM Studio é um aplicativo visual completo para rodar modelos GGUF locais.\n\n"
        "✅ Interface gráfica amigável para download de modelos\n"
        "✅ Roda 100% no seu computador (sem internet)\n"
        "⚠️ Lembre-se de clicar em 'Start Server' na aba Local Server do LM Studio"
    )

    CANDIDATOS_URL = [
        "http://26.242.55.50:1234",
        "http://127.0.0.1:1234",
        "http://localhost:1234"
    ]
    URL_BASE = "http://26.242.55.50:1234"

    def detectar(self) -> dict:
        for url in self.CANDIDATOS_URL:
            try:
                r = requests.get(f"{url}/v1/models", timeout=1.8)
                if r.status_code == 200:
                    dados = r.json()
                    modelos = [m.get("id", "") for m in dados.get("data", []) if m.get("id")]
                    self.URL_BASE = url
                    return {
                        "disponivel": True,
                        "modelos": modelos,
                        "url_detectada": f"{url}/v1",
                        "detalhes": f"{len(modelos)} modelo(s) carregado(s) em {url}" if modelos else f"Servidor online em {url}"
                    }
            except Exception:
                continue

        return {
            "disponivel": False,
            "modelos": [],
            "detalhes": "LM Studio offline. Abra o app, carregue o modelo e inicie o Local Server."
        }

    def criar_cliente(self, url: str, api_key: str, modelo: str):
        from openai import OpenAI
        base_url = url.rstrip("/") if url else f"{self.URL_BASE}/v1"
        if not base_url.endswith("/v1"):
            base_url = f"{base_url}/v1"
        return OpenAI(
            base_url=base_url,
            api_key=api_key or "lm-studio",
            timeout=180.0
        )

    def get_url_padrao(self) -> str:
        return f"{self.URL_BASE}/v1"

    def get_modelos_recomendados(self) -> list:
        return ["qwen3.5-9b.gguf", "qwen2.5-7b-instruct", "meta-llama-3.1-8b-instruct"]
