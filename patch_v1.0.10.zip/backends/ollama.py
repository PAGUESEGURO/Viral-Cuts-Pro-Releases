import requests
from .base import AIBackend


class OllamaBackend(AIBackend):
    nome = "Ollama"
    tipo = "local"
    icone = "🦙"
    cor = "#38bdf8"
    descricao_ajuda = (
        "Ollama é um motor de IA local gratuito e de alto desempenho.\n\n"
        "✅ Roda direto na sua placa de vídeo / CPU\n"
        "✅ Sem limite de uso e sem custos de API\n"
        "✅ Funciona 100% offline após baixar o modelo"
    )

    URL_BASE = "http://localhost:11434"

    def detectar(self) -> dict:
        try:
            r = requests.get(f"{self.URL_BASE}/api/tags", timeout=2.5)
            if r.status_code == 200:
                dados = r.json()
                modelos = [m.get("name", "") for m in dados.get("models", []) if m.get("name")]
                return {
                    "disponivel": True,
                    "modelos": modelos,
                    "detalhes": f"{len(modelos)} modelo(s) pronto(s)" if modelos else "Online (nenhum modelo baixado)"
                }
        except requests.ConnectionError:
            return {
                "disponivel": False,
                "modelos": [],
                "detalhes": "Ollama offline. Inicie com 'ollama serve' ou pelo app."
            }
        except Exception as e:
            return {"disponivel": False, "modelos": [], "detalhes": str(e)}

        return {"disponivel": False, "modelos": [], "detalhes": "Sem resposta"}

    def criar_cliente(self, url: str, api_key: str, modelo: str):
        from openai import OpenAI
        base_url = url.rstrip("/") if url else f"{self.URL_BASE}/v1"
        if not base_url.endswith("/v1"):
            base_url = f"{base_url}/v1"
        return OpenAI(
            base_url=base_url,
            api_key=api_key or "ollama",
            timeout=180.0
        )

    def get_url_padrao(self) -> str:
        return f"{self.URL_BASE}/v1"

    def get_modelos_recomendados(self) -> list:
        return ["qwen2.5:7b", "qwen2.5:14b", "llama3.2:3b", "llama3.1:8b", "mistral:7b"]
