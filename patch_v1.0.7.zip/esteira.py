"""
=============================================================================
VIRAL CUTS PRO - ORQUESTRADOR PRINCIPAL DA ESTEIRA DE CORTES VIRAIS
Motor Modular, Frame-Accurate, Multi-Backend com Legendas Dinâmicas TikTok
=============================================================================
"""

import os
import sys
import re
import time
import shutil
import argparse
import subprocess
from pathlib import Path
from collections import Counter
from typing import List, Dict, Any, Optional

from utils import (
    SafeStreamWrapper, setup_safe_streams, log_debug as _log_debug_base,
    gerar_hash_video, formatar_tempo, tempo_para_segundos,
    eh_linha_musica_ou_lixo, verificar_espaco_em_disco, inicializar_ffmpeg,
    encontrar_inicio_frase, encontrar_fim_frase, extrair_json_robusto,
    corrigir_vocabulario_streamer
)
from viral_intelligence import ViralAnalyzer, TranscriptPreprocessor, ViralValidator, ViralScorer
from viral_prompts import ViralPrompts
import smart_editor
import subtitles
from history_manager import HistoryManager

setup_safe_streams()
inicializar_ffmpeg()

# Dependências Opcionais
try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None

try:
    import requests
except ImportError:
    requests = None

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

HAS_RICH = False
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich import print as rprint
    console = Console()
    HAS_RICH = True
except ImportError:
    Console = None

# Diretórios e Configurações Globais
DIR_ATUAL = Path(__file__).parent.resolve()
DIR_PACOTES = DIR_ATUAL / "pacotes_txt"
DIR_SAIDA = DIR_ATUAL / "cortes_prontos"
DIR_ESTADOS = DIR_ATUAL / "projetos_estados"
DIR_ESTADOS.mkdir(parents=True, exist_ok=True)
DIR_SAIDA.mkdir(parents=True, exist_ok=True)

ARQUIVO_TRANSCRICAO = DIR_ATUAL / "transcricao_completa.txt"
ARQUIVO_HISTORICO_GLOBAL = DIR_ATUAL / "historico_cortes.json"
ARQUIVO_RELATORIO_MD = DIR_ATUAL / "relatorio_cortes.md"
ARQUIVO_RELATORIO_HTML = DIR_ATUAL / "relatorio_cortes.html"
ARQUIVO_LOG = DIR_ATUAL / "esteira_debug.log"

TRANSCRICAO_GLOBAL: List[Dict[str, Any]] = []
EXTENSOES_VIDEO = [".mpg", ".mpeg", ".ts", ".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".wmv", ".m4v"]

# Instância Central do Gerenciador de Histórico
history_mgr = HistoryManager(dir_estados=DIR_ESTADOS, dir_saida=DIR_SAIDA)

# Aliases para retrocompatibilidade com suítes de teste existentes
CORES_EMOCAO_ASS = subtitles.CORES_EMOCAO_ASS
ANIMACOES_EMOCAO_ASS = subtitles.ANIMACOES_EMOCAO_ASS
formatar_ass_time = subtitles.formatar_ass_time
calcular_tamanho_fonte_ass = subtitles.calcular_tamanho_fonte_ass
destacar_palavras_chave = subtitles.destacar_palavras_chave
gerar_ass_para_corte = subtitles.gerar_ass_para_corte
gerar_srt_para_corte = subtitles.gerar_srt_para_corte
def sincronizar_historico_com_disco(historico: List[Dict[str, Any]], dir_saida: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Wrapper de compatibilidade para sincronização de histórico."""
    return history_mgr.sincronizar_com_disco(historico, dir_saida=dir_saida)


def testar_lm_studio(url: Optional[str] = None) -> Optional[str]:
    """Testa conexão rápida com LM Studio local para retrocompatibilidade."""
    urls_teste = [url] if url else ["http://localhost:1234/v1", "http://127.0.0.1:1234/v1"]
    for u in urls_teste:
        if not u:
            continue
        try:
            r = requests.get(f"{u.rstrip('/')}/models", timeout=2.0)
            if r.status_code == 200:
                return u
        except Exception:
            pass
    return urls_teste[0] if urls_teste else "http://localhost:1234/v1"



def log_debug(mensagem: str, nivel: str = "INFO"):
    _log_debug_base(mensagem, nivel, arquivo_log=ARQUIVO_LOG)


def ler_pacote_estruturado(caminho_pacote_txt: Path) -> List[Dict[str, Any]]:
    """Lê um arquivo de pacote de texto e retorna lista de falas estruturadas com timestamps."""
    if not caminho_pacote_txt or not Path(caminho_pacote_txt).exists():
        return []
    linhas = []
    try:
        with open(caminho_pacote_txt, "r", encoding="utf-8", errors="replace") as f:
            for l in f:
                l_str = l.strip()
                if not l_str:
                    continue
                m = re.match(r'\[?(\d{1,2}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?)\s*(?:->|-->)\s*(\d{1,2}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?)\]?\s*(.*)', l_str)
                if m:
                    s_in = tempo_para_segundos(m.group(1))
                    s_out = tempo_para_segundos(m.group(2))
                    linhas.append({
                        "inicio": s_in,
                        "fim": s_out,
                        "tempo_formatado": f"[{m.group(1)} -> {m.group(2)}]",
                        "texto": m.group(3).strip()
                    })
    except Exception as e:
        log_debug(f"Erro ao ler pacote estruturado {caminho_pacote_txt}: {e}", "WARNING")
    return linhas


def formatar_linhas_para_ia(linhas_estruturadas: List[Dict[str, Any]]) -> str:
    """Converte lista de falas estruturadas em texto com timestamps para o prompt da IA."""
    if not linhas_estruturadas:
        return ""
    return "\n".join(f"{item.get('tempo_formatado', '')} {item.get('texto', '')}" for item in linhas_estruturadas)


def chamar_ia_com_timeout(url_lm, client_lm, system_prompt, user_prompt, modelo="qwen3.5-9b.gguf", timeout_sec=120, max_tentativas=2):
    """Função compatível para chamadas diretas com timeout e captura de reasoning_content."""
    if not client_lm:
        return None
    for tentativa in range(1, max_tentativas + 1):
        try:
            resp = client_lm.chat.completions.create(
                model=modelo,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                max_tokens=600,
                timeout=timeout_sec
            )
            if resp and resp.choices:
                msg = resp.choices[0].message
                conteudo = (getattr(msg, 'content', '') or '').strip()
                if not conteudo and msg:
                    conteudo = (getattr(msg, 'reasoning_content', '') or '').strip()
                if conteudo:
                    return conteudo
        except Exception as e_ia:
            log_debug(f"Falha na tentativa {tentativa}/{max_tentativas} de chamada à IA: {e_ia}", "WARNING")
            time.sleep(0.5)
    return None


def encontrar_video_na_pasta(caminho_especifico: Optional[str] = None) -> Optional[Path]:
    """Localiza o arquivo de vídeo especificado ou o mais recente da pasta."""
    if caminho_especifico:
        p = Path(caminho_especifico)
        if p.exists():
            return p

    arquivos = []
    for ext in EXTENSOES_VIDEO:
        for f in DIR_ATUAL.glob(f"*{ext}"):
            if f.exists() and not f.name.startswith("temp_") and not f.name.startswith("clean_"):
                arquivos.append(f)
        for f in DIR_ATUAL.glob(f"*{ext.upper()}"):
            if f.exists() and not f.name.startswith("temp_") and not f.name.startswith("clean_") and f not in arquivos:
                arquivos.append(f)

    if not arquivos:
        return None

    try:
        arquivos.sort(key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True)
    except Exception as e:
        log_debug(f"Aviso ao ordenar vídeos: {e}", "WARNING")

    return arquivos[0] if arquivos else None


def validar_video_ffprobe(video_path: Path) -> bool:
    """Valida se o vídeo gerado possui streams válidos de áudio e vídeo."""
    if not video_path or not Path(video_path).exists():
        return False
    try:
        if video_path.stat().st_size < 50000:
            return False
    except Exception:
        return False

    cmd = [
        "ffprobe", "-v", "error",
        "-select_streams", "v:0",
        "-show_entries", "stream=codec_type",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(video_path)
    ]
    try:
        cflags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=10, creationflags=cflags)
        return "video" in res.stdout.lower()
    except Exception as e:
        log_debug(f"Falha ao validar vídeo com ffprobe ({e})", "WARNING")
        return False


def fatiar_em_pacotes_txt(transcricao: List[Dict[str, Any]], hash_proj: str) -> List[Path]:
    """
    Fatia a transcrição em pacotes equilibrados de no máximo 3 minutos ou 120 linhas.
    Garante que o contexto da IA nunca estoure (evita erro 400 Context Overflow).
    """
    dir_pacotes_proj = DIR_ESTADOS / f"pacotes_{hash_proj}"
    dir_pacotes_proj.mkdir(exist_ok=True)

    for arq_antigo in dir_pacotes_proj.glob("pacote_*.txt"):
        try:
            arq_antigo.unlink()
        except Exception:
            pass

    BLOCO_SEGUNDOS = 3 * 60
    MAX_LINHAS_PACOTE = 120

    pacotes_arquivos = []
    bloco_atual = []
    tempo_bloco_inicio = 0.0
    tempo_bloco_fim = 0.0
    num_pacote = 1

    def _salvar_pacote(num, t_in, t_out, linhas):
        nome = f"pacote_{num:02d}_min_{int(t_in//60):03d}_{int(t_out//60):03d}.txt"
        caminho = dir_pacotes_proj / nome
        with open(caminho, "w", encoding="utf-8", errors="replace") as f:
            f.write("\n".join(linhas))
        return caminho

    for seg in transcricao:
        if eh_linha_musica_ou_lixo(seg.get("texto", "")):
            continue

        if not bloco_atual:
            tempo_bloco_inicio = float(seg["inicio"])

        bloco_atual.append(f"{seg['tempo_formatado']} {seg['texto']}")
        tempo_bloco_fim = float(seg["fim"])

        if (seg["fim"] - tempo_bloco_inicio >= BLOCO_SEGUNDOS) or (len(bloco_atual) >= MAX_LINHAS_PACOTE):
            arq = _salvar_pacote(num_pacote, tempo_bloco_inicio, tempo_bloco_fim, bloco_atual)
            pacotes_arquivos.append(arq)
            num_pacote += 1
            bloco_atual = []

    if bloco_atual:
        arq = _salvar_pacote(num_pacote, tempo_bloco_inicio, tempo_bloco_fim, bloco_atual)
        pacotes_arquivos.append(arq)

    log_debug(f"Fatiamento concluído para {hash_proj}: Total de {len(pacotes_arquivos)} pacotes de 3 min.")
    return pacotes_arquivos


def gerenciar_transcricao_completa(video_path: Path, hash_proj: str) -> Optional[List[Dict[str, Any]]]:
    """Gerencia transcrição reutilizando cache persistente ou executando Faster-Whisper."""
    global TRANSCRICAO_GLOBAL

    arq_transcricao_proj = DIR_ESTADOS / f"transcricao_{hash_proj}.txt"
    if arq_transcricao_proj.exists():
        log_debug(f"Reutilizando transcrição em cache para {hash_proj}")
        transcricao = []
        with open(arq_transcricao_proj, "r", encoding="utf-8", errors="replace") as f:
            for l in f:
                l = l.strip()
                if not l:
                    continue
                match = re.match(r'\[?(\d{1,2}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?)\s*(?:->|-->)\s*(\d{1,2}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?)\]?\s*(.*)', l)
                if match:
                    s_in = tempo_para_segundos(match.group(1))
                    s_out = tempo_para_segundos(match.group(2))
                    txt = match.group(3).strip()
                    if (s_out - s_in) > 0.15:
                        transcricao.append({
                            "inicio": s_in,
                            "fim": s_out,
                            "tempo_formatado": f"[{formatar_tempo(s_in)} -> {formatar_tempo(s_out)}]",
                            "texto": txt
                        })
        if transcricao:
            TRANSCRICAO_GLOBAL = transcricao
            print(f"✓ Transcrição do vídeo '{video_path.name}' reutilizada do cache ({len(transcricao)} falas limpas)!")
            return transcricao

    if WhisperModel is None:
        log_debug("faster_whisper não instalado. Impossível transcrever.", "ERROR")
        print("❌ Biblioteca 'faster-whisper' não instalada.")
        return None

    # Extrai WAV temporário com filtro de voz otimizado para fala
    audio_wav = DIR_ESTADOS / f"audio_temp_{hash_proj}.wav"
    alvo = video_path
    cflags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    try:
        cmd_wav = [
            "ffmpeg", "-y",
            "-fflags", "+genpts+discardcorrupt",
            "-avoid_negative_ts", "make_zero",
            "-i", str(video_path),
            "-vn",
            "-af", "highpass=f=80,lowpass=f=7500,loudnorm=I=-16:TP=-1.5:LRA=11",
            "-acodec", "pcm_s16le",
            "-ar", "16000",
            "-ac", "1",
            str(audio_wav)
        ]
        subprocess.run(cmd_wav, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=300, creationflags=cflags)
        if audio_wav.exists() and audio_wav.stat().st_size > 50000:
            alvo = audio_wav
    except Exception as e_wav:
        log_debug(f"Aviso na extração WAV ({e_wav}), usando vídeo original.", "WARNING")

    print(f"🎙️ Iniciando transcrição de alta precisão com Faster-Whisper...")

    prompt_streamer = "Live stream de jogos, gameplay, streamer brasileiro, Dark and Darker, loot, PvP, clutch, clipe viral, conversa em português do Brasil."

    def _obter_model_whisper():
        num_threads = os.cpu_count() or 4
        try:
            m = WhisperModel("small", device="cuda", compute_type="float16")
            s_gen, i_info = m.transcribe(str(alvo), language="pt", beam_size=1, vad_filter=True, word_timestamps=True, initial_prompt=prompt_streamer)
            return s_gen, "GPU (CUDA float16)"
        except Exception:
            pass

        try:
            m_int8 = WhisperModel("small", device="cuda", compute_type="int8_float16")
            s_gen, i_info = m_int8.transcribe(str(alvo), language="pt", beam_size=1, vad_filter=True, word_timestamps=True, initial_prompt=prompt_streamer)
            return s_gen, "GPU (CUDA int8)"
        except Exception:
            pass

        m_cpu = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=num_threads)
        s_gen, i_info = m_cpu.transcribe(str(alvo), language="pt", beam_size=1, vad_filter=True, word_timestamps=True, initial_prompt=prompt_streamer)
        return s_gen, f"CPU int8 ({num_threads} threads)"


    try:
        segments_gen, modo_usado = _obter_model_whisper()
        log_debug(f"Whisper inicializado em modo {modo_usado}")
    except Exception as e_mod:
        log_debug(f"Erro fatal ao inicializar Whisper: {e_mod}", "ERROR")
        return None

    transcricao = []
    linhas_para_salvar = []
    for s in segments_gen:
        if getattr(s, 'no_speech_prob', 0) > 0.6:
            continue
        txt_clean = s.text.strip()
        if (s.end - s.start) <= 0.2:
            continue
        t_fmt = f"[{formatar_tempo(s.start)} -> {formatar_tempo(s.end)}]"
        linhas_para_salvar.append(f"{t_fmt} {txt_clean}")
        transcricao.append({
            "inicio": s.start,
            "fim": s.end,
            "tempo_formatado": t_fmt,
            "texto": txt_clean
        })

    if audio_wav.exists():
        audio_wav.unlink(missing_ok=True)

    if transcricao:
        with open(arq_transcricao_proj, "w", encoding="utf-8") as f:
            f.write("\n".join(linhas_para_salvar) + "\n")
        TRANSCRICAO_GLOBAL = transcricao
        print(f"✓ Transcrição concluída com sucesso ({len(transcricao)} falas)!")
        return transcricao

    return None


def renderizar_corte_single(
    sec_in: float,
    sec_out: float,
    titulo_bruto: str,
    video_path: Path,
    num_corte: int,
    corte_dict: Optional[Dict[str, Any]] = None,
    nome_canal: Optional[str] = None
) -> Optional[str]:
    """
    Renderiza um corte viral em 9:16 vertical blur com legendas dinâmicas, jump cuts e frame-accurate seeking.
    """
    t_inicio_render = time.time()
    pad_in = getattr(subtitles, "PAD_INICIO_FALA", 0.20)
    pad_out = getattr(subtitles, "PAD_FIM_FALA", 0.35)

    falas_reais = [item for item in TRANSCRICAO_GLOBAL if item.get("fim", 0) > sec_in and item.get("inicio", 0) < sec_out and str(item.get("texto", "")).strip()]

    if falas_reais:
        sec_in_buffered = max(0.0, falas_reais[0]["inicio"] - pad_in)
        sec_out_buffered = min(falas_reais[-1]["fim"] + pad_out, sec_in_buffered + 120.0)
    elif TRANSCRICAO_GLOBAL:
        sec_in_buffered = encontrar_inicio_frase(TRANSCRICAO_GLOBAL, sec_in)
        sec_out_buffered = encontrar_fim_frase(TRANSCRICAO_GLOBAL, sec_out, duracao_max=120.0, sec_inicio=sec_in_buffered)
    else:
        sec_in_buffered = max(0.0, sec_in)
        sec_out_buffered = sec_out

    duracao = sec_out_buffered - sec_in_buffered
    if duracao < 8.0:
        return None

    titulo_limpo = re.sub(r'[^\w\s-]', '', str(titulo_bruto)).strip().replace(" ", "_").lower()
    if len(titulo_limpo) > 40:
        titulo_limpo = titulo_limpo[:40].rstrip("_")
    if not titulo_limpo:
        titulo_limpo = f"corte_{num_corte}"

    saida_mp4 = DIR_SAIDA / f"corte_{num_corte:02d}_{titulo_limpo}.mp4"
    saida_temp = DIR_SAIDA / f"corte_{num_corte:02d}_{titulo_limpo}.tmp.mp4"

    corte_data = corte_dict if isinstance(corte_dict, dict) else {"titulo_viral": titulo_limpo}

    # 1. Gera EDL e legendas com micro-transcrição word-level (precisão milimétrica de 0.00s drift)
    edl = smart_editor.gerar_edit_decision_list(corte_data, TRANSCRICAO_GLOBAL, sec_in_buffered, sec_out_buffered)
    
    caminho_legenda_ass, caminho_legenda_srt = subtitles.gerar_legendas_para_corte(
        video_path, sec_in_buffered, sec_out_buffered, num_corte,
        nome_canal=nome_canal, transcricao_global=TRANSCRICAO_GLOBAL
    )

    # 2. Constrói filtros com fallback
    filter_complex_ass = smart_editor.construir_filtro_video_edicao(edl, target_w=1080, target_h=1920, legenda_path=caminho_legenda_ass, base_dir=DIR_ATUAL)
    filter_complex_srt = smart_editor.construir_filtro_video_edicao(edl, target_w=1080, target_h=1920, legenda_path=caminho_legenda_srt, base_dir=DIR_ATUAL)
    filter_complex_clean = smart_editor.construir_filtro_video_edicao(edl, target_w=1080, target_h=1920, legenda_path=None, base_dir=DIR_ATUAL)

    # Seeking com regeneração de timestamps PTS para 100% de sincronia áudio/vídeo e legendas:
    seek_args = [
        "-avoid_negative_ts", "make_zero",
        "-fflags", "+genpts+igndts",
        "-ss", f"{sec_in_buffered:.3f}",
        "-i", str(video_path),
        "-t", f"{duracao:.3f}"
    ]

    # Comandos de renderização com Constant Frame Rate (CFR 30fps), seeking preciso e mapeamento de áudio garantido
    cmds = [
        # Tentativa 1: Legenda ASS estilizada TikTok + Áudio Loudnorm 192k + CFR 30fps
        [
            "ffmpeg", "-y"
        ] + seek_args + [
            "-fps_mode", "cfr", "-r", "30",
            "-filter_complex", filter_complex_ass,
            "-map", "[v_final]",
            "-map", "[a_final]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
            "-movflags", "+faststart",
            str(saida_temp)
        ],
        # Tentativa 2: Legenda SRT fallback + Áudio Loudnorm 192k + CFR 30fps
        [
            "ffmpeg", "-y"
        ] + seek_args + [
            "-fps_mode", "cfr", "-r", "30",
            "-filter_complex", filter_complex_srt,
            "-map", "[v_final]",
            "-map", "[a_final]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
            "-movflags", "+faststart",
            str(saida_temp)
        ],
        # Tentativa 3: 9:16 Vertical Blur + Áudio Loudnorm (sem legenda caso libass falhe)
        [
            "ffmpeg", "-y"
        ] + seek_args + [
            "-fps_mode", "cfr", "-r", "30",
            "-filter_complex", filter_complex_clean,
            "-map", "[v_final]",
            "-map", "[a_final]",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "24",
            "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
            "-movflags", "+faststart",
            str(saida_temp)
        ]
    ]




    try:
        for tentativa, cmd_usar in enumerate(cmds, start=1):
            proc = None
            try:
                creation_flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
                proc = subprocess.Popen(cmd_usar, cwd=str(DIR_ATUAL), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, creationflags=creation_flags)
                _, stderr_bytes = proc.communicate(timeout=600)

                if proc.returncode != 0 and stderr_bytes:
                    err_preview = stderr_bytes.decode('utf-8', errors='replace').strip()
                    linhas_err = [l for l in err_preview.splitlines() if not l.startswith(' ') and 'configuration:' not in l and 'built with' not in l and 'libav' not in l]
                    log_debug(f"[FFmpeg stderr tentativa {tentativa}] {chr(10).join(linhas_err[-6:])}", "WARNING")

                if proc.returncode == 0 and saida_temp.exists() and saida_temp.stat().st_size > 50000:
                    if not validar_video_ffprobe(saida_temp):
                        saida_temp.unlink(missing_ok=True)
                        continue

                    saida_temp.replace(saida_mp4)

                    # Thumbnail
                    try:
                        thumb_path = DIR_SAIDA / f"{saida_mp4.stem}_thumb.jpg"
                        cmd_thumb = ["ffmpeg", "-y", "-ss", str(min(2.5, duracao / 2)), "-i", str(saida_mp4), "-vframes", "1", "-q:v", "2", str(thumb_path)]
                        subprocess.run(cmd_thumb, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15, creationflags=creation_flags)
                    except Exception:
                        pass

                    # Arquivo de metadados .txt
                    try:
                        info_txt_path = DIR_SAIDA / f"{saida_mp4.stem}_info.txt"
                        titulo_pub = str(corte_data.get('titulo_viral', titulo_limpo)).replace('_', ' ')
                        cat_pub = str(corte_data.get('categoria', 'VIRAL')).upper()
                        nota_pub = corte_data.get('pontuacao_viral', 8)
                        motivo_pub = corte_data.get('motivo', 'Momento de alto engajamento')

                        linhas_info = [
                            "=======================================================",
                            f"🎬 VIRAL CUTS PRO - INFORMAÇÕES DO CORTE #{num_corte:02d}",
                            "=======================================================",
                            f"📌 Arquivo: {saida_mp4.name}",
                            f"🔥 Título: {titulo_pub}",
                            f"⏱️ Minutagem: {formatar_tempo(sec_in_buffered)} -> {formatar_tempo(sec_out_buffered)} ({duracao:.1f}s)",
                            f"⭐ Pontuação: {nota_pub}/10 | Categoria: {cat_pub}",
                            f"🎯 Análise da IA: {motivo_pub}",
                            "======================================================="
                        ]
                        with open(info_txt_path, "w", encoding="utf-8") as f_info:
                            f_info.write("\n".join(linhas_info) + "\n")
                    except Exception:
                        pass

                    t_total_render = time.time() - t_inicio_render
                    log_debug(f"[PERFORMANCE] Renderização concluída em {t_total_render:.2f}s: {saida_mp4.name}")
                    return saida_mp4.name
                else:
                    saida_temp.unlink(missing_ok=True)
            except Exception as e_proc:
                log_debug(f"Exceção no FFmpeg para {saida_temp.name}: {e_proc}", "ERROR")
                if proc:
                    try: proc.kill()
                    except Exception: pass
                saida_temp.unlink(missing_ok=True)
    finally:
        if caminho_legenda_ass and Path(caminho_legenda_ass).exists():
            try: caminho_legenda_ass.unlink(missing_ok=True)
            except Exception: pass
        if caminho_legenda_srt and Path(caminho_legenda_srt).exists():
            try: caminho_legenda_srt.unlink(missing_ok=True)
            except Exception: pass


    return None


def analisar_pacote_e_renderizar_imediatamente(
    caminho_pacote_txt: Path,
    video_path: Path,
    url_lm: str,
    client_lm: Any,
    num_corte_global: int,
    historico: List[Dict[str, Any]],
    hash_proj: str,
    modelo_lm: str = "qwen3.5-9b.gguf",
    nota_minima: int = 6,
    nome_canal: Optional[str] = None
) -> tuple[List[str], int]:
    """Processa um pacote de texto com o ViralAnalyzer e renderiza cortes válidos imediatamente."""
    linhas_estruturadas = ler_pacote_estruturado(caminho_pacote_txt)
    if not linhas_estruturadas:
        return [], num_corte_global

    texto_transcricao = formatar_linhas_para_ia(linhas_estruturadas)
    analyzer = ViralAnalyzer(client_lm, modelo=modelo_lm)
    cortes_validados = analyzer.analisar_trecho(texto_transcricao, transcricao_linhas_pacote=linhas_estruturadas)

    cortes_gerados = []
    for corte in cortes_validados:
        if not isinstance(corte, dict):
            continue

        pontuacao = corte.get("pontuacao_viral", 7)
        if pontuacao < nota_minima:
            log_debug(f"Corte descartado por nota ({pontuacao} < {nota_minima}): {corte.get('titulo_viral')}")
            continue

        sec_in = float(corte.get("sec_in", tempo_para_segundos(corte.get("tempo_inicio", "00:00:00"))))
        sec_out = float(corte.get("sec_out", tempo_para_segundos(corte.get("tempo_fim", "00:00:30"))))

        if history_mgr.eh_corte_duplicado(sec_in, sec_out, historico):
            log_debug(f"Pulo de corte duplicado ({sec_in}s -> {sec_out}s) em {caminho_pacote_txt.name}")
            continue

        num_corte_global += 1
        titulo_corte = corte.get("titulo_viral", f"corte_{num_corte_global}")
        res = renderizar_corte_single(sec_in, sec_out, titulo_corte, video_path, num_corte_global, corte_dict=corte, nome_canal=nome_canal)

        if res:
            cortes_gerados.append(res)
            item_hist = {
                "id": num_corte_global,
                "arquivo": res,
                "sec_in": sec_in,
                "sec_out": sec_out,
                "duracao": round(sec_out - sec_in, 1),
                "titulo": titulo_corte,
                "headline": corte.get("headline_overlay", ""),
                "hook": corte.get("hook", ""),
                "pontuacao_viral": pontuacao,
                "categoria": corte.get("categoria", "VIRAL"),
                "motivo": corte.get("motivo", "Momento de alta retenção")
            }
            historico.append(item_hist)
            history_mgr.salvar_historico(historico, hash_proj)

            if HAS_RICH:
                rprint(f"   [bold green]✅ Corte #{num_corte_global:02d} gerado com sucesso![/bold green] ({res})")
            else:
                print(f"   ✅ Corte #{num_corte_global:02d} gerado com sucesso! ({res})")

    return cortes_gerados, num_corte_global


def executar_esteira_pipeline(
    video_path: Optional[Path] = None,
    backend: str = "LM Studio",
    modelo: str = "qwen3.5-9b.gguf",
    nota_minima: int = 6,
    url: str = "",
    api_key: str = "",
    nome_canal: Optional[str] = None,
    transcricao_path: Optional[Path] = None,
    forcar: bool = False,
    remover_silencios: bool = True,
    gerar_legendas: bool = True,
    estilo_legenda: str = "TikTok Bold Yellow",
    enquadramento_916: bool = True,
    zoom_rosto: bool = True,
    log_callback: Optional[Callable[[str], None]] = None,
    corte_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    cancel_check: Optional[Callable[[], bool]] = None
) -> tuple[bool, str, List[Dict[str, Any]]]:
    """
    Executa a esteira completa de cortes de forma modular (in-process ou CLI).
    Emite logs via log_callback e novos cortes via corte_callback.
    """
    def _emit_log(msg: str):
        if log_callback:
            log_callback(msg)
        print(msg)

    _emit_log("=== INICIANDO VIRAL CUTS PRO - MOTOR DE INTELIGÊNCIA ARTIFICIAL ===")

    if not verificar_espaco_em_disco():
        _emit_log("❌ Espaço em disco insuficiente para renderização.")
        return False, "Espaço em disco insuficiente.", []

    video_input = encontrar_video_na_pasta(str(video_path) if video_path else None)
    if not video_input:
        _emit_log("❌ Nenhum vídeo bruto válido encontrado. Selecione um arquivo na interface.")
        return False, "Vídeo não encontrado.", []

    hash_proj = gerar_hash_video(video_input)
    tamanho_gb = video_input.stat().st_size / (1024 ** 3)
    _emit_log(f"🎬 Vídeo Conectado: {video_input.name} ({tamanho_gb:.2f} GB) | Hash: {hash_proj}")

    if transcricao_path:
        txt_ext = Path(transcricao_path)
        if txt_ext.exists() and txt_ext.stat().st_size > 10:
            shutil.copy2(txt_ext, DIR_ESTADOS / f"transcricao_{hash_proj}.txt")
            _emit_log("📄 Transcrição externa vinculada com sucesso!")

    # Conexão unificada com BackendManager
    client_lm = None
    url_lm = None
    if backend:
        try:
            from backend_manager import BackendManager
            manager = BackendManager()
            if url or api_key:
                cfg_exist = manager.get_config_backend(backend)
                manager.set_config_backend(backend, {
                    "url": url or cfg_exist.get("url", ""),
                    "modelo": modelo or cfg_exist.get("modelo", ""),
                    "api_key": api_key or cfg_exist.get("api_key", "")
                })
            cliente_mb, erro_mb = manager.criar_cliente(backend)
            if erro_mb:
                _emit_log(f"❌ Falha ao conectar com motor de IA {backend}: {erro_mb}")
                return False, f"Falha ao conectar com {backend}: {erro_mb}", []
            client_lm = cliente_mb
            url_lm = manager.get_config_backend(backend).get("url", "")
            _emit_log(f"✓ Conectado ao motor de IA: {backend} ({modelo})")
        except Exception as e_mb:
            log_debug(f"Aviso BackendManager ({e_mb})", "WARNING")

    if client_lm is None and OpenAI:
        url_lm = url or "http://localhost:1234/v1"
        client_lm = OpenAI(base_url=url_lm, api_key="lm-studio", timeout=180.0)
        _emit_log("✓ Conectado ao servidor de IA local.")

    if cancel_check and cancel_check():
        return False, "Processamento cancelado pelo usuário.", []

    historico = history_mgr.carregar_historico(hash_proj, forcar)
    _emit_log("🎙️ Extraindo áudio e iniciando transcrição Whisper...")
    transcricao = gerenciar_transcricao_completa(video_input, hash_proj)
    if not transcricao:
        _emit_log("❌ Falha na transcrição do áudio.")
        return False, "Falha na transcrição do áudio.", []

    if cancel_check and cancel_check():
        return False, "Processamento cancelado pelo usuário.", []

    pacotes = fatiar_em_pacotes_txt(transcricao, hash_proj)
    _emit_log(f"✓ Transcrição dividida em {len(pacotes)} pacotes de 3min vinculados ao projeto.")

    num_corte_global = max([int(h.get("id", 0)) for h in historico], default=0)
    total_gerados = []

    for idx, pct in enumerate(pacotes, start=1):
        if cancel_check and cancel_check():
            _emit_log("⚠️ Processamento interrompido pelo usuário.")
            return False, "Interrompido.", total_gerados

        _emit_log(f"\n⚡ Analisando Pacote {idx:02d}/{len(pacotes):02d} ({pct.name}) com IA...")
        novos_cortes, num_corte_global = analisar_pacote_e_renderizar_imediatamente(
            pct, video_input, url_lm, client_lm, num_corte_global, historico, hash_proj,
            modelo_lm=modelo, nota_minima=nota_minima, nome_canal=nome_canal
        )
        for c in novos_cortes:
            total_gerados.append(c)
            caminho_corte_mp4 = DIR_SAIDA / c
            if corte_callback:
                corte_callback({
                    "titulo": Path(c).stem,
                    "caminho": str(caminho_corte_mp4),
                    "score": 85,
                    "duracao": 30.0
                })

    _emit_log(f"\n🎉 Esteira concluída! Total de {len(historico)} cortes virais prontos no painel.")
    return True, "Concluído com sucesso", historico


def main():
    parser = argparse.ArgumentParser(description="Motor Backend VIRAL CUTS PRO")
    parser.add_argument("video", nargs="?", help="Caminho do arquivo de vídeo bruto")
    parser.add_argument("--url", default="http://localhost:1234/v1", help="URL do servidor LM Studio")
    parser.add_argument("--backend", default=None, help="Backend de IA: ollama, lmstudio, groq, openrouter")
    parser.add_argument("--api-key", default=None, help="Chave de API para backends cloud")
    parser.add_argument("--modelo", default="qwen3.5-9b.gguf", help="Nome do modelo IA")
    parser.add_argument("--nota-minima", type=int, default=6, help="Nota mínima viral (1-10)")
    parser.add_argument("--force", action="store_true", help="Forçar re-corte limpando cache do projeto")
    parser.add_argument("--transcricao", help="Caminho para arquivo de transcrição .txt pré-existente")
    parser.add_argument("--canal", default=None, help="Nome do canal / Marca d'água superior opcional")

    args = parser.parse_args()

    sucesso, msg, _ = executar_esteira_pipeline(
        video_path=Path(args.video) if args.video else None,
        backend=args.backend or "LM Studio",
        modelo=args.modelo,
        nota_minima=args.nota_minima,
        url=args.url,
        api_key=args.api_key or "",
        nome_canal=args.canal,
        transcricao_path=Path(args.transcricao) if args.transcricao else None,
        forcar=args.force
    )

    if not sucesso:
        sys.exit(1)


if __name__ == "__main__":
    main()

