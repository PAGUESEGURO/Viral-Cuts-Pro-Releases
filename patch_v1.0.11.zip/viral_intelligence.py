"""
=============================================================================
VIRAL CUTS PRO - MOTOR DE INTELIGÊNCIA VIRAL MULTIDIMENSIONAL (5 Camadas)
=============================================================================
"""

import json
import re
import time
from utils import (
    detectar_emocao_fala,
    detectar_engajamento,
    detectar_tema,
    calcular_densidade_emocional,
    tempo_para_segundos,
    formatar_tempo,
    log_debug,
    estimar_tokens,
    truncar_transcript_inteligente,
    encontrar_inicio_frase,
    encontrar_fim_frase,
    encontrar_pausa_proxima,
    extrair_json_robusto,
)


from viral_prompts import ViralPrompts


class TranscriptPreprocessor:
    """Camada 1: Pré-processamento e extração de sinais vitais da fala."""

    def __init__(self):
        pass

    def analisar_linhas(self, transcricao_linhas):
        """
        Analisa todas as linhas da transcrição e retorna metadados estruturados.
        """
        if not transcricao_linhas:
            return {
                "total_falas": 0,
                "picos_emocionais": [],
                "tema_predominante": {"topico": "HIBRIDO", "subtopico": "geral", "confianca": 0.0},
                "resumo_ia": "Sem falas disponíveis.",
                "timestamps_validos": []
            }

        picos = calcular_densidade_emocional(transcricao_linhas)
        # Ordena por intensidade/score_energia decrescente para selecionar os momentos mais fortes da live
        picos_ordenados = sorted(picos, key=lambda x: x.get("score_energia", 0), reverse=True)
        
        amostra_texto = " ".join(item.get("texto", "") for item in transcricao_linhas[:100])
        tema = detectar_tema(amostra_texto)

        timestamps_validos = []
        for item in transcricao_linhas:
            t_fmt = item.get("tempo_formatado", "")
            match = re.search(r'(\d{1,2}:\d{2}(?::\d{2})?)', t_fmt)
            if match:
                timestamps_validos.append(match.group(1))

        resumo_picos = []
        for p in picos_ordenados[:5]:
            resumo_picos.append(f"[{p['tempo_formatado']}] {p['emocao']} (energia {p.get('score_energia', 0)}): {p['texto'][:50]}")

        picos_texto = "\n".join(resumo_picos) if resumo_picos else "Nenhum pico detectado"
        resumo_ia = (
            f"Tema: {tema['topico']} (confiança: {tema['confianca']})\n"
            f"Total de falas: {len(transcricao_linhas)}\n"
            f"Picos de maior energia: {len(picos)}\n"
            f"Top Momentos Explosivos:\n{picos_texto}"
        )

        return {
            "total_falas": len(transcricao_linhas),
            "picos_emocionais": picos_ordenados,
            "tema_predominante": tema,
            "resumo_ia": resumo_ia,
            "timestamps_validos": timestamps_validos
        }


class ViralScorer:
    """Camada 4: Scoring multidimensional ponderado com foco em retenção preditiva."""

    PESOS = {
        "forca_hook": 0.30,
        "intensidade_emocional": 0.25,
        "compartilhabilidade": 0.25,
        "potencial_debate": 0.20,
    }

    @classmethod
    def calcular_nota_final(cls, corte_dict, metadados=None):
        """Calcula score de 1 a 10 combinando scoring da IA e sweet spot de retenção."""
        sc = corte_dict.get("scoring", {})
        if isinstance(sc, dict) and sc:
            nota_calc = 0.0
            for chave, peso in cls.PESOS.items():
                val = sc.get(chave, 5)
                try:
                    val_num = float(val)
                except Exception:
                    val_num = 5.0
                val_num = max(1.0, min(10.0, val_num))
                nota_calc += val_num * peso
            
            nota_final = round(nota_calc, 1)
        else:
            raw_pont = corte_dict.get("pontuacao_viral", 5)
            try:
                nota_final = float(raw_pont)
            except Exception:
                nota_final = 5.0

        # Sweet Spot Bonus: Cortes entre 30s e 55s ganham bônus de retenção preditiva (+0.5)
        dur = corte_dict.get("duracao", 0)
        if 30.0 <= dur <= 55.0 and nota_final <= 9.5:
            nota_final += 0.5

        return max(1.0, min(10.0, round(nota_final, 1)))

    @classmethod
    def validar_scoring(cls, corte_dict, transcricao_linhas=None):
        """Valida se o scoring faz sentido com base nos dados reais."""
        sc = corte_dict.get("scoring", {})
        if not isinstance(sc, dict):
            return corte_dict

        titulo = corte_dict.get("titulo_viral", "")
        motivo = corte_dict.get("motivo", "")
        
        texto_completo = f"{titulo} {motivo}".lower()

        # Se intensidade é alta mas não há sinais de emoção no texto
        intensidade = sc.get("intensidade_emocional", 5)
        if isinstance(intensidade, (int, float)) and intensidade >= 8:
            sinais_emocao = ["!", "caralho", "porra", "droga", "não acredito", "mano", "kkkk"]
            if not any(s in texto_completo for s in sinais_emocao):
                sc["intensidade_emocional"] = max(5, intensidade - 2)
                corte_dict["scoring"] = sc

        # Se hook é alto mas não há frase de abertura
        hook_score = sc.get("forca_hook", 5)
        if isinstance(hook_score, (int, float)) and hook_score >= 8:
            hook = corte_dict.get("hook", "")
            if not hook or len(hook) < 10:
                sc["forca_hook"] = max(5, hook_score - 2)
                corte_dict["scoring"] = sc

        return corte_dict


class ViralValidator:
    """Camada 5: Validação de integridade, duração e sanitização."""

    MIN_DURACAO = 25.0
    MAX_DURACAO = 120.0    # Aumentado: raciocínios analíticos podem precisar de até 2 minutos
    SWEET_SPOT_MAX = 55.0  # Sweet spot para TikTok/Shorts (bônus de score)


    @classmethod
    def validar_e_refinar_cortes(cls, cortes_brutos, historico=None, transcricao_linhas=None):
        """
        Valida, corrige limites e remove sobreposições de cortes sugeridos,
        garantindo conclusão de raciocínio e preservação do contexto.
        """
        if not cortes_brutos:
            return []

        cortes_limpos = []
        for idx, c in enumerate(cortes_brutos, start=1):
            if not isinstance(c, dict):
                continue

            t_in_str = c.get("tempo_inicio", "00:00:00")
            t_out_str = c.get("tempo_fim", "00:00:30")

            s_in = tempo_para_segundos(t_in_str)
            s_out = tempo_para_segundos(t_out_str)

            # Validar timestamps
            if s_in < 0:
                s_in = 0.0
            if s_out <= s_in:
                continue

            # Snap de início e fim para frases completas (não cortar no meio de diálogo)
            if transcricao_linhas:
                s_in = encontrar_inicio_frase(transcricao_linhas, s_in)
                s_out = encontrar_fim_frase(transcricao_linhas, s_out, duracao_max=cls.MAX_DURACAO, sec_inicio=s_in)

            dur = s_out - s_in
            
            # Ajustar duração com margem inteligente
            if dur < cls.MIN_DURACAO:
                s_out = s_in + cls.MIN_DURACAO
                dur = cls.MIN_DURACAO
            elif dur > cls.MAX_DURACAO:
                s_out = s_in + cls.MAX_DURACAO
                dur = cls.MAX_DURACAO

            titulo = str(c.get("titulo_viral", "")).strip()
            if not titulo or len(titulo) < 3:
                titulo = f"Corte Destaque {idx:02d}"


            headline = str(c.get("headline_overlay", "")).strip()
            if not headline:
                headline = f"MOMENTO: {titulo.upper()[:50]}"

            nota = ViralScorer.calcular_nota_final(c)
            c = ViralScorer.validar_scoring(c, transcricao_linhas)

            hook = str(c.get("hook", "")).strip()
            if not hook or len(hook) < 5:
                hook = titulo[:60]

            cortes_limpos.append({
                "titulo_viral": titulo,
                "tempo_inicio": formatar_tempo(s_in),
                "tempo_fim": formatar_tempo(s_out),
                "sec_in": s_in,
                "sec_out": s_out,
                "duracao": dur,
                "hook": hook,
                "headline_overlay": headline,
                "pontuacao_viral": int(round(nota)),
                "categoria": str(c.get("categoria", "RESENHA")).upper(),
                "motivo": str(c.get("motivo", "Momento de alta retenção")),
                "plataforma": str(c.get("plataforma_ideal", "TikTok")),
                "edicao": c.get("edicao", {"remover_silencios": True, "zoom_punchline": True, "posicao_webcam": "top_left"})
            })


        # Remover sobreposições
        cortes_filtrados = []
        for corte in cortes_limpos:
            tem_sobreposicao = False
            for existente in cortes_filtrados:
                overlap_in = max(corte["sec_in"], existente["sec_in"])
                overlap_out = min(corte["sec_out"], existente["sec_out"])
                overlap_dur = max(0, overlap_out - overlap_in)
                dur_corte = corte["sec_out"] - corte["sec_in"]
                if dur_corte > 0 and (overlap_dur / dur_corte) > 0.3:
                    tem_sobreposicao = True
                    break
            if not tem_sobreposicao:
                cortes_filtrados.append(corte)

        return cortes_filtrados


class ViralAnalyzer:
    """Camada 2 & 3: Orquestrador da análise viral com IA e parsing seguro."""

    def __init__(self, client_lm, modelo="qwen3.5-9b.gguf"):
        self.client = client_lm
        self.modelo = modelo
        self.prompts = ViralPrompts()
        self.preprocessor = TranscriptPreprocessor()
        self.validator = ViralValidator()

    def analisar_trecho(self, texto_pacote, transcricao_linhas_pacote=None):
        """
        Executa a esteira de análise em 5 camadas.
        """
        metadados = self.preprocessor.analisar_linhas(transcricao_linhas_pacote or [])
        topico = metadados["tema_predominante"]["topico"]
        
        # Truncar transcript inteligentemente para caber no contexto
        texto_truncado = truncar_transcript_inteligente(texto_pacote, max_tokens=2200)
        
        tokens_texto = estimar_tokens(texto_truncado)
        tokens_system = estimar_tokens(self.prompts.get_system_prompt_master(topico))
        tokens_total_estimado = tokens_texto + tokens_system + 200  # margem para resposta
        
        log_debug(f"Tokens estimados: {tokens_total_estimado} (system: {tokens_system}, texto: {tokens_texto})", "INFO")

        # Se estimativa for muito alta, truncar mais
        if tokens_total_estimado > 5000:
            texto_truncado = truncar_transcript_inteligente(texto_pacote, max_tokens=1500)
            log_debug(f"Transcript truncado agressivamente para ~4500 tokens totais", "WARNING")

        prompt_completo = self.prompts.prompt_analise_completa(texto_truncado, metadados["resumo_ia"], topico)
        system_prompt = self.prompts.get_system_prompt_master(topico)

        conteudo = self._chamar_ia(system_prompt, prompt_completo)
        
        if not conteudo:
            log_debug("IA não retornou conteúdo. Tentando prompt simplificado...", "WARNING")
            prompt_simples = self.prompts.prompt_fallback_simples(texto_truncado)
            conteudo = self._chamar_ia(system_prompt, prompt_simples)

        cortes_brutos = self._extrair_json(conteudo)
        
        # Validar timestamps extraídos contra transcript real
        if transcricao_linhas_pacote and cortes_brutos:
            cortes_brutos = self._validar_timestamps_contra_transcript(cortes_brutos, transcricao_linhas_pacote)

        # Se a IA não retornou cortes válidos, tenta o fallback heurístico por energia real
        if not cortes_brutos and transcricao_linhas_pacote:
            cortes_brutos = self._gerar_fallback_heuristico_energia(transcricao_linhas_pacote, metadados)

        return self.validator.validar_e_refinar_cortes(cortes_brutos, transcricao_linhas=transcricao_linhas_pacote)

    def _gerar_fallback_heuristico_energia(self, transcricao_linhas, metadados=None):
        """
        Gera corte de fallback APENAS se houver pico de energia real comprovado.
        Rejeita trechos monótonos ou sem emoção para evitar falsos positivos (qualidade > quantidade).
        Gera títulos contextuais ricos de 4 a 7 palavras baseados no diálogo real.
        """
        if not transcricao_linhas or len(transcricao_linhas) < 2:
            return []

        maior_score = 0.0
        melhor_janela = None
        melhor_idx_i = 0
        melhor_idx_j = 0
        tem_emocao_forte = False

        for idx_i in range(len(transcricao_linhas)):
            texto_i = transcricao_linhas[idx_i].get("texto", "")
            emocao_i = detectar_emocao_fala(texto_i)
            engaj_i = detectar_engajamento(texto_i)

            if emocao_i["intensidade"] >= 6 or engaj_i["forca"] >= 6:
                tem_emocao_forte = True

            score_base = (emocao_i["intensidade"] * 0.6) + (engaj_i["forca"] * 0.4)

            for idx_j in range(idx_i + 1, min(idx_i + 30, len(transcricao_linhas))):
                sec_start_i = float(transcricao_linhas[idx_i].get("inicio", 0))
                sec_end_j = float(transcricao_linhas[idx_j].get("fim", 0))
                dur_tmp = sec_end_j - sec_start_i

                if 25.0 <= dur_tmp <= 70.0:
                    score_janela = score_base
                    for k in range(idx_i, idx_j + 1):
                        texto_k = transcricao_linhas[k].get("texto", "")
                        emocao_k = detectar_emocao_fala(texto_k)
                        score_janela += emocao_k["intensidade"] * 0.15
                        if emocao_k["intensidade"] >= 6:
                            tem_emocao_forte = True

                    txt_fim = str(transcricao_linhas[idx_j].get("texto", "")).strip()
                    if txt_fim.endswith(('.', '!', '?', '...')):
                        score_janela += 1.5

                    if score_janela > maior_score:
                        maior_score = score_janela
                        melhor_idx_i = idx_i
                        melhor_idx_j = idx_j
                        melhor_janela = (
                            formatar_tempo(sec_start_i),
                            formatar_tempo(sec_end_j)
                        )

        # Filtro rígido de qualidade: só gera corte se atingir score mínimo E tiver emoção/engajamento real
        LIMIAR_MINIMO_SCORE = 4.5
        if not melhor_janela or maior_score < LIMIAR_MINIMO_SCORE or not tem_emocao_forte:
            log_debug(f"Bloco sem energia viral suficiente (score {maior_score:.1f}, forte: {tem_emocao_forte}) - nenhum corte gerado.", "INFO")
            return []

        # Gerador de título contextual rico a partir das falas do clímax (4 a 7 palavras)
        palavras_contexto = []
        for k in range(melhor_idx_i, min(melhor_idx_j + 1, melhor_idx_i + 6)):
            txt_k = transcricao_linhas[k].get("texto", "")
            for w in txt_k.split():
                w_clean = re.sub(r'[^\w]', '', w)
                if len(w_clean) >= 2:
                    palavras_contexto.append(w_clean.upper())
                if len(palavras_contexto) >= 7:
                    break
            if len(palavras_contexto) >= 7:
                break

        if len(palavras_contexto) >= 3:
            titulo_contextual = "_".join(palavras_contexto[:6])
            headline_contextual = f"🔥 {' '.join(palavras_contexto[:6])}"
        else:
            emocao_topo = transcricao_linhas[melhor_idx_i].get("emocao", "MOMENTO")
            titulo_contextual = f"MOMENTO_{emocao_topo}_AO_VIVO"
            headline_contextual = f"🔥 MOMENTO {emocao_topo} AO VIVO"

        emocao_dominante = transcricao_linhas[melhor_idx_i].get("emocao", "VIRAL")
        return [{
            "titulo_viral": titulo_contextual,
            "headline_overlay": headline_contextual,
            "hook": transcricao_linhas[melhor_idx_i].get("texto", "")[:60],
            "tempo_inicio": melhor_janela[0],
            "pontuacao_viral": max(1, min(10, round(maior_score, 1))),
            "categoria": emocao_dominante if emocao_dominante in ("RAGE", "HILARIOUS", "HYPE") else "VIRAL",
            "motivo": f"Pico de energia ({emocao_dominante}) detectado automaticamente com conclusão de frase"
        }]


    def _chamar_ia(self, system_prompt, user_prompt, max_tentativas=2):
        """Chama a IA com timeout ágil (35s) e tratamento de erros. Rejeita reasoning_content sem JSON."""
        for tentativa in range(max_tentativas):
            try:
                log_debug(f"[FASE: ANALISE_IA] Chamando IA (tentativa {tentativa+1}/{max_tentativas})", "INFO")
                resp = self.client.chat.completions.create(
                    model=self.modelo,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=0.3,
                    max_tokens=500,
                    timeout=35
                )
                msg = resp.choices[0].message if resp and resp.choices else None
                if not msg:
                    log_debug("[FASE: ANALISE_IA] IA retornou resposta vazia", "WARNING")
                    continue

                # 1. Preferir content (resposta final estruturada)
                conteudo = (getattr(msg, 'content', '') or '').strip()

                # 2. Fallback para reasoning_content APENAS se contiver JSON real
                # (evita aceitar chain-of-thought interno como resposta)
                if not conteudo:
                    reasoning = (getattr(msg, 'reasoning_content', '') or '').strip()
                    if reasoning and ('{' in reasoning or '[' in reasoning):
                        log_debug(
                            "[FASE: ANALISE_IA] content vazio — usando reasoning_content pois contém JSON",
                            "WARNING"
                        )
                        conteudo = reasoning
                    else:
                        log_debug(
                            "[FASE: ANALISE_IA] content vazio e reasoning_content sem JSON — nenhum conteúdo validável",
                            "WARNING"
                        )

                if conteudo:
                    log_debug(f"[FASE: ANALISE_IA] IA retornou {len(conteudo)} caracteres", "INFO")
                    return conteudo

                log_debug("[FASE: ANALISE_IA] Conteúdo final vazio após verificações", "WARNING")

            except Exception as e_ia:
                log_debug(f"[FASE: ANALISE_IA] Erro na tentativa {tentativa+1}: {e_ia}", "WARNING")
                time.sleep(1.5 ** tentativa)
        
        return None


    def _validar_timestamps_contra_transcript(self, cortes, transcricao_linhas):
        """Valida se os timestamps dos cortes existem no transcript."""
        if not transcricao_linhas:
            return cortes

        timestamps_disponiveis = set()
        for item in transcricao_linhas:
            t_fmt = item.get("tempo_formatado", "")
            match = re.search(r'(\d{1,2}:\d{2}(?::\d{2})?)', t_fmt)
            if match:
                timestamps_disponiveis.add(match.group(1))

        cortes_validados = []
        for corte in cortes:
            t_in = corte.get("tempo_inicio", "")
            t_out = corte.get("tempo_fim", "")
            
            # Normalizar timestamps para comparação
            t_in_norm = self._normalizar_timestamp(t_in)
            t_out_norm = self._normalizar_timestamp(t_out)
            
            # Verificar se há falas suficientes no intervalo
            tem_falas = False
            for item in transcricao_linhas:
                s_in_item = item.get("inicio", 0)
                s_out_item = item.get("fim", 0)
                s_in_corte = tempo_para_segundos(t_in)
                s_out_corte = tempo_para_segundos(t_out)
                
                if s_in_item < s_out_corte and s_out_item > s_in_corte:
                    texto = item.get("texto", "").strip()
                    if texto and len(texto) > 5:
                        tem_falas = True
                        break
            
            if tem_falas:
                cortes_validados.append(corte)
            else:
                log_debug(f"Corte descartado: sem falas suficientes ({t_in} -> {t_out})", "WARNING")

        return cortes_validados

    def _normalizar_timestamp(self, ts):
        """Normaliza timestamp para formato HH:MM:SS."""
        if not ts:
            return "00:00:00"
        ts = ts.strip().replace("[", "").replace("]", "")
        partes = ts.split(":")
        if len(partes) == 2:
            return f"00:{partes[0].zfill(2)}:{partes[1].zfill(2)}"
        elif len(partes) == 3:
            return f"{partes[0].zfill(2)}:{partes[1].zfill(2)}:{partes[2].zfill(2)}"
        return ts

    def _extrair_json(self, texto_raw):
        """Parser multi-estratégia resistente a tags <think> e formatação Markdown."""
        if not texto_raw:
            return []

        texto_limpo = re.sub(r'<think>.*?</think>', '', str(texto_raw), flags=re.DOTALL).strip()
        itens = extrair_json_robusto(texto_limpo)
        return [d for d in itens if isinstance(d, dict) and self._validar_corte_basico(d)]


    def _validar_corte_basico(self, corte):
        """Validação básica de um corte extraído."""
        if not isinstance(corte, dict):
            return False
        
        titulo = corte.get("titulo_viral", "")
        t_in = corte.get("tempo_inicio", "")
        t_out = corte.get("tempo_fim", "")
        
        if not titulo or not t_in or not t_out:
            return False
        
        # Validar formato de timestamp
        if not re.match(r'\d{1,2}:\d{2}(:\d{2})?', str(t_in)):
            return False
        if not re.match(r'\d{1,2}:\d{2}(:\d{2})?', str(t_out)):
            return False
        
        # Validar duração básica
        s_in = tempo_para_segundos(t_in)
        s_out = tempo_para_segundos(t_out)
        dur = s_out - s_in
        if dur < 10 or dur > 120:
            return False
        
        return True
