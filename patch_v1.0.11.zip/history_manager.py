"""
=============================================================================
VIRAL CUTS PRO - GERENCIADOR ATÔMICO DE HISTÓRICO & RELATÓRIOS
Persistência Segura contra File-Locks do Windows, HTML Dashboard e Sync sem Spam
=============================================================================
"""

import os
import json
import time
import shutil
import html
from pathlib import Path
from typing import List, Dict, Any, Optional

from utils import log_debug, formatar_tempo

DIR_ATUAL = Path(__file__).parent.resolve()
DIR_ESTADOS_PADRAO = DIR_ATUAL / "projetos_estados"
DIR_SAIDA_PADRAO = DIR_ATUAL / "cortes_prontos"
ARQUIVO_HISTORICO_PADRAO = DIR_ATUAL / "historico_cortes.json"
ARQUIVO_RELATORIO_MD_PADRAO = DIR_ATUAL / "relatorio_cortes.md"
ARQUIVO_RELATORIO_HTML_PADRAO = DIR_ATUAL / "relatorio_cortes.html"


class HistoryManager:
    """Gerenciador central e isolado de persistência de estado e histórico de cortes."""

    def __init__(self, dir_estados: Optional[Path] = None, dir_saida: Optional[Path] = None):
        self.dir_estados = Path(dir_estados) if dir_estados else DIR_ESTADOS_PADRAO
        self.dir_saida = Path(dir_saida) if dir_saida else DIR_SAIDA_PADRAO
        self.dir_estados.mkdir(parents=True, exist_ok=True)
        self.dir_saida.mkdir(parents=True, exist_ok=True)
        self._ultimo_count_removidos = -1

    def _obter_caminho_historico(self, hash_proj: str = "global") -> Path:
        if hash_proj != "global":
            return self.dir_estados / f"historico_{hash_proj}.json"
        return ARQUIVO_HISTORICO_PADRAO

    def sincronizar_com_disco(self, historico: List[Dict[str, Any]], dir_saida: Optional[Path] = None) -> List[Dict[str, Any]]:
        """
        Filtra o histórico mantendo apenas os cortes cujos arquivos de vídeo ainda existem no disco.
        Suprime logs repetitivos idênticos para evitar poluição do log em pings de 5s.
        """
        if not historico or not isinstance(historico, list):
            return []

        alvo_dir = Path(dir_saida) if dir_saida else self.dir_saida
        historico_valido = []
        removidos = 0

        for item in historico:
            if not isinstance(item, dict):
                continue
            arq_nome = item.get("arquivo")
            if arq_nome:
                arq_path = alvo_dir / arq_nome
                try:
                    if arq_path.exists() and arq_path.stat().st_size >= 50_000:
                        historico_valido.append(item)
                    else:
                        if arq_path.exists() and arq_path.stat().st_size < 50_000:
                            arq_path.unlink(missing_ok=True)
                        removidos += 1
                except Exception:
                    removidos += 1
            else:
                removidos += 1

        if removidos > 0 and removidos != self._ultimo_count_removidos:
            self._ultimo_count_removidos = removidos
            log_debug(f"Sincronização com disco: {removidos} corte(s) sem arquivo válido no disco removidos do histórico.")
        elif removidos == 0 and self._ultimo_count_removidos != 0:
            self._ultimo_count_removidos = 0

        return historico_valido

    def carregar_historico(self, hash_proj: str = "global", forcar_recorte: bool = False) -> List[Dict[str, Any]]:
        """Carrega o histórico com suporte a re-corte forçado e sincronização com o disco."""
        arq_hist = self._obter_caminho_historico(hash_proj)

        if forcar_recorte and arq_hist.exists():
            try:
                backup_path = arq_hist.parent / f"{arq_hist.stem}_backup.json"
                shutil.copy2(arq_hist, backup_path)
                arq_hist.unlink(missing_ok=True)
                log_debug(f"Histórico resetado para re-corte forçado em {hash_proj}")
                return []
            except Exception as e_backup:
                log_debug(f"Erro ao criar backup do histórico ({e_backup})", "WARNING")

        if arq_hist.exists():
            try:
                with open(arq_hist, "r", encoding="utf-8") as f:
                    dados = json.load(f)
                    if isinstance(dados, list):
                        dados_sinc = self.sincronizar_com_disco(dados)
                        if len(dados_sinc) != len(dados):
                            self.salvar_historico(dados_sinc, hash_proj)
                        return dados_sinc
            except Exception as e:
                log_debug(f"Histórico corrompido em {arq_hist.name} ({e}), iniciando vazio", "ERROR")

        return []

    def salvar_historico(self, historico: List[Dict[str, Any]], hash_proj: str = "global"):
        """Salva o histórico de forma atômica garantindo atomicidade e ausência de file-locks."""
        def _salvar_atomico(caminho_final: Path, dados: Any):
            tmp_path = caminho_final.parent / f"{caminho_final.name}.tmp"
            try:
                caminho_final.parent.mkdir(parents=True, exist_ok=True)
                with open(tmp_path, "w", encoding="utf-8") as f_tmp:
                    json.dump(dados, f_tmp, indent=2, ensure_ascii=False)
                    f_tmp.flush()
                    os.fsync(f_tmp.fileno())
                try:
                    tmp_path.replace(caminho_final)
                except (PermissionError, OSError):
                    time.sleep(0.05)
                    shutil.copy2(tmp_path, caminho_final)
                    tmp_path.unlink(missing_ok=True)
            except Exception as e_write:
                try:
                    with open(caminho_final, "w", encoding="utf-8") as f_dir:
                        json.dump(dados, f_dir, indent=2, ensure_ascii=False)
                except Exception as e_dir:
                    log_debug(f"Erro fatal ao salvar {caminho_final.name}: {e_dir}", "ERROR")
                if tmp_path.exists():
                    tmp_path.unlink(missing_ok=True)

        _salvar_atomico(ARQUIVO_HISTORICO_PADRAO, historico)
        if hash_proj != "global":
            _salvar_atomico(self.dir_estados / f"historico_{hash_proj}.json", historico)

        self.gerar_relatorios(historico)

    def eh_corte_duplicado(self, sec_in: float, sec_out: float, historico: List[Dict[str, Any]], limite_overlap: float = 0.3) -> bool:
        """Verifica se o intervalo proposto já tem sobreposição significativa no histórico."""
        duracao_nova = sec_out - sec_in
        if duracao_nova <= 0:
            return True

        for h in historico:
            h_in = float(h.get("sec_in", 0))
            h_out = float(h.get("sec_out", 0))
            overlap_in = max(sec_in, h_in)
            overlap_out = min(sec_out, h_out)
            overlap_dur = max(0.0, overlap_out - overlap_in)

            if (overlap_dur / duracao_nova) >= limite_overlap:
                return True

        return False

    def gerar_relatorios(self, historico: List[Dict[str, Any]], arq_md: Optional[Path] = None, arq_html: Optional[Path] = None):
        """Gera relatórios HTML e Markdown profissionais e sanitizados contra XSS."""
        if arq_md is None:
            arq_md = ARQUIVO_RELATORIO_MD_PADRAO
        if arq_html is None:
            arq_html = ARQUIVO_RELATORIO_HTML_PADRAO

        linhas_md = [
            "# 📊 Relatório Geral de Cortes Gerados - VIRAL CUTS PRO",
            "",
            f"**Data da última atualização:** {time.strftime('%d/%m/%Y %H:%M:%S')}",
            f"**Total de Vídeos Virais Gerados:** {len(historico)} cortes",
            "",
            "| ID | Arquivo de Vídeo | Minutagem | Duração | Nota Viral | Categoria | Título Viral | Motivo da IA |",
            "|---|---|---|---|---|---|---|---|"
        ]

        cards_html = []
        for item in historico:
            num = int(item.get("id", 1))
            nome = str(item.get("arquivo", "video.mp4"))
            titulo = str(item.get("headline") or item.get("titulo", "Destaque")).replace("_", " ")
            nota = item.get("pontuacao_viral", 8)
            categoria = str(item.get("categoria", "VIRAL")).upper()
            motivo = str(item.get("motivo", "Momento de alto engajamento"))
            dur_str = f"{int(item.get('duracao', 0))}s"
            t_in_str = formatar_tempo(float(item.get("sec_in", 0)))
            t_out_str = formatar_tempo(float(item.get("sec_out", 0)))

            linhas_md.append(f"| {num:02d} | `{nome}` | `{t_in_str} -> {t_out_str}` | {dur_str} | ⭐ {nota}/10 | `{categoria}` | 🔥 {titulo} | {motivo} |")

            badge_color = "#e53e3e" if int(nota) >= 9 else "#dd6b20" if int(nota) >= 7 else "#3182ce"
            path_rel = f"cortes_prontos/{html.escape(nome)}"

            card = f"""
            <div class="card">
                <div class="card-header">
                    <span class="badge-num">#{num:02d}</span>
                    <span class="badge-cat">{html.escape(categoria)}</span>
                    <span class="badge-score" style="background-color: {badge_color};">⭐ {nota}/10</span>
                </div>
                <h3 class="card-title">🔥 {html.escape(titulo)}</h3>
                <p class="card-meta">⏱️ {t_in_str} ➔ {t_out_str} ({dur_str})</p>
                <p class="card-motivo">"{html.escape(motivo)}"</p>
                <video controls width="100%" style="border-radius: 8px; margin-top: 10px;" preload="metadata">
                    <source src="{path_rel}" type="video/mp4">
                </video>
                <a href="{path_rel}" download class="btn-download">💾 Baixar Vídeo MP4 com Legendas</a>
            </div>
            """
            cards_html.append(card)

        if not cards_html:
            cards_html.append("""
            <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 40px 20px;">
                <div style="font-size: 3.5rem; margin-bottom: 15px;">🎬 ⚡</div>
                <h2 style="color: #38bdf8; margin-bottom: 10px;">Nenhum corte gerado ainda</h2>
                <p style="color: #94a3b8;">Inicie a esteira para processar os melhores momentos da sua live!</p>
            </div>
            """)

        html_full = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎬 VIRAL CUTS PRO - Dashboard de Cortes</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0b0f19; color: #f8fafc; margin: 0; padding: 20px; }}
        .header {{ text-align: center; padding: 20px; background: linear-gradient(135deg, #151c2c 0%, #0b0f19 100%); border-bottom: 2px solid #38bdf8; margin-bottom: 30px; border-radius: 12px; }}
        .header h1 {{ margin: 0; font-size: 2.2rem; color: #38bdf8; }}
        .header p {{ color: #94a3b8; margin-top: 8px; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 25px; max-width: 1400px; margin: 0 auto; }}
        .card {{ background: #151c2c; border: 1px solid #2a364f; border-radius: 12px; padding: 16px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); display: flex; flex-direction: column; justify-content: space-between; }}
        .card-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }}
        .badge-num {{ background: #334155; padding: 3px 8px; border-radius: 6px; font-weight: bold; font-size: 0.85rem; }}
        .badge-cat {{ background: #0284c7; padding: 3px 8px; border-radius: 6px; font-size: 0.8rem; font-weight: bold; }}
        .badge-score {{ padding: 3px 8px; border-radius: 6px; font-weight: bold; font-size: 0.85rem; color: #fff; }}
        .card-title {{ margin: 6px 0; font-size: 1.1rem; color: #f1f5f9; }}
        .card-meta {{ color: #94a3b8; font-size: 0.85rem; margin: 2px 0; }}
        .card-motivo {{ color: #cbd5e1; font-size: 0.85rem; font-style: italic; background: #0b0f19; padding: 8px; border-radius: 6px; margin: 8px 0; }}
        .btn-download {{ display: block; text-align: center; background: #2563eb; color: white; text-decoration: none; padding: 10px; border-radius: 6px; margin-top: 10px; font-weight: bold; }}
        .btn-download:hover {{ background: #1d4ed8; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>⚡ VIRAL CUTS PRO - Dashboard de Cortes</h1>
        <p>Total de Cortes Prontos: <strong>{len(historico)}</strong> | Atualizado em: {time.strftime('%d/%m/%Y %H:%M:%S')}</p>
    </div>
    <div class="grid">
        {"".join(cards_html)}
    </div>
</body>
</html>
"""
        try:
            with open(arq_md, "w", encoding="utf-8") as f_md:
                f_md.write("\n".join(linhas_md) + "\n")
            with open(arq_html, "w", encoding="utf-8") as f_html:
                f_html.write(html_full)
        except Exception as e:
            log_debug(f"Erro ao salvar relatórios ({e})", "WARNING")
