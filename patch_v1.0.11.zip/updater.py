"""
=============================================================================
VIRAL CUTS PRO - MÓDULO DE AUTO-ATUALIZAÇÃO (HOT-PATCH)
Verifica versão no GitHub Releases e aplica patches sem reinstalação.
=============================================================================
"""

import os
import sys
import json
import shutil
import zipfile
import threading
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, Callable, Dict, Any, Tuple

# ─── Constantes ───────────────────────────────────────────────────────────────

APP_VERSION = "1.0.0"
APP_BUILD   = 1

# URL pública do version.json no repositório de distribuição (Releases público)
VERSION_JSON_URL = "https://raw.githubusercontent.com/PAGUESEGURO/Viral-Cuts-Pro-Releases/main/version.json"

# Arquivos que NUNCA devem ser sobrescritos por um patch (dados do usuário)
ARQUIVOS_PROTEGIDOS = {
    "historico_cortes.json",
    "config_backends.json",
    "transcricao_completa.txt",
    "esteira_debug.log",
    "relatorio_cortes.md",
    "relatorio_cortes.html",
    "version.local",
}

# Diretório raiz onde o app está instalado / rodando
if getattr(sys, 'frozen', False):
    DIR_APP = Path(sys.executable).parent  # instalação PyInstaller
else:
    DIR_APP = Path(__file__).parent.resolve()  # desenvolvimento direto

ARQUIVO_VERSION_LOCAL = DIR_APP / "version.local"


# ─── Utilitários ──────────────────────────────────────────────────────────────

def _ler_versao_local() -> Dict[str, Any]:
    """Lê a versão instalada localmente."""
    if ARQUIVO_VERSION_LOCAL.exists():
        try:
            return json.loads(ARQUIVO_VERSION_LOCAL.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"version": APP_VERSION, "build": APP_BUILD}


def _salvar_versao_local(dados: Dict[str, Any]) -> None:
    """Persiste a versão aplicada no disco."""
    try:
        ARQUIVO_VERSION_LOCAL.write_text(
            json.dumps(dados, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    except Exception:
        pass


def _versao_para_tupla(v: str):
    """Converte '1.2.3' em (1, 2, 3) para comparação."""
    try:
        return tuple(int(x) for x in str(v).split("."))
    except Exception:
        return (0, 0, 0)


# ─── Verificação de versão ────────────────────────────────────────────────────

def checar_atualizacao(timeout: int = 5) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    Busca o version.json remoto do GitHub Releases.
    Retorna (tem_nova_versao, dados_remoto, mensagem_status).
    """
    try:
        import urllib.request
        req = urllib.request.Request(
            VERSION_JSON_URL,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            dados_remoto = json.loads(resp.read().decode("utf-8"))

        versao_local = _ler_versao_local()
        v_local  = _versao_para_tupla(versao_local.get("version", APP_VERSION))
        v_remota = _versao_para_tupla(dados_remoto.get("version", APP_VERSION))

        if v_remota > v_local:
            return True, dados_remoto, f"Nova versão v{dados_remoto.get('version')} disponível!"
        else:
            return False, dados_remoto, f"Você já está na versão mais recente (v{versao_local.get('version', APP_VERSION)})."

    except Exception as e:
        err_str = str(e)
        if "404" in err_str:
            return False, None, (
                "Servidor de atualizações inacessível ou repositório de releases não encontrado.\n"
                "Verifique sua conexão com a internet e tente novamente."
            )
        return False, None, f"Não foi possível conectar ao servidor de atualizações: {err_str}"


def verificar_versao_remota(timeout: int = 5) -> Optional[Dict[str, Any]]:
    """Função legada para compatibilidade."""
    tem_update, dados, _ = checar_atualizacao(timeout)
    return dados if tem_update else None


# ─── Download e aplicação do patch ───────────────────────────────────────────

def _baixar_arquivo(url: str, destino: Path, progresso_cb: Optional[Callable[[int], None]] = None) -> bool:
    """Baixa um arquivo com progresso opcional."""
    try:
        import urllib.request

        def _report(block_num, block_size, total_size):
            if progresso_cb and total_size > 0:
                pct = min(100, int(block_num * block_size * 100 / total_size))
                progresso_cb(pct)

        req = urllib.request.Request(
            url,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        )
        with urllib.request.urlopen(req) as resp, open(destino, 'wb') as out_f:
            total_size = int(resp.headers.get('content-length', 0))
            downloaded = 0
            block_size = 8192
            while True:
                chunk = resp.read(block_size)
                if not chunk:
                    break
                out_f.write(chunk)
                downloaded += len(chunk)
                if progresso_cb and total_size > 0:
                    progresso_cb(min(100, int(downloaded * 100 / total_size)))

        return True
    except Exception as e:
        print(f"[Updater] Falha no download: {e}")
        return False


def aplicar_patch(dados_remoto: Dict[str, Any],
                  progresso_cb: Optional[Callable[[int], None]] = None,
                  log_cb: Optional[Callable[[str], None]] = None) -> bool:
    """
    Baixa e aplica o patch zip sobre a pasta de instalação.
    Arquivos protegidos (dados do usuário) são preservados.
    Retorna True se o patch foi aplicado com sucesso.
    """
    url_patch = dados_remoto.get("url_patch", "")

    def _log(msg: str):
        print(f"[Updater] {msg}")
        if log_cb:
            log_cb(msg)

    versao = dados_remoto.get("version", "")
    urls_para_tentar = []

    if url_patch:
        urls_para_tentar.append(url_patch)

    if versao:
        urls_para_tentar.append(f"https://raw.githubusercontent.com/PAGUESEGURO/Viral-Cuts-Pro-Releases/main/patch_v{versao}.zip")
        urls_para_tentar.append(f"https://github.com/PAGUESEGURO/Viral-Cuts-Pro-Releases/releases/download/v{versao}/patch_v{versao}.zip")

    # Remover duplicatas mantendo ordem
    urls_unicas = list(dict.fromkeys(urls_para_tentar))

    if not urls_unicas:
        _log("Erro: nenhuma URL de patch válida.")
        return False

    _log(f"Iniciando download do patch v{versao}...")

    tmp_dir = Path(tempfile.mkdtemp(prefix="vcp_patch_"))
    patch_zip = tmp_dir / "patch.zip"

    try:
        # 1. Download do patch tentando as URLs em sequência
        ok = False
        for url_tentativa in urls_unicas:
            _log(f"Baixando: {url_tentativa[:50]}...")
            ok = _baixar_arquivo(url_tentativa, patch_zip, progresso_cb)
            if ok and patch_zip.exists() and patch_zip.stat().st_size > 1024:
                break
            ok = False

        if not ok or not patch_zip.exists():
            _log("Falha ao baixar patch de todas as fontes disponíveis.")
            return False

        _log("Patch baixado com sucesso. Aplicando arquivos...")

        # 2. Extrair patch em pasta temporária e comparar
        extrai_dir = tmp_dir / "extracted"
        extrai_dir.mkdir()
        with zipfile.ZipFile(patch_zip, "r") as zf:
            zf.extractall(extrai_dir)

        # Se for archive do GitHub, desenvelopa a pasta raiz (ex: Viral-Cuts-Pro-main/)
        subdirs = list(extrai_dir.iterdir())
        if len(subdirs) == 1 and subdirs[0].is_dir() and "Viral-Cuts-Pro" in subdirs[0].name:
            root_src = subdirs[0]
        else:
            root_src = extrai_dir

        # 3. Copiar arquivos para o DIR_APP respeitando proteções
        arquivos_aplicados = 0
        for src in root_src.rglob("*"):
            if src.is_file():
                rel = src.relative_to(root_src)
                nome_arquivo = rel.name

                # Pular arquivos protegidos (dados do usuário)
                if nome_arquivo in ARQUIVOS_PROTEGIDOS:
                    _log(f"  Preservado (protegido): {rel}")
                    continue

                dest = DIR_APP / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)
                arquivos_aplicados += 1
                _log(f"  Atualizado: {rel}")

        # 4. Salvar nova versão local
        _salvar_versao_local(dados_remoto)
        _log(f"Patch v{dados_remoto.get('version')} aplicado! ({arquivos_aplicados} arquivos)")

        if progresso_cb:
            progresso_cb(100)

        return True

    except Exception as e:
        _log(f"Erro ao aplicar patch: {e}")
        return False

    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def reiniciar_app(root=None) -> None:
    """Reinicia o processo atual para carregar os novos arquivos e fecha o processo anterior."""
    try:
        if root is not None:
            try:
                root.after(500, _exec_restart)
            except Exception:
                _exec_restart()
            try:
                root.destroy()
            except Exception:
                pass
        else:
            _exec_restart()
    except Exception as e:
        print(f"[Updater] Falha ao reiniciar: {e}")
        os._exit(1)

def _exec_restart() -> None:
    """Executa o reinício do processo."""
    try:
        if getattr(sys, 'frozen', False):
            subprocess.Popen([sys.executable], cwd=str(Path(sys.executable).parent.resolve()))
        else:
            main_script = DIR_APP / "app_gui_v2.py"
            if not main_script.exists():
                main_script = DIR_APP / "app_gui.py"
            subprocess.Popen([sys.executable, str(main_script)], cwd=str(DIR_APP))
        sys.exit(0)
    except Exception as e:
        print(f"[Updater] Falha ao reiniciar: {e}")
        os._exit(1)


# ─── Interface pública: verificação em background ────────────────────────────

class AutoUpdater:
    """
    Classe principal de gerenciamento de atualizações.
    Executa verificação em background para não travar a GUI.
    """

    def __init__(self,
                 on_update_disponivel: Optional[Callable[[Dict[str, Any]], None]] = None,
                 on_patch_aplicado: Optional[Callable[[bool], None]] = None):
        self.on_update_disponivel = on_update_disponivel
        self.on_patch_aplicado = on_patch_aplicado
        self._dados_remoto: Optional[Dict[str, Any]] = None

    def verificar_em_background(self, root=None, callback=None) -> None:
        """
        Dispara a verificação de versão em uma thread daemon.
        Usa root.after() para chamar o callback na thread do Tkinter.
        """
        def _worker():
            tem_update, dados, msg = checar_atualizacao(timeout=6)
            self._dados_remoto = dados if tem_update else None

            cb = callback or self.on_update_disponivel
            if cb:
                if root:
                    try:
                        import inspect
                        sig = inspect.signature(cb)
                        if len(sig.parameters) >= 3:
                            root.after(0, lambda t=tem_update, d=dados, m=msg: cb(t, d, m))
                        else:
                            root.after(0, lambda d=(dados if tem_update else None): cb(d))
                    except Exception:
                        root.after(0, lambda d=(dados if tem_update else None): cb(d))
                else:
                    try:
                        cb(tem_update, dados, msg)
                    except TypeError:
                        cb(dados if tem_update else None)

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    def aplicar_update(self,
                       progresso_cb: Optional[Callable[[int], None]] = None,
                       log_cb: Optional[Callable[[str], None]] = None,
                       root=None) -> None:
        """Aplica o patch disponível em background e reinicia o app."""
        if not self._dados_remoto:
            return

        dados = self._dados_remoto

        def _worker():
            sucesso = aplicar_patch(dados, progresso_cb, log_cb)
            if self.on_patch_aplicado:
                if root:
                    root.after(0, lambda: self.on_patch_aplicado(sucesso))
                else:
                    self.on_patch_aplicado(sucesso)
            if sucesso:
                # Aguarda 1.2s para o usuário ver o feedback antes de reiniciar
                import time; time.sleep(1.2)
                if root:
                    root.after(0, lambda: reiniciar_app(root=root))
                else:
                    reiniciar_app()

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    @staticmethod
    def versao_local() -> str:
        """Retorna a versão atualmente instalada."""
        return _ler_versao_local().get("version", APP_VERSION)


# ─── CLI de diagnóstico ───────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"Versão local : {AutoUpdater.versao_local()}")
    print(f"Verificando versão remota em {VERSION_JSON_URL}...")
    dados = verificar_versao_remota()
    if dados:
        print(f"Nova versão disponível: {dados['version']}")
        print(f"Notas: {dados.get('notas', '')}")
        resp = input("Aplicar patch agora? (s/N): ").strip().lower()
        if resp == "s":
            sucesso = aplicar_patch(dados, log_cb=print)
            if sucesso:
                print("Patch aplicado! Reiniciando...")
                reiniciar_app()
    else:
        print("Nenhuma atualização disponível. App está na versão mais recente.")
