import os
import sys
import json
import shutil
import threading
import subprocess
import time
import webbrowser
import multiprocessing
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from utils import SafeStreamWrapper, setup_safe_streams
from pipeline_controller import PipelineController, PipelineConfig, EstadoPipeline

setup_safe_streams()

if getattr(sys, 'frozen', False):
    multiprocessing.freeze_support()


try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

DIR_ATUAL = Path(__file__).parent.resolve()
DIR_SAIDA = DIR_ATUAL / "cortes_prontos"
ARQUIVO_HISTORICO = DIR_ATUAL / "historico_cortes.json"
ARQUIVO_HTML = DIR_ATUAL / "relatorio_cortes.html"
ARQUIVO_LOG = DIR_ATUAL / "esteira_debug.log"
SCRIPT_ESTEIRA = DIR_ATUAL / "esteira.py"
LOGO_PATH = DIR_ATUAL / "app_logo.png"

class ViralCutsProGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("⚡ VIRAL CUTS PRO - Gerador Automático de Cortes da Live")
        self.root.geometry("1140x780")
        self.root.minsize(980, 680)
        self.root.configure(bg="#0b0f19")

        self.processo_esteira = None
        self.rodando_event = threading.Event()
        self.caminho_video_selecionado = None
        self.logo_img_tk = None
        self.last_log_pos = 0

        # Controlador do Pipeline Desacoplado
        self.controller = PipelineController(script_esteira=SCRIPT_ESTEIRA)
        self.controller.registrar_callback("on_log", lambda l: self.root.after(0, self.append_log_realtime, l))
        self.controller.registrar_callback("on_status_change", lambda st, msg: self.root.after(0, self._on_pipeline_status, st, msg))
        self.controller.registrar_callback("on_finalizado", lambda code, msg: self.root.after(0, self.finalizar_execucao, code, msg))

        # Variáveis de Configuração
        self.lm_url = tk.StringVar(value="http://localhost:1234/v1")
        self.modelo = tk.StringVar(value="qwen3.5-9b.gguf")
        self.nota_minima = tk.IntVar(value=6)
        self.usar_transcricao_existente = tk.BooleanVar(value=False)
        self.caminho_transcricao = tk.StringVar(value="")
        self.remover_silencios = tk.BooleanVar(value=True)
        self.posicao_webcam = tk.StringVar(value="Topo-Esquerdo (Padrão)")
        self.nome_canal = tk.StringVar(value="")

        # Blindagem #1: BackendManager Singleton
        try:
            from backend_manager import BackendManager
            self.backend_manager = BackendManager()
            preferido = self.backend_manager.get_backend_preferido()
        except Exception:
            self.backend_manager = None
            preferido = "LM Studio"

        self.backend_selecionado = tk.StringVar(value=preferido)
        self.backend_url = tk.StringVar(value="")
        self.modelo_selecionado = tk.StringVar(value="")
        self.api_key_cloud = tk.StringVar(value="")
        self._api_key_visivel = False
        self._carregar_config_backend_atual()

        self.setup_styles()


        self.build_ui()
        self.atualizar_estatisticas()
        self.carregar_historico_tabela()
        self.monitorar_logs_arquivo()

        # Blindagem #6: Verificar se precisa abrir onboarding no primeiro uso
        self.root.after(600, self._check_onboarding_startup)


    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        
        BG_DARK = "#0b0f19"
        CARD_BG = "#151c2c"
        BORDER_CLR = "#2a364f"
        FG_WHITE = "#ffffff"
        CYAN_ACCENT = "#38bdf8"
        
        style.configure(".", background=BG_DARK, foreground=FG_WHITE, font=("Segoe UI", 10))
        style.configure("TFrame", background=BG_DARK)
        style.configure("Card.TFrame", background=CARD_BG, relief="flat")
        
        style.configure("TLabelframe", background=CARD_BG, foreground=CYAN_ACCENT, font=("Segoe UI", 11, "bold"), bordercolor=BORDER_CLR)
        style.configure("TLabelframe.Label", background=CARD_BG, foreground=CYAN_ACCENT)

        style.configure("TEntry", fieldbackground="#0b0f19", foreground="#ffffff", insertcolor="#ffffff", bordercolor=BORDER_CLR, padding=6)
        style.configure("TSpinbox", fieldbackground="#0b0f19", foreground="#ffffff", arrowcolor=CYAN_ACCENT, bordercolor=BORDER_CLR, padding=6)

        style.configure("TButton", font=("Segoe UI", 10, "bold"), background="#2563eb", foreground="#ffffff", borderwidth=0, padding=10)
        style.map("TButton", background=[("active", "#1d4ed8"), ("disabled", "#334155")])

        style.configure("Primary.TButton", font=("Segoe UI", 11, "bold"), background="#0284c7", foreground="#ffffff", borderwidth=0, padding=12)
        style.map("Primary.TButton", background=[("active", "#0369a1"), ("disabled", "#334155")])

        style.configure("Select.TButton", font=("Segoe UI", 10, "bold"), background="#0d9488", foreground="#ffffff", borderwidth=0, padding=10)
        style.map("Select.TButton", background=[("active", "#0f766e")])

        style.configure("Reset.TButton", font=("Segoe UI", 9, "bold"), background="#d97706", foreground="#ffffff", borderwidth=0, padding=8)
        style.map("Reset.TButton", background=[("active", "#b45309"), ("disabled", "#334155")])

        style.configure("Stop.TButton", font=("Segoe UI", 10, "bold"), background="#dc2626", foreground="#ffffff", borderwidth=0, padding=10)
        style.map("Stop.TButton", background=[("active", "#b91c1c"), ("disabled", "#334155")])

        style.configure("Web.TButton", font=("Segoe UI", 9, "bold"), background="#4f46e5", foreground="#ffffff", borderwidth=0, padding=8)
        style.map("Web.TButton", background=[("active", "#4338ca")])

        style.configure("Treeview", background=CARD_BG, foreground="#f8fafc", fieldbackground=CARD_BG, rowheight=32, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", background="#1e293b", foreground=CYAN_ACCENT, font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#0284c7")], foreground=[("selected", "#ffffff")])

        style.configure("TProgressbar", thickness=18, troughcolor="#151c2c", background=CYAN_ACCENT)

    def build_ui(self):
        # 1. Header Principal
        header_frame = tk.Frame(self.root, bg="#151c2c", height=75)
        header_frame.pack(fill="x", side="top", padx=15, pady=(15, 10))

        if HAS_PIL and LOGO_PATH.exists():
            try:
                img = Image.open(LOGO_PATH)
                img = img.resize((50, 50), Image.Resampling.LANCZOS)
                self.logo_img_tk = ImageTk.PhotoImage(img)
                lbl_logo = tk.Label(header_frame, image=self.logo_img_tk, bg="#151c2c")
                lbl_logo.pack(side="left", padx=(15, 10), pady=10)
            except Exception as e_logo:
                print(f"[DEBUG] Logotipo do cabeçalho não carregado: {e_logo}")


        title_container = tk.Frame(header_frame, bg="#151c2c")
        title_container.pack(side="left", fill="y", pady=10)

        lbl_titulo = tk.Label(title_container, text="⚡ VIRAL CUTS PRO", font=("Segoe UI", 16, "bold"), bg="#151c2c", fg="#38bdf8")
        lbl_titulo.pack(anchor="w")

        lbl_sub = tk.Label(title_container, text="Software Profissional de Cortes Virais com IA & Legendas Automáticas", font=("Segoe UI", 9), bg="#151c2c", fg="#94a3b8")
        lbl_sub.pack(anchor="w")

        self.lbl_status_badge = tk.Label(header_frame, text="● PARADO", font=("Segoe UI", 11, "bold"), bg="#151c2c", fg="#ef4444")
        self.lbl_status_badge.pack(side="right", padx=20, pady=12)

        # 2. Split Main Layout
        main_paned = ttk.PanedWindow(self.root, orient="horizontal")
        main_paned.pack(fill="both", expand=True, padx=15, pady=10)

        # Lado Esquerdo: Controles & Painel de Configurações com Canvas Rolável
        left_container = ttk.Frame(main_paned, width=380)
        main_paned.add(left_container, weight=1)

        self.canvas_left = tk.Canvas(left_container, bg="#0b0f19", highlightthickness=0, bd=0)
        self.scrollbar_left = ttk.Scrollbar(left_container, orient="vertical", command=self.canvas_left.yview)
        
        left_frame = ttk.Frame(self.canvas_left)
        left_frame.bind(
            "<Configure>",
            lambda e: self.canvas_left.configure(scrollregion=self.canvas_left.bbox("all"))
        )

        canvas_window = self.canvas_left.create_window((0, 0), window=left_frame, anchor="nw")

        def _on_canvas_configure(event):
            self.canvas_left.itemconfig(canvas_window, width=event.width)

        self.canvas_left.bind("<Configure>", _on_canvas_configure)
        self.canvas_left.configure(yscrollcommand=self.scrollbar_left.set)

        def _on_mousewheel(event):
            self.canvas_left.yview_scroll(int(-1 * (event.delta / 120)), "units")

        self.scrollbar_left.pack(side="right", fill="y")
        self.canvas_left.pack(side="left", fill="both", expand=True)

        box_video = ttk.LabelFrame(left_frame, text="🎬 1. Selecionar Vídeo Bruto da Live", padding=12)
        box_video.pack(fill="x", padx=5, pady=4)

        self.lbl_nome_video = tk.Label(box_video, text="Nenhum arquivo selecionado\n(Usando último vídeo da pasta por padrão)", font=("Segoe UI", 9, "italic"), bg="#151c2c", fg="#94a3b8", wraplength=320, justify="left")
        self.lbl_nome_video.pack(fill="x", pady=(0, 8))

        self.btn_selecionar_video = ttk.Button(box_video, text="📁 Selecionar Arquivo da Live...", style="Select.TButton", command=self.selecionar_arquivo_video)
        self.btn_selecionar_video.pack(fill="x", pady=2)

        # Opção Opcional: Transcrição Existente (.txt)
        frame_trans = tk.Frame(box_video, bg="#151c2c")
        frame_trans.pack(fill="x", pady=(8, 2))

        chk_trans = ttk.Checkbutton(
            frame_trans,
            text="📄 Usar transcrição .txt pronta (Pular Whisper)",
            variable=self.usar_transcricao_existente,
            command=self.toggle_transcricao_ui
        )
        chk_trans.pack(anchor="w")

        self.frame_txt_picker = tk.Frame(box_video, bg="#151c2c")

        self.lbl_nome_txt = tk.Label(
            self.frame_txt_picker,
            text="Nenhum .txt selecionado",
            font=("Segoe UI", 8, "italic"),
            bg="#151c2c",
            fg="#94a3b8",
            wraplength=200,
            justify="left"
        )
        self.lbl_nome_txt.pack(side="left", fill="x", expand=True, padx=(0, 4))

        self.btn_pick_txt = ttk.Button(
            self.frame_txt_picker,
            text="📄 Buscar .txt",
            style="Select.TButton",
            command=self.selecionar_arquivo_transcricao
        )
        self.btn_pick_txt.pack(side="right")


        box_cfg = ttk.LabelFrame(left_frame, text="⚙️ 2. Configurações da IA", padding=12)
        box_cfg.pack(fill="x", padx=5, pady=4)

        tk.Label(box_cfg, text="LM Studio URL:", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w")
        ent_url = ttk.Entry(box_cfg, textvariable=self.lm_url)
        ent_url.pack(fill="x", pady=(2, 6))

        tk.Label(box_cfg, text="Modelo IA:", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w")
        ent_mod = ttk.Entry(box_cfg, textvariable=self.modelo)
        ent_mod.pack(fill="x", pady=(2, 6))
        
        frame_score = tk.Frame(box_cfg, bg="#151c2c")
        frame_score.pack(fill="x", pady=2)
        tk.Label(frame_score, text="Nota Mínima Viral (1-10):", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(side="left")
        spn_score = ttk.Spinbox(frame_score, from_=1, to=10, textvariable=self.nota_minima, width=6)
        spn_score.pack(side="right")

        # Botão para abrir o Wizard de Backend / Onboarding a qualquer momento
        self.btn_onboard_cfg = ttk.Button(box_cfg, text="⚙️ Configurar Motor IA", command=self.abrir_onboarding)
        self.btn_onboard_cfg.pack(fill="x", pady=(6, 2))

        # 3. Editor de Vídeo IA
        box_edicao = ttk.LabelFrame(left_frame, text="🎬 3. Editor de Vídeo IA", padding=12)
        box_edicao.pack(fill="x", padx=5, pady=4)

        ttk.Checkbutton(
            box_edicao,
            text="🔇 Remoção Automática de Silêncio",
            variable=self.remover_silencios
        ).pack(anchor="w", pady=(0, 4))

        tk.Label(box_edicao, text="Posição Webcam / Zoom:", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w")
        cb_webcam = ttk.Combobox(
            box_edicao,
            textvariable=self.posicao_webcam,
            values=["Topo-Esquerdo (Padrão)", "Topo-Direito", "Fundo-Esquerdo", "Fundo-Direito", "Centro", "Desativado"],
            state="readonly"
        )
        cb_webcam.pack(fill="x", pady=(2, 6))
        
        tk.Label(box_edicao, text="🏷️ Nome do Canal / @ (Opcional - Topo Estático):", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w")
        ent_canal = ttk.Entry(box_edicao, textvariable=self.nome_canal)
        ent_canal.pack(fill="x", pady=(2, 2))

        box_acoes = ttk.LabelFrame(left_frame, text="⚡ 4. Controles do Processo", padding=12)
        box_acoes.pack(fill="x", padx=5, pady=4)


        self.btn_iniciar = ttk.Button(box_acoes, text="▶️ Iniciar Produção de Cortes", style="Primary.TButton", command=self.iniciar_esteira)
        self.btn_iniciar.pack(fill="x", pady=4)

        self.btn_recorte = ttk.Button(box_acoes, text="🔄 Forçar Re-Corte (Limpar Cache)", style="Reset.TButton", command=self.forcar_recorte_esteira)
        self.btn_recorte.pack(fill="x", pady=3)

        self.btn_parar = ttk.Button(box_acoes, text="⏹️ Interromper Esteira", style="Stop.TButton", command=self.parar_esteira, state="disabled")
        self.btn_parar.pack(fill="x", pady=4)

        frame_aux = tk.Frame(box_acoes, bg="#151c2c")
        frame_aux.pack(fill="x", pady=2)
        
        self.btn_html = ttk.Button(frame_aux, text="🌐 Dashboard HTML", style="Web.TButton", command=self.abrir_dashboard_html)
        self.btn_html.pack(side="left", fill="x", expand=True, padx=(0, 2))

        self.btn_pasta = ttk.Button(frame_aux, text="📁 Pasta Cortes", style="Web.TButton", command=self.abrir_pasta_cortes)
        self.btn_pasta.pack(side="right", fill="x", expand=True, padx=(2, 0))

        box_stats = ttk.LabelFrame(left_frame, text="📊 Status do Sistema", padding=10)
        box_stats.pack(fill="x", padx=5, pady=4)

        self.lbl_stat_cortes = tk.Label(box_stats, text="Cortes Gerados: 0 vídeos", font=("Segoe UI", 9), bg="#151c2c", fg="#cbd5e1", anchor="w")
        self.lbl_stat_cortes.pack(fill="x", pady=1)

        self.lbl_stat_disco = tk.Label(box_stats, text="Disco Livre: -- GB", font=("Segoe UI", 9), bg="#151c2c", fg="#cbd5e1", anchor="w")
        self.lbl_stat_disco.pack(fill="x", pady=1)

        self.lbl_stat_lm = tk.Label(box_stats, text="Servidor IA: Verificando...", font=("Segoe UI", 9), bg="#151c2c", fg="#cbd5e1", anchor="w")
        self.lbl_stat_lm.pack(fill="x", pady=1)

        # Vincular evento de scroll da roda do mouse (MouseWheel) recursivamente nos elementos do painel esquerdo
        def _bind_mousewheel(widget):
            widget.bind("<MouseWheel>", _on_mousewheel)
            for child in widget.winfo_children():
                _bind_mousewheel(child)
        
        self.root.after(100, lambda: _bind_mousewheel(left_frame))


        # Lado Direito: Visualização do Progresso, Galeria e Terminal
        right_frame = ttk.Frame(main_paned)
        main_paned.add(right_frame, weight=3)

        # Container da Barra de Progresso com Top Banner
        progress_container = tk.Frame(right_frame, bg="#151c2c")
        progress_container.pack(fill="x", padx=5, pady=(5, 8))

        self.lbl_progresso_status = tk.Label(progress_container, text="Pronto para iniciar.", font=("Segoe UI", 10, "bold"), bg="#151c2c", fg="#38bdf8")
        self.lbl_progresso_status.pack(anchor="w", padx=14, pady=(8, 4))

        self.progress_bar = ttk.Progressbar(progress_container, mode="indeterminate")
        self.progress_bar.pack(fill="x", padx=14, pady=(0, 8))

        # Notebook com duas abas principais
        self.notebook = ttk.Notebook(right_frame)
        self.notebook.pack(fill="both", expand=True, padx=5, pady=2)

        # Aba 1: Galeria de Cortes
        self.tab_galeria = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_galeria, text="🎬 Galeria de Cortes Prontos")

        # Visual Vazio (Empty State Component)
        self.empty_state_frame = tk.Frame(self.tab_galeria, bg="#151c2c")
        self.empty_state_frame.pack(fill="both", expand=True, padx=20, pady=20)

        lbl_empty_icon = tk.Label(self.empty_state_frame, text="🎬⚡", font=("Segoe UI", 48), bg="#151c2c", fg="#38bdf8")
        lbl_empty_icon.pack(pady=(40, 10))

        lbl_empty_title = tk.Label(self.empty_state_frame, text="Nenhum corte gerado nesta sessão", font=("Segoe UI", 15, "bold"), bg="#151c2c", fg="#f8fafc")
        lbl_empty_title.pack(pady=4)

        lbl_empty_desc = tk.Label(
            self.empty_state_frame,
            text="Selecione um vídeo da live no painel à esquerda e clique em '▶ Iniciar Produção de Cortes'.\nA IA irá analisar a transcrição, detectar ganchos virais e renderizar vídeos prontos com legendas!",
            font=("Segoe UI", 10), bg="#151c2c", fg="#94a3b8", justify="center"
        )
        lbl_empty_desc.pack(pady=6)

        btn_empty_start = ttk.Button(self.empty_state_frame, text="▶️ Iniciar Produção de Cortes Agora", style="Primary.TButton", command=self.iniciar_esteira)
        btn_empty_start.pack(pady=15)

        # Tabela (Treeview) de Cortes Prontos
        colunas = ("id", "titulo", "nota", "categoria", "duracao", "motivo")
        self.tabela_frame = tk.Frame(self.tab_galeria, bg="#151c2c")
        
        self.tabela = ttk.Treeview(self.tabela_frame, columns=colunas, show="headings", selectmode="browse")
        
        self.tabela.heading("id", text="ID")
        self.tabela.heading("titulo", text="Título Viral do Corte")
        self.tabela.heading("nota", text="Nota")
        self.tabela.heading("categoria", text="Categoria")
        self.tabela.heading("duracao", text="Duração")
        self.tabela.heading("motivo", text="Motivo / Análise da IA")

        self.tabela.column("id", width=45, anchor="center")
        self.tabela.column("titulo", width=220, anchor="w")
        self.tabela.column("nota", width=70, anchor="center")
        self.tabela.column("categoria", width=100, anchor="center")
        self.tabela.column("duracao", width=75, anchor="center")
        self.tabela.column("motivo", width=290, anchor="w")

        scrollbar_y = ttk.Scrollbar(self.tabela_frame, orient="vertical", command=self.tabela.yview)
        self.tabela.configure(yscrollcommand=scrollbar_y.set)
        
        self.tabela.pack(side="left", fill="both", expand=True)
        scrollbar_y.pack(side="right", fill="y")

        self.tabela.bind("<Double-1>", self.on_double_click_corte)

        # Aba 2: Terminal de Logs ao Vivo
        self.tab_log = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_log, text="📜 Terminal de Logs ao Vivo")

        frame_log_inner = tk.Frame(self.tab_log, bg="#0b0f19")
        frame_log_inner.pack(fill="both", expand=True, padx=8, pady=8)

        self.txt_log = tk.Text(
            frame_log_inner,
            bg="#0b0f19",
            fg="#93c5fd",
            font=("Consolas", 10),
            wrap="word",
            borderwidth=0,
            padx=12,
            pady=10,
            selectbackground="#1e3a8a",
            selectforeground="#ffffff"
        )
        scroll_log = ttk.Scrollbar(frame_log_inner, orient="vertical", command=self.txt_log.yview)
        self.txt_log.configure(yscrollcommand=scroll_log.set)

        self.txt_log.pack(side="left", fill="both", expand=True)
        scroll_log.pack(side="right", fill="y")

        self.txt_log.tag_config("INFO", foreground="#93c5fd")
        self.txt_log.tag_config("SUCCESS", foreground="#4ade80")
        self.txt_log.tag_config("WARNING", foreground="#facc15")
        self.txt_log.tag_config("ERROR", foreground="#f87171")
        self.txt_log.tag_config("HIGHLIGHT", foreground="#38bdf8", font=("Consolas", 10, "bold"))

        # Aba 3: Backend IA (NOVA)
        self.tab_backend = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_backend, text="⚙️ Backend IA")
        self._build_tab_backend()

    def _carregar_config_backend_atual(self):
        if not getattr(self, 'backend_manager', None):
            return
        b_nome = self.backend_selecionado.get()
        cfg = self.backend_manager.get_config_backend(b_nome)
        self.backend_url.set(cfg.get("url", ""))
        self.modelo_selecionado.set(cfg.get("modelo", ""))
        self.api_key_cloud.set(cfg.get("api_key", ""))

    def _check_onboarding_startup(self):
        if getattr(self, 'backend_manager', None) and not self.backend_manager.is_onboarding_completo():
            self.abrir_onboarding()

    def abrir_onboarding(self):
        try:
            from onboarding import OnboardingWizard
            top = tk.Toplevel(self.root)
            top.transient(self.root)
            top.lift()
            top.focus_force()

            def _on_finish(escolhido):
                self.backend_selecionado.set(escolhido)
                self._carregar_config_backend_atual()
                self._on_backend_change()

            OnboardingWizard(top, self.backend_manager, _on_finish)
        except Exception as e:
            print(f"[DEBUG] Erro ao abrir onboarding: {e}")


    def _build_tab_backend(self):
        container = tk.Frame(self.tab_backend, bg="#0b0f19")
        container.pack(fill="both", expand=True, padx=15, pady=10)

        # Header
        h_frame = tk.Frame(container, bg="#0b0f19")
        h_frame.pack(fill="x", pady=(0, 8))
        tk.Label(h_frame, text="⚙️ Configuração Central de Motores de IA", font=("Segoe UI", 13, "bold"), bg="#0b0f19", fg="#38bdf8").pack(side="left")

        # Seletor de Backend
        f_sel = tk.Frame(container, bg="#151c2c", highlightbackground="#2a364f", highlightthickness=1)
        f_sel.pack(fill="x", pady=4, ipady=4)

        tk.Label(f_sel, text="Motor de IA Ativo:", font=("Segoe UI", 10, "bold"), bg="#151c2c", fg="#ffffff").pack(side="left", padx=12, pady=6)
        
        nomes_backends = [nome for (nome, _, _) in self.backend_manager._BACKEND_CLASSES] if getattr(self, 'backend_manager', None) else ["Ollama", "LM Studio", "Groq", "OpenRouter"]
        self.cb_backend_sel = ttk.Combobox(f_sel, textvariable=self.backend_selecionado, values=nomes_backends, state="readonly", width=18)
        self.cb_backend_sel.pack(side="left", padx=6, pady=6)
        self.cb_backend_sel.bind("<<ComboboxSelected>>", self._on_backend_change)

        self.btn_detectar_bk = ttk.Button(f_sel, text="🔄 Detectar Serviços", command=self.detectar_backends_ui)
        self.btn_detectar_bk.pack(side="right", padx=12, pady=6)

        # Card de Status
        self.f_status_card = tk.Frame(container, bg="#151c2c", highlightbackground="#2a364f", highlightthickness=1)
        self.f_status_card.pack(fill="x", pady=4, ipady=4)

        self.lbl_status_bk_card = tk.Label(self.f_status_card, text="Status: Verificando...", font=("Segoe UI", 9), bg="#151c2c", fg="#94a3b8")
        self.lbl_status_bk_card.pack(anchor="w", padx=12, pady=6)

        # Campos de Configuração
        f_form = tk.Frame(container, bg="#151c2c", highlightbackground="#2a364f", highlightthickness=1)
        f_form.pack(fill="x", pady=4, ipady=8)

        tk.Label(f_form, text="URL Endpoint API:", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w", padx=12, pady=(6, 2))
        self.ent_bk_url = ttk.Entry(f_form, textvariable=self.backend_url)
        self.ent_bk_url.pack(fill="x", padx=12, pady=(0, 6))

        tk.Label(f_form, text="Modelo de IA:", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w", padx=12, pady=(4, 2))
        self.cb_bk_modelo = ttk.Combobox(f_form, textvariable=self.modelo_selecionado)
        self.cb_bk_modelo.pack(fill="x", padx=12, pady=(0, 6))

        # API Key (Blindagem #8: Toggle Olho)
        self.f_api_key_group = tk.Frame(f_form, bg="#151c2c")
        self.f_api_key_group.pack(fill="x", padx=12, pady=(4, 6))

        tk.Label(self.f_api_key_group, text="Chave de API (API Key):", font=("Segoe UI", 9, "bold"), bg="#151c2c", fg="#f8fafc").pack(anchor="w", pady=(0, 2))
        
        f_key_sub = tk.Frame(self.f_api_key_group, bg="#151c2c")
        f_key_sub.pack(fill="x")

        self.ent_bk_key = ttk.Entry(f_key_sub, textvariable=self.api_key_cloud, show="*")
        self.ent_bk_key.pack(side="left", fill="x", expand=True)

        self.btn_eye_toggle = ttk.Button(f_key_sub, text="👁️", width=4, command=self._toggle_api_key_visibility)
        self.btn_eye_toggle.pack(side="right", padx=(5, 0))

        # Ações do Backend
        f_botoes = tk.Frame(container, bg="#0b0f19")
        f_botoes.pack(fill="x", pady=10)

        self.btn_test_conn = ttk.Button(f_botoes, text="🔌 Testar Conexão", style="Primary.TButton", command=self._testar_conexao_backend)
        self.btn_test_conn.pack(side="left", padx=(0, 6))

        self.btn_repeat_onb = ttk.Button(f_botoes, text="🔄 Repetir Configuração Inicial", command=self.abrir_onboarding)
        self.btn_repeat_onb.pack(side="left", padx=6)

        self.btn_reset_bk = ttk.Button(f_botoes, text="⚠️ Redefinir Backend", command=self._redefinir_backend)
        self.btn_reset_bk.pack(side="right")

        self._on_backend_change()

    def _on_backend_change(self, event=None):
        if not getattr(self, 'backend_manager', None):
            return
        b_nome = self.backend_selecionado.get()
        self._carregar_config_backend_atual()

        b_obj = self.backend_manager.get_backend(b_nome)
        if b_obj:
            if b_obj.tipo == "cloud":
                self.f_api_key_group.pack(fill="x", padx=12, pady=(4, 6))
            else:
                self.f_api_key_group.pack_forget()
            
            self.cb_bk_modelo["values"] = b_obj.get_modelos_recomendados()

        self.detectar_backends_ui()

    def _toggle_api_key_visibility(self):
        self._api_key_visivel = not self._api_key_visivel
        if self._api_key_visivel:
            self.ent_bk_key.config(show="")
            self.btn_eye_toggle.config(text="🙈")
        else:
            self.ent_bk_key.config(show="*")
            self.btn_eye_toggle.config(text="👁️")

    def _testar_conexao_backend(self):
        if not getattr(self, 'backend_manager', None):
            return
        b_nome = self.backend_selecionado.get()
        
        # Salvar configuração atual
        url_norm = self.backend_manager.normalizar_url(self.backend_url.get())
        self.backend_manager.set_config_backend(b_nome, {
            "url": url_norm,
            "modelo": self.modelo_selecionado.get().strip(),
            "api_key": self.api_key_cloud.get().strip()
        })

        self.lbl_status_bk_card.config(text="🔌 Conectando ao backend...", fg="#facc15")
        
        def _task():
            cliente, erro = self.backend_manager.criar_cliente(b_nome)
            def _update():
                if erro:
                    self.lbl_status_bk_card.config(text=f"❌ Falha: {erro}", fg="#f87171")
                else:
                    self.lbl_status_bk_card.config(text=f"✅ Conectado com sucesso ao {b_nome}!", fg="#4ade80")
            self.root.after(0, _update)

        threading.Thread(target=_task, daemon=True).start()

    def _redefinir_backend(self):
        if messagebox.askyesno("Redefinir Configuração", "Deseja restaurar as configurações padrão de todos os backends de IA?"):
            if getattr(self, 'backend_manager', None):
                self.backend_manager.redefinir_config()
                self._carregar_config_backend_atual()
                self._on_backend_change()
                messagebox.showinfo("Configuração Restaurada", "As configurações de IA foram restauradas para os padrões de fábrica.")

    def detectar_backends_ui(self):
        # Blindagem #2: Detecção assíncrona não bloqueante
        if not getattr(self, 'backend_manager', None):
            return
        if hasattr(self, 'btn_detectar_bk'):
            self.btn_detectar_bk.config(state="disabled")
        if hasattr(self, 'lbl_status_bk_card'):
            self.lbl_status_bk_card.config(text="🔄 Detectando status dos serviços...", fg="#facc15")

        def _bg_scan():
            status = self.backend_manager.detectar_todos()
            def _apply():
                if hasattr(self, 'btn_detectar_bk') and self.btn_detectar_bk.winfo_exists():
                    self.btn_detectar_bk.config(state="normal")
                b_atual = self.backend_selecionado.get()
                info = status.get(b_atual, {})
                if hasattr(self, 'lbl_status_bk_card') and self.lbl_status_bk_card.winfo_exists():
                    if info.get("disponivel"):
                        self.lbl_status_bk_card.config(text=f"✅ {b_atual}: {info.get('detalhes', 'Pronto')}", fg="#4ade80")
                        if info.get("modelos"):
                            self.cb_bk_modelo["values"] = info["modelos"]
                    else:
                        self.lbl_status_bk_card.config(text=f"⚠️ {b_atual}: {info.get('detalhes', 'Não detectado')}", fg="#facc15")
            self.root.after(0, _apply)

        threading.Thread(target=_bg_scan, daemon=True).start()


    def selecionar_arquivo_video(self):
        caminho = filedialog.askopenfilename(
            parent=self.root,
            title="Selecionar Vídeo Bruto da Live",
            filetypes=[("Vídeos Suportados", "*.mp4 *.mkv *.avi *.mov *.ts *.mpg *.webm *.flv"), ("Todos os Arquivos", "*.*")]
        )
        if caminho:
            self.caminho_video_selecionado = caminho
            path_obj = Path(caminho)
            gb = path_obj.stat().st_size / (1024 ** 3)
            self.lbl_nome_video.config(text=f"📌 {path_obj.name}\n({gb:.2f} GB)", fg="#38bdf8")
            self.lbl_status_badge.config(text="● PRONTO", fg="#38bdf8")

    def toggle_transcricao_ui(self):
        if self.usar_transcricao_existente.get():
            self.frame_txt_picker.pack(fill="x", pady=(4, 0))
        else:
            self.frame_txt_picker.pack_forget()

    def selecionar_arquivo_transcricao(self):
        caminho = filedialog.askopenfilename(
            parent=self.root,
            title="Selecionar Transcrição .txt Existente",
            filetypes=[("Arquivos de Texto (.txt)", "*.txt"), ("Todos os Arquivos", "*.*")]
        )
        if caminho:
            self.caminho_transcricao.set(caminho)
            path_obj = Path(caminho)
            kb = path_obj.stat().st_size / 1024
            self.lbl_nome_txt.config(text=f"📄 {path_obj.name} ({kb:.1f} KB)", fg="#38bdf8")
            self.usar_transcricao_existente.set(True)
            self.toggle_transcricao_ui()


    def get_lm_url_normalizada(self):
        url = self.lm_url.get().strip().rstrip('/')
        if not url:
            return "http://localhost:1234/v1"
        if not (url.startswith("http://") or url.startswith("https://")):
            url = f"http://{url}"
        if not url.endswith('/v1'):
            url += '/v1'
        return url

    def sincronizar_historico_disco(self):
        """Sincroniza o histórico com os arquivos .mp4 existentes na pasta de saída."""
        if not ARQUIVO_HISTORICO.exists():
            return []
        try:
            with open(ARQUIVO_HISTORICO, "r", encoding="utf-8") as f:
                dados = json.load(f)
            if not isinstance(dados, list):
                return []
            
            dados_validos = []
            for item in dados:
                arq_nome = item.get("arquivo")
                if arq_nome and (DIR_SAIDA / arq_nome).exists():
                    dados_validos.append(item)
            
            if len(dados_validos) != len(dados):
                tmp_p = ARQUIVO_HISTORICO.parent / f"{ARQUIVO_HISTORICO.name}.tmp"
                try:
                    with open(tmp_p, "w", encoding="utf-8") as f_tmp:
                        json.dump(dados_validos, f_tmp, indent=2, ensure_ascii=False)
                        f_tmp.flush()
                        os.fsync(f_tmp.fileno())
                    try:
                        tmp_p.replace(ARQUIVO_HISTORICO)
                    except (PermissionError, OSError):
                        time.sleep(0.05)
                        shutil.copy2(tmp_p, ARQUIVO_HISTORICO)
                        tmp_p.unlink(missing_ok=True)
                except Exception as e_write:
                    try:
                        with open(ARQUIVO_HISTORICO, "w", encoding="utf-8") as f_dir:
                            json.dump(dados_validos, f_dir, indent=2, ensure_ascii=False)
                    except Exception:
                        pass
                    if tmp_p.exists():
                        tmp_p.unlink(missing_ok=True)
            return dados_validos
        except Exception as e_sinc:
            print(f"[DEBUG] Erro ao sincronizar historico com disco: {e_sinc}", file=sys.stderr)
            return []

    def atualizar_estatisticas(self):
        try:
            dados = self.sincronizar_historico_disco()
            self.lbl_stat_cortes.config(text=f"Cortes Gerados: {len(dados)} videos")
        except Exception as e_stat_c:
            print(f"[DEBUG] Erro ao ler contagem de cortes: {e_stat_c}", file=sys.stderr)

        try:
            total, used, free = shutil.disk_usage(DIR_ATUAL)
            free_gb = free / (1024 ** 3)
            self.lbl_stat_disco.config(text=f"Disco Livre: {free_gb:.2f} GB")
        except Exception as e_stat_d:
            print(f"[DEBUG] Erro ao ler espaço em disco: {e_stat_d}", file=sys.stderr)

        self._verificar_backend_ativo_bg()
        self.root.after(5000, self.atualizar_estatisticas)

    def _verificar_backend_ativo_bg(self):
        """Verifica o status apenas do backend atualmente selecionado (não todos)."""
        if not getattr(self, 'backend_manager', None):
            return
        b_nome = self.backend_selecionado.get()
        
        def _check():
            try:
                info = self.backend_manager.detectar_backend(b_nome)
                if info.get("disponivel"):
                    texto = f"Servidor IA: {b_nome} Conectado"
                    cor = "#4ade80"
                else:
                    detalhes = info.get("detalhes", "Desconectado")
                    # Trunca mensagem longa para caber no label
                    detalhes_curto = detalhes[:50] + "..." if len(detalhes) > 50 else detalhes
                    texto = f"Servidor IA: {b_nome} — {detalhes_curto}"
                    cor = "#f87171"
                self.root.after(0, lambda t=texto, c=cor: self.lbl_stat_lm.config(text=t, fg=c))
            except Exception:
                self.root.after(0, lambda: self.lbl_stat_lm.config(text=f"Servidor IA: {b_nome} — Erro", fg="#f87171"))
        
        threading.Thread(target=_check, daemon=True).start()


    def carregar_historico_tabela(self):
        for row in self.tabela.get_children():
            self.tabela.delete(row)

        tem_itens = False
        try:
            historico = self.sincronizar_historico_disco()
            if isinstance(historico, list) and len(historico) > 0:
                tem_itens = True
                for item in historico:
                    try:
                        num = int(item.get("id", 1))
                    except (ValueError, TypeError):
                        num = 1
                    titulo = item.get("headline") or item.get("titulo", "Destaque")
                    titulo = str(titulo).replace("_", " ")[:80]
                    nota = f"⭐ {item.get('pontuacao_viral', 8)}/10"
                    cat = item.get("categoria", "RESENHA").upper()
                    dur_raw = item.get('duracao', 0)
                    try:
                        dur_val = int(float(dur_raw))
                    except Exception:
                        dur_val = 0
                    dur = f"{dur_val}s"
                    motivo = item.get("hook") or item.get("motivo", "Momento viral")
                    motivo = str(motivo)[:100]
                    arq = item.get("arquivo", "")

                    self.tabela.insert("", "end", values=(f"#{num:02d}", titulo, nota, cat, dur, motivo), tags=(arq,))
        except Exception as e_hist:
            print(f"Aviso: Erro ao carregar historico de cortes: {e_hist}", file=sys.stderr)


        if tem_itens:
            self.empty_state_frame.pack_forget()
            self.tabela_frame.pack(fill="both", expand=True)
        else:
            self.tabela_frame.pack_forget()
            self.empty_state_frame.pack(fill="both", expand=True)

        self.root.after(4000, self.carregar_historico_tabela)

    def on_double_click_corte(self, event):
        item_id = self.tabela.selection()
        if not item_id:
            return
        
        values = self.tabela.item(item_id, "values")
        if values:
            tags = self.tabela.item(item_id, "tags")
            if tags and len(tags) > 0:
                nome_arq = tags[0]
                caminho_mp4 = DIR_SAIDA / nome_arq
                if caminho_mp4.exists():
                    try:
                        os.startfile(caminho_mp4)
                    except Exception as e_start:
                        messagebox.showerror("Erro ao Abrir Vídeo", f"Não foi possível abrir o vídeo:\n{e_start}")
                else:
                    messagebox.showwarning("Arquivo não encontrado", f"O arquivo {nome_arq} não foi encontrado na pasta cortes_prontos.")

    def monitorar_logs_arquivo(self):
        if ARQUIVO_LOG.exists():
            try:
                with open(ARQUIVO_LOG, "r", encoding="utf-8", errors="replace") as f:
                    f.seek(self.last_log_pos)
                    novas_linhas = f.read()
                    self.last_log_pos = f.tell()
                    if novas_linhas:
                        self.append_log_realtime(novas_linhas)
            except Exception as e_log_mon:
                print(f"[DEBUG] Erro ao ler novos logs: {e_log_mon}", file=sys.stderr)
        self.root.after(2000, self.monitorar_logs_arquivo)


    def iniciar_esteira(self, forcar=False):
        self.btn_iniciar.config(state="disabled")
        self.btn_recorte.config(state="disabled")
        self.btn_parar.config(state="normal")
        if self.rodando_event.is_set():
            self.btn_iniciar.config(state="normal")
            self.btn_recorte.config(state="normal")
            self.btn_parar.config(state="disabled")
            return

        if self.caminho_video_selecionado:
            p_vid = Path(self.caminho_video_selecionado)
            if not p_vid.exists():
                messagebox.showwarning("Vídeo Não Encontrado", f"O arquivo de vídeo selecionado não foi encontrado:\n{p_vid}")
                self.btn_iniciar.config(state="normal")
                self.btn_recorte.config(state="normal")
                self.btn_parar.config(state="disabled")
                return

        if self.usar_transcricao_existente.get() and self.caminho_transcricao.get():
            p_txt = Path(self.caminho_transcricao.get())
            if not p_txt.exists():
                messagebox.showwarning("Transcrição Não Encontrada", f"O arquivo de transcrição selecionado não foi encontrado:\n{p_txt}")
                self.btn_iniciar.config(state="normal")
                self.btn_recorte.config(state="normal")
                self.btn_parar.config(state="disabled")
                return

        try:
            nota_val = max(1, min(10, int(self.nota_minima.get())))
        except Exception:
            nota_val = 7

        mod_val = self.modelo.get().strip() or "qwen3.5-9b.gguf"

        bk_atual = self.backend_selecionado.get() or "LM Studio"
        mod_escolhido = self.modelo_selecionado.get().strip() or mod_val

        url_final = self.backend_url.get().strip()
        if not url_final and bk_atual.lower() in ("lm studio", "lmstudio"):
            url_final = self.get_lm_url_normalizada()

        config = PipelineConfig(
            video_path=Path(self.caminho_video_selecionado) if self.caminho_video_selecionado else None,
            backend=bk_atual,
            modelo=mod_escolhido,
            nota_minima=nota_val,
            url=url_final,
            api_key=self.api_key_cloud.get().strip(),
            transcricao_path=Path(self.caminho_transcricao.get()) if (self.usar_transcricao_existente.get() and self.caminho_transcricao.get()) else None,
            nome_canal=self.nome_canal.get().strip(),
            forcar=forcar,
            remover_silencios=self.remover_silencios.get(),
            posicao_webcam=self.posicao_webcam.get()
        )

        self._ja_finalizou = False
        self.rodando_event.set()
        self.btn_iniciar.config(state="disabled")
        self.btn_recorte.config(state="disabled")
        self.btn_parar.config(state="normal")
        self.lbl_status_badge.config(text="● EXECUTANDO", fg="#4ade80")
        self.lbl_progresso_status.config(text="Executando esteira de cortes virais...", fg="#38bdf8")
        self.progress_bar.start(10)

        sucesso = self.controller.iniciar(config)
        if not sucesso:
            self.finalizar_execucao(exit_code=1, status_msg="● ERRO AO INICIAR")

    def _on_pipeline_status(self, estado: str, msg: str):
        if estado == EstadoPipeline.EXECUTANDO:
            self.lbl_status_badge.config(text="● EXECUTANDO", fg="#4ade80")
            self.lbl_progresso_status.config(text="Executando esteira de cortes virais...", fg="#38bdf8")
        elif estado == EstadoPipeline.INTERROMPIDO:
            self.lbl_status_badge.config(text="● INTERROMPIDO", fg="#ef4444")
            self.lbl_progresso_status.config(text="⚠️ Processamento interrompido pelo usuário.", fg="#facc15")
        elif estado == EstadoPipeline.ERRO:
            self.lbl_status_badge.config(text="● ERRO", fg="#ef4444")
            self.lbl_progresso_status.config(text=msg, fg="#f87171")

    def forcar_recorte_esteira(self):
        if messagebox.askyesno("Forçar Re-Corte", "Deseja resetar o cache do projeto e recortar o vídeo novamente com novas legendas e prompts virais?"):
            self.iniciar_esteira(forcar=True)

    def _formatar_log_amigavel(self, texto_bruto: str):
        """
        Filtra logs técnicos ruidosos, caminhos gigantescos e hashes de projeto,
        convertendo em mensagens concisas, profissionais e elegantes para a GUI.
        """
        t = texto_bruto.strip()
        if not t:
            return None, "INFO"

        # Remove prefixos de timestamp longos tipo [2026-08-14 01:05:10] [INFO]
        t_sem_ts = re.sub(r'^\[\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\]\s*\[(?:INFO|DEBUG|WARNING|ERROR)\]\s*', '', t)

        # Transcrição reutilizada do cache
        if "Transcrição de" in t_sem_ts and "reutilizada" in t_sem_ts:
            m_falas = re.search(r'\((\d+)\s+falas', t_sem_ts)
            qtd = f"{int(m_falas.group(1)):,}".replace(",", ".") if m_falas else "milhares de"
            return f"⚡ Transcrição carregada do cache ({qtd} falas úteis)", "SUCCESS"

        # Fatiamento / pacotes
        if "Fatiamento concluído" in t_sem_ts:
            m_pct = re.search(r'Total de (\d+) pacotes', t_sem_ts)
            qtd = m_pct.group(1) if m_pct else ""
            return f"📦 Live dividida em {qtd} blocos de análise de IA", "INFO"

        # Fallback heurístico / Análise de pacote
        if "fallback heurístico com detecção de emoção para pacote_" in t_sem_ts:
            m_num = re.search(r'pacote_(\d+)', t_sem_ts)
            num_str = f"Bloco {int(m_num.group(1))}" if m_num else "Bloco"
            return f"🎯 Analisando reações, emoções e picos virais ({num_str})...", "HIGHLIGHT"

        if "Iniciando análise com IA para pacote_" in t_sem_ts:
            m_num = re.search(r'pacote_(\d+)', t_sem_ts)
            num_str = f"Bloco {int(m_num.group(1))}" if m_num else "Bloco"
            return f"🧠 Analisando transcrição com IA ({num_str})...", "HIGHLIGHT"

        # Renderização do corte
        if "Iniciando FFmpeg para corte_" in t_sem_ts:
            m_num = re.search(r'corte_(\d+)', t_sem_ts)
            m_tempo = re.search(r'tempo:\s*([\d\.]+)s\s*->\s*([\d\.]+)s', t_sem_ts)
            dur_str = ""
            if m_tempo:
                dur = float(m_tempo.group(2)) - float(m_tempo.group(1))
                dur_str = f" ({dur:.0f}s)"
            num_corte = f"Corte {int(m_num.group(1)):02d}" if m_num else "Corte"
            return f"🎬 Renderizando {num_corte} em 9:16 com Auto Silence Cut{dur_str}...", "INFO"

        # Corte Confirmado
        if "Corte Confirmado" in t_sem_ts:
            m_nota = re.search(r'Nota:\s*(\d+)/10', t_sem_ts)
            m_cat = re.search(r'Cat:\s*(\w+)', t_sem_ts)
            nota = m_nota.group(1) if m_nota else "?"
            cat = m_cat.group(1) if m_cat else "VIRAL"
            m_corte = re.search(r'corte_(\d+)', t_sem_ts)
            num = int(m_corte.group(1)) if m_corte else 1
            return f"✅ Corte {num:02d} Concluído! [Nota {nota}/10 — {cat}]", "SUCCESS"

        if "Renderização concluída" in t_sem_ts:
            return None, "INFO"

        if "[PERFORMANCE]" in t:
            return None, "INFO"

        tag = "INFO"
        if "erro" in t_sem_ts.lower() or "error" in t_sem_ts.lower() or "falha" in t_sem_ts.lower():
            tag = "ERROR"
        elif "warning" in t_sem_ts.lower() or "aviso" in t_sem_ts.lower():
            tag = "WARNING"
        elif "concluído" in t_sem_ts.lower() or "sucesso" in t_sem_ts.lower() or "✓" in t_sem_ts:
            tag = "SUCCESS"

        ts_curto = time.strftime("%H:%M:%S")
        return f"[{ts_curto}] {t_sem_ts}", tag

    def append_log_realtime(self, texto, tag=None):
        if not tag:
            texto_formatado, tag_detectada = self._formatar_log_amigavel(texto)
            if texto_formatado is None:
                return
            texto_exibir = texto_formatado + "\n"
            tag = tag_detectada
        else:
            texto_exibir = texto if texto.endswith("\n") else texto + "\n"

        try:
            num_linhas = int(self.txt_log.index('end-1c').split('.')[0])
            if num_linhas > 1500:
                self.txt_log.delete('1.0', '400.0')
        except Exception:
            pass

        self.txt_log.insert(tk.END, texto_exibir, (tag,))
        self.txt_log.see(tk.END)

        if "Analisando" in texto_exibir or "🧠" in texto_exibir or "🎯" in texto_exibir:
            self.lbl_progresso_status.config(text=f"Etapa: {texto_exibir.strip()}", fg="#facc15")
        elif "Renderizando" in texto_exibir or "🎬" in texto_exibir:
            self.lbl_progresso_status.config(text=f"Etapa: {texto_exibir.strip()}", fg="#38bdf8")
            self.carregar_historico_tabela()
        elif "Transcrevendo" in texto_exibir:
            self.lbl_progresso_status.config(text="Etapa: Transcrevendo com Faster-Whisper...", fg="#38bdf8")
        elif "Concluído" in texto_exibir or "✅" in texto_exibir:
            self.carregar_historico_tabela()

    def parar_esteira(self):
        if self.controller.is_rodando() or self.rodando_event.is_set():
            self.controller.parar()

    def finalizar_execucao(self, exit_code=0, status_msg=None):
        if getattr(self, '_ja_finalizou', False):
            return
        self._ja_finalizou = True
        self.rodando_event.clear()
        self.progress_bar.stop()
        self.btn_iniciar.config(state="normal")
        self.btn_recorte.config(state="normal")
        self.btn_parar.config(state="disabled")

        # Refresh tabela ANTES de contar para ter dados atualizados
        self.carregar_historico_tabela()
        self.root.update_idletasks()
        qtd_cortes = len(self.tabela.get_children())

        if status_msg == "● INTERROMPIDO":
            self.lbl_status_badge.config(text="● INTERROMPIDO", fg="#ef4444")
            self.lbl_progresso_status.config(text="⚠️ Processamento interrompido pelo usuário.", fg="#facc15")
        elif exit_code != 0:
            self.lbl_status_badge.config(text="● ERRO", fg="#ef4444")
            self.lbl_progresso_status.config(text="❌ Ocorreu um erro no processamento. Verifique a aba 'Terminal de Logs'.", fg="#f87171")
            self.notebook.select(self.tab_log)
        elif qtd_cortes > 0:
            self.lbl_status_badge.config(text=f"● CONCLUÍDO ({qtd_cortes} CORTES)", fg="#4ade80")
            self.lbl_progresso_status.config(text=f"🎉 Processamento concluído com sucesso! {qtd_cortes} cortes gerados.", fg="#4ade80")
            self.notebook.select(self.tab_galeria)
        else:
            self.lbl_status_badge.config(text="● 0 CORTES GERADOS", fg="#facc15")
            self.lbl_progresso_status.config(text="⚠️ Processamento concluído, mas nenhum corte atendeu aos critérios. Altere a Nota Mínima ou consulte o Log.", fg="#facc15")
            self.notebook.select(self.tab_log)

    def abrir_dashboard_html(self):
        if ARQUIVO_HTML.exists():
            webbrowser.open(str(ARQUIVO_HTML.resolve()))
        else:
            messagebox.showinfo("Dashboard HTML", "O Dashboard HTML ainda não foi gerado. Execute a esteira para criá-lo.")

    def abrir_pasta_cortes(self):
        DIR_SAIDA.mkdir(exist_ok=True)
        try:
            os.startfile(DIR_SAIDA)
        except Exception as e:
            messagebox.showerror("Erro ao Abrir Pasta", f"Falha ao abrir pasta de saída:\n{e}")

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--backend":
        sys.argv.pop(1)
        import esteira
        esteira.main()
        sys.exit(0)

    root = tk.Tk()
    if LOGO_PATH.exists() and HAS_PIL:
        try:
            ico_img = ImageTk.PhotoImage(Image.open(LOGO_PATH))
            root.iconphoto(True, ico_img)
        except Exception as e_ico_main:
            print(f"[DEBUG] Ícone principal não aplicado: {e_ico_main}")

    app = ViralCutsProGUI(root)
    root.mainloop()


if __name__ == "__main__":
    multiprocessing.freeze_support()
    main()
